/* equity.js — manual equity transactions, Twelve Data symbol search/autocomplete,
   and FIFO-derived holdings for the equity book. */

const Equity = (() => {
  const COLLECTION = 'equity_transactions';
  let searchDebounce = null;

  function td(path, params) {
    const url = new URL(`https://api.twelvedata.com/${path}`);
    Object.entries(params || {}).forEach(([k, v]) => url.searchParams.set(k, v));
    if (typeof TWELVEDATA_API_KEY !== 'undefined' && TWELVEDATA_API_KEY) url.searchParams.set('apikey', TWELVEDATA_API_KEY);
    return fetch(url).then(r => r.json());
  }

  async function searchSymbol(query) {
    if (!query || query.length < 2) return [];
    const data = await td('symbol_search', { symbol: query });
    if (!data || !data.data) return [];
    return data.data
      .filter(d => d.country === 'India' && (d.exchange === 'NSE' || d.exchange === 'BSE'))
      .slice(0, 8);
  }

  async function fetchQuotes(items) {
    // items: [{symbol, exchange}] -> returns { "SYMBOL:EXCHANGE": {price, ...} }
    // NOTE: Twelve Data's free plan excludes NSE/BSE price data entirely (confirmed against
    // their live API — only symbol_search above works on it for India). This will 404 for
    // any Indian symbol; kept here in case it's ever pointed at exchanges the free plan does
    // cover. Equity prices actually come from price_cache, populated by the scheduled Apps
    // Script job reading NSE's bhavcopy — see apps-script/dailyPriceUpdate.gs.
    if (!items.length) return {};
    const symbolParam = items.map(i => `${i.symbol}:${i.exchange}`).join(',');
    const data = await td('quote', { symbol: symbolParam });
    const out = {};
    if (!data || data.code) return out; // API error (e.g. missing/invalid key) — caller falls back gracefully
    if (items.length === 1) {
      out[`${items[0].symbol}:${items[0].exchange}`] = data;
    } else {
      Object.keys(data).forEach(k => { if (data[k] && !data[k].code) out[k] = data[k]; });
    }
    return out;
  }

  /* ---------- CRUD ---------- */
  async function addTransaction(txn) {
    return DB.addDoc(COLLECTION, txn);
  }
  async function updateTransaction(id, patch) {
    return DB.updateDoc(COLLECTION, id, patch);
  }
  async function deleteTransaction(id) {
    return DB.deleteDoc(COLLECTION, id);
  }
  async function deleteHolding(symbol, exchange) {
    // Removes every transaction for this symbol+exchange — used for "remove this stock
    // entirely" on the holdings table, rather than deleting one transaction at a time.
    const txns = await getAllTransactions();
    const toDelete = txns.filter(t => t.symbol === symbol && t.exchange === exchange);
    await Promise.all(toDelete.map(t => DB.deleteDoc(COLLECTION, t.id)));
    return toDelete.length;
  }
  // What "Import from statements" created: every transaction tagged source:'import'.
  const IMPORT_COLLECTIONS = ['equity_ledger', 'equity_snapshots', 'equity_costs'];
  async function importedSummary() {
    const all = await getAllTransactions();
    const imported = all.filter(t => t.source === 'import');
    const [ledger, snaps] = await Promise.all([DB.getAll('equity_ledger'), DB.getAll('equity_snapshots')]);
    return {
      lots: imported.length,
      stocks: new Set(imported.map(t => `${t.symbol}:${t.exchange}`)).size,
      cost: imported.reduce((s, t) => s + t.qty * t.price, 0),
      manual: all.length - imported.length,
      ledgerEvents: ledger.reduce((s, d) => s + (d.events ? d.events.length : 0), 0),
      snapshots: snaps.length
    };
  }
  // Deletes everything the statement import created — its lots, and the saved statement history
  // (ledger, holdings snapshots, chosen costs/tickers) that new uploads build on. Manual
  // transactions are never touched. The daily value snapshots that include equity are removed
  // too, because they embed the deleted holdings (they only feed the "Total incl. equity" line).
  async function deleteImported() {
    const imported = (await getAllTransactions()).filter(t => t.source === 'import');
    for (let i = 0; i < imported.length; i += 10) {
      await Promise.all(imported.slice(i, i + 10).map(t => DB.deleteDoc(COLLECTION, t.id)));
    }
    let ledgerDocs = 0;
    for (const col of IMPORT_COLLECTIONS) {
      const docs = await DB.getAll(col);
      for (let i = 0; i < docs.length; i += 10) await Promise.all(docs.slice(i, i + 10).map(d => DB.deleteDoc(col, d.id)));
      ledgerDocs += docs.length;
    }
    let snapshots = 0;
    if (imported.length || ledgerDocs) {
      const snaps = (await DB.getAll('value_history')).filter(s => (s.eqValue || 0) > 0);
      for (let i = 0; i < snaps.length; i += 10) {
        await Promise.all(snaps.slice(i, i + 10).map(s => DB.deleteDoc('value_history', s.id)));
      }
      snapshots = snaps.length;
    }
    // The cached "Value over time" equity line was built from exactly the data just deleted —
    // leaving it in place would show a line for holdings that no longer exist.
    try { await EqHistory.clearCachedSeries(); } catch (e) { /* not essential */ }
    return { lots: imported.length, ledgerDocs, snapshots };
  }
  async function getAllTransactions() {
    const rows = await DB.getAll(COLLECTION);
    return rows.sort((a, b) => new Date(a.date) - new Date(b.date));
  }

  /* ---------- Derive holdings via FIFO, grouped by symbol+exchange ---------- */
  async function computeHoldings() {
    const txns = await getAllTransactions();
    const groups = {};
    txns.forEach(t => {
      const key = `${t.symbol}:${t.exchange}`;
      (groups[key] = groups[key] || { symbol: t.symbol, exchange: t.exchange, companyName: t.companyName, isin: t.isin, broker: t.broker, txns: [] }).txns.push(t);
    });

    const holdings = [];
    Object.values(groups).forEach(g => {
      const { lots, realized } = Calc.fifoMatch(g.txns);
      const qty = lots.reduce((s, l) => s + l.qty, 0);
      const avgCostVal = Calc.avgCost(lots);
      const realizedSum = Calc.sumRealized(realized);
      holdings.push({
        symbol: g.symbol, exchange: g.exchange, companyName: g.companyName, isin: g.isin, broker: g.broker,
        // Imported positions carry estimated acquisition dates (the books have none), so any
        // return calculation that depends on dates must leave them out — see App's XIRR code.
        imported: g.txns.some(t => t.source === 'import'),
        hasEstimatedDates: g.txns.some(t => t.dateEstimated),
        // a split/bonus rescales the lots' quantity and price, so their displayed figures no longer
        // equal the raw entries — lot-level editing is only offered where they still do
        hasCorpAction: g.txns.some(t => t.type === 'split' || t.type === 'bonus'),
        qty, avgCost: avgCostVal, lots, realized, realizedSum,
        cashflows: g.txns.filter(t => t.type === 'buy' || t.type === 'sell').map(t => ({
          date: new Date(t.date), amount: t.type === 'buy' ? -(t.qty * t.price) : (t.qty * t.price)
        }))
      });
    });
    return holdings;
  }

  return { searchSymbol, fetchQuotes, addTransaction, updateTransaction, deleteTransaction, deleteHolding, importedSummary, deleteImported, getAllTransactions, computeHoldings };
})();

/* ---------- UI wiring ---------- */
(function () {
  let selectedStock = null;

  function openEquityModal() {
    document.getElementById('eqTxnForm').reset();
    document.getElementById('eqSelectedStock').hidden = true;
    document.getElementById('eqStockResults').hidden = true;
    document.getElementById('eqDate').value = new Date().toISOString().slice(0, 10);
    selectedStock = null;
    onTypeChange();
    document.getElementById('eqTxnModal').hidden = false;
  }

  function onTypeChange() {
    const type = document.getElementById('eqType').value;
    const isCorpAction = type === 'split' || type === 'bonus';
    document.getElementById('eqRatioRow').hidden = !isCorpAction;
    document.getElementById('eqPriceField').style.display = isCorpAction ? 'none' : '';
  }

  async function handleStockSearch(e) {
    const q = e.target.value.trim();
    const list = document.getElementById('eqStockResults');
    if (q.length < 2) { list.hidden = true; return; }
    const results = await Equity.searchSymbol(q);
    if (!results.length) { list.innerHTML = '<div class="autocomplete-item">No matches</div>'; list.hidden = false; return; }
    list.innerHTML = results.map((r, i) =>
      `<div class="autocomplete-item" data-idx="${i}"><span>${r.instrument_name}</span><span class="ex">${r.symbol} · ${r.exchange}</span></div>`
    ).join('');
    list.hidden = false;
    list.querySelectorAll('.autocomplete-item[data-idx]').forEach(el => {
      el.addEventListener('click', () => {
        const r = results[+el.dataset.idx];
        selectedStock = r;
        document.getElementById('eqSymbol').value = r.symbol;
        document.getElementById('eqExchange').value = r.exchange;
        document.getElementById('eqCompanyName').value = r.instrument_name;
        document.getElementById('eqStockSearch').value = r.instrument_name;
        const sel = document.getElementById('eqSelectedStock');
        sel.hidden = false;
        sel.textContent = `${r.instrument_name} — ${r.symbol} (${r.exchange})`;
        list.hidden = true;
      });
    });
  }

  async function handleSubmit(e) {
    e.preventDefault();
    const status = document.getElementById('eqTxnStatus');
    const type = document.getElementById('eqType').value;
    if (!selectedStock && !document.getElementById('eqSymbol').value) {
      status.textContent = 'Pick a stock from the search results.'; status.className = 'status-line error'; return;
    }
    const txn = {
      type,
      symbol: document.getElementById('eqSymbol').value,
      exchange: document.getElementById('eqExchange').value,
      companyName: document.getElementById('eqCompanyName').value,
      qty: parseFloat(document.getElementById('eqQty').value) || 0,
      price: parseFloat(document.getElementById('eqPrice').value) || 0,
      date: document.getElementById('eqDate').value,
      broker: document.getElementById('eqBroker').value,
      isin: document.getElementById('eqIsin').value || null,
      charges: {
        brokerage: parseFloat(document.getElementById('eqBrokerage').value) || 0,
        stt: parseFloat(document.getElementById('eqStt').value) || 0,
        other: parseFloat(document.getElementById('eqOtherCharges').value) || 0
      }
    };
    if (type === 'split' || type === 'bonus') {
      txn.ratio = parseFloat(document.getElementById('eqRatio').value) || 1;
    }
    try {
      await Equity.addTransaction(txn);
      status.textContent = 'Saved.'; status.className = 'status-line ok';
      setTimeout(() => { document.getElementById('eqTxnModal').hidden = true; App.refreshCurrentView(); }, 500);
    } catch (err) {
      status.textContent = 'Error: ' + err.message; status.className = 'status-line error';
    }
  }

  document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('eqStockSearch').addEventListener('input', (e) => {
      clearTimeout(searchDebounceTimer);
      searchDebounceTimer = setTimeout(() => handleStockSearch(e), 300);
    });
    document.getElementById('eqType').addEventListener('change', onTypeChange);
    document.getElementById('eqTxnForm').addEventListener('submit', handleSubmit);
  });
  let searchDebounceTimer = null;

  window.EquityUI = { openEquityModal };
})();
