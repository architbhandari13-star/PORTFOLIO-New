/* edit.js — correcting entries after they have been saved (typos at upload, a wrong ticker, a wrong
   date). One small form serves every case; what can be edited depends on where the record came from:

     manual equity transaction   everything
     imported equity lot         its DATE, and — for the whole stock — ticker, exchange, name and cost
                                 per share. Quantity and lot structure come from the statements, so
                                 they are read-only here (re-uploading would rebuild them anyway).
     equity holding              ticker / exchange / name across all of its transactions
     mutual fund transaction     date, units, NAV, amount (sign follows the type)
     mutual fund                 scheme name and AMC, across its folio, transactions and periods

   Edits to imported data are also written to the records that survive a re-import (`equity_costs`
   for ticker/cost, `dateEdited` + `lotKey` for dates), so a later upload does not undo them. */

const EditUI = (() => {
  const BROKERS = ['IIFL', 'SMC Global', 'Joindre Capital', 'Karvy Capital', 'Prabhudas', 'Reliance Securities', 'Sunshine', 'KR Choksey', 'Kotak', 'Other'];
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const num = (v) => { const n = parseFloat(String(v).replace(/,/g, '')); return isNaN(n) ? null : n; };
  const isDate = (s) => /^\d{4}-\d{2}-\d{2}$/.test(s) && !isNaN(new Date(s));
  const r4 = (n) => Math.round(n * 10000) / 10000;
  let cfg = null;

  /* ---------- the generic form ---------- */
  // cfg: { title, note, fields:[{key,label,type,value,options,step,min,full,readonly,hint,showWhen(values)}],
  //        validate(values) -> message|null, save(values) -> Promise }
  function fieldHtml(f) {
    const id = `edit_${f.key}`;
    let input;
    if (f.type === 'select') input = `<select id="${id}" ${f.readonly ? 'disabled' : ''}>${f.options.map(o => `<option value="${esc(o)}" ${String(o) === String(f.value) ? 'selected' : ''}>${esc(o)}</option>`).join('')}</select>`;
    else input = `<input id="${id}" type="${f.type || 'text'}" value="${esc(f.value)}" ${f.step ? `step="${f.step}"` : ''} ${f.min != null ? `min="${f.min}"` : ''} ${f.readonly ? 'readonly' : ''} ${f.upper ? 'style="text-transform:uppercase"' : ''} autocomplete="off" spellcheck="false">`;
    return `<label class="field ${f.full ? 'full' : ''}" data-fieldwrap="${f.key}"><span>${esc(f.label)}</span>${input}${f.hint ? `<small class="field-hint">${esc(f.hint)}</small>` : ''}</label>`;
  }
  function values() {
    const v = {};
    cfg.fields.forEach(f => { const el = document.getElementById(`edit_${f.key}`); v[f.key] = el ? el.value : f.value; });
    return v;
  }
  function refreshVisibility() {
    const v = values();
    cfg.fields.forEach(f => { const w = document.querySelector(`[data-fieldwrap="${f.key}"]`); if (w && f.showWhen) w.hidden = !f.showWhen(v); });
  }

  function open(c) {
    cfg = c;
    document.getElementById('editTitle').textContent = c.title;
    const note = document.getElementById('editNote');
    note.hidden = !c.note; note.innerHTML = c.note || '';
    document.getElementById('editFields').innerHTML = c.fields.map(fieldHtml).join('');
    const st = document.getElementById('editStatus'); st.textContent = ''; st.className = 'status-line';
    document.getElementById('editSave').disabled = false;
    refreshVisibility();
    document.getElementById('editModal').hidden = false;
    const first = document.querySelector('#editFields input:not([readonly]), #editFields select');
    if (first) first.focus();
  }

  async function submit(e) {
    e.preventDefault();
    const st = document.getElementById('editStatus'), btn = document.getElementById('editSave');
    const v = values();
    const bad = cfg.validate ? cfg.validate(v) : null;
    if (bad) { st.textContent = bad; st.className = 'status-line error'; return; }
    btn.disabled = true;
    try {
      st.textContent = 'Saving…'; st.className = 'status-line';
      await cfg.save(v);
      st.textContent = 'Saved.'; st.className = 'status-line ok';
      setTimeout(() => { document.getElementById('editModal').hidden = true; App.refreshCurrentView(); }, 450);
    } catch (err) {
      st.textContent = 'Error: ' + err.message; st.className = 'status-line error';
      btn.disabled = false;
    }
  }

  /* ---------- equity: stock-level change (ticker / name / cost) ---------- */
  // Applies to every transaction of the stock; for imported lots it is also stored where a later
  // import will find it, so it is not undone.
  async function applyStockEdit(old, next) {
    const txns = (await Equity.getAllTransactions()).filter(t => t.symbol === old.symbol && t.exchange === old.exchange);
    const tickerChanged = next.symbol !== old.symbol || next.exchange !== old.exchange;
    const importedIsins = new Set();
    for (const t of txns) {
      const patch = { symbol: next.symbol, exchange: next.exchange, companyName: next.companyName };
      if (t.source === 'import') {
        importedIsins.add(t.isin);
        // a lot whose cost was set individually keeps it; the stock-wide cost only reaches the others
        if (next.rate != null && !t.priceEdited && Math.abs(next.rate - t.price) > 1e-9) { patch.price = r4(next.rate); patch.costSource = 'entered'; }
      }
      await Equity.updateTransaction(t.id, patch);
    }
    if (importedIsins.size) {
      const costs = (await DB.getAll('equity_costs')).filter(c => importedIsins.has(c.isin));
      for (const c of costs) {
        const p = { symbol: next.symbol, exchange: next.exchange, companyName: next.companyName };
        if (tickerChanged) p.tickerEdited = true;
        if (next.rate != null && (c.rate == null || Math.abs(next.rate - c.rate) > 1e-9)) { p.rate = r4(next.rate); p.costSource = 'entered'; p.rateEdited = true; }
        await DB.updateDoc('equity_costs', c.id, p);
      }
      // A ticker correction changes which symbol the Overview's cached price history looks up —
      // the cache would otherwise keep showing the old (or missing) symbol's line.
      if (tickerChanged) await EqHistory.bumpGeneration();
    }
    if (tickerChanged) { try { await Pricing.refreshEquityPrices(await Equity.computeHoldings()); } catch (e) { /* prices refresh on the next visit */ } }
    return txns.length;
  }

  const stockFields = (h, withRate) => [
    { key: 'symbol', label: 'Ticker symbol', value: h.symbol, upper: true },
    { key: 'exchange', label: 'Exchange', type: 'select', options: ['NSE', 'BSE'], value: h.exchange },
    { key: 'companyName', label: 'Company name', value: h.companyName || '', full: true },
    ...(withRate ? [{ key: 'rate', label: 'Default cost per share (imported lots)', type: 'number', step: 'any', min: 0, value: withRate.value, full: true, hint: 'Applies to imported lots whose cost you have not set individually. For a specific lot, use ✎ in the stock\'s lot list.' }] : [])
  ];
  const stockValidate = (v) => (!v.symbol.trim() ? 'The ticker symbol cannot be empty.' : (v.rate !== undefined && v.rate !== '' && !(num(v.rate) > 0) ? 'Cost per share must be a positive number.' : null));

  /* ---------- entry points ---------- */
  // One lot: its own purchase date and its own cost per share. Imported lots are individual records
  // rebuilt from the statements on every import, so a lot's edits are remembered by its `lotKey`
  // (`dateEdited` / `priceEdited`) and re-applied to that same lot afterwards.
  async function openLot(id) {
    const t = (await Equity.getAllTransactions()).find(x => x.id === id);
    if (!t) return;
    if (t.source !== 'import') return openEquityTxn(id);   // a manual lot is an ordinary entry: full form
    open({
      title: 'Edit lot',
      note: `<b>${Number(t.qty).toLocaleString('en-IN', { maximumFractionDigits: 3 })} shares</b> of ${esc(t.companyName || t.symbol)}. The quantity comes from your CDSL statements, so it isn't editable; the date and cost below apply to <b>this lot only</b>.${t.dateEstimated ? ' <span class="warn-text">The date is only a placeholder (' + esc(t.dateNote || 'no purchase date') + ') — enter the real one.</span>' : ''}`,
      fields: [
        { key: 'date', label: 'Purchase date', type: 'date', value: t.date },
        { key: 'price', label: 'Cost per share (₹)', type: 'number', step: 'any', min: 0, value: t.price, hint: t.priceEdited ? 'You set this cost yourself.' : 'Currently your books\' average for the stock — enter the real price if you know it.' }
      ],
      validate: (v) => !isDate(v.date) ? 'Please enter a valid date.' : (!(num(v.price) > 0) ? 'Cost per share must be greater than zero.' : null),
      save: async (v) => {
        const patch = {};
        if (v.date !== t.date) Object.assign(patch, { date: v.date, dateEstimated: false, dateEdited: true });
        if (Math.abs(num(v.price) - t.price) > 1e-9) Object.assign(patch, { price: r4(num(v.price)), priceEdited: true, costSource: 'entered' });
        if (Object.keys(patch).length) await Equity.updateTransaction(t.id, patch);
      }
    });
  }

  async function openEquityTxn(id) {
    const t = (await Equity.getAllTransactions()).find(x => x.id === id);
    if (!t) return;
    if (t.source === 'import') return openLot(id);
    const isCorp = (v) => v.type === 'split' || v.type === 'bonus';
    open({
      title: 'Edit transaction',
      fields: [
        { key: 'type', label: 'Type', type: 'select', options: ['buy', 'sell', 'split', 'bonus'], value: t.type },
        { key: 'date', label: 'Date', type: 'date', value: t.date },
        { key: 'symbol', label: 'Ticker symbol', value: t.symbol, upper: true },
        { key: 'exchange', label: 'Exchange', type: 'select', options: ['NSE', 'BSE'], value: t.exchange },
        { key: 'companyName', label: 'Company name', value: t.companyName || '', full: true },
        { key: 'qty', label: 'Quantity', type: 'number', step: 'any', min: 0, value: t.qty, showWhen: v => !isCorp(v) },
        { key: 'price', label: 'Price / share', type: 'number', step: 'any', min: 0, value: t.price, showWhen: v => !isCorp(v) },
        { key: 'ratio', label: 'Ratio (new units per old unit)', type: 'number', step: 'any', min: 0, value: t.ratio || '', full: true, showWhen: isCorp, hint: 'e.g. 2 for a 1:1 bonus' },
        { key: 'broker', label: 'Broker / DP', type: 'select', options: BROKERS.includes(t.broker) ? BROKERS : [...BROKERS, t.broker].filter(Boolean), value: t.broker || 'Other' },
        { key: 'isin', label: 'ISIN (optional)', value: t.isin || '' },
        { key: 'brokerage', label: 'Brokerage', type: 'number', step: 'any', min: 0, value: (t.charges && t.charges.brokerage) || 0 },
        { key: 'stt', label: 'STT', type: 'number', step: 'any', min: 0, value: (t.charges && t.charges.stt) || 0 },
        { key: 'other', label: 'Other charges', type: 'number', step: 'any', min: 0, value: (t.charges && t.charges.other) || 0 }
      ],
      validate: (v) => {
        if (!v.symbol.trim()) return 'The ticker symbol cannot be empty.';
        if (!isDate(v.date)) return 'Please enter a valid date.';
        if (isCorp(v)) return num(v.ratio) > 0 ? null : 'Enter the split/bonus ratio.';
        return num(v.qty) > 0 ? (num(v.price) >= 0 ? null : 'Enter the price.') : 'Quantity must be greater than zero.';
      },
      save: async (v) => {
        const corp = isCorp(v);
        await Equity.updateTransaction(t.id, {
          type: v.type, date: v.date, symbol: v.symbol.trim().toUpperCase(), exchange: v.exchange, companyName: v.companyName.trim(),
          qty: corp ? (t.qty || 0) : num(v.qty), price: corp ? 0 : num(v.price), ratio: corp ? num(v.ratio) : null,
          broker: v.broker, isin: v.isin.trim() || null,
          charges: { brokerage: num(v.brokerage) || 0, stt: num(v.stt) || 0, other: num(v.other) || 0 }
        });
      }
    });
  }

  async function openHolding(symbol, exchange) {
    const txns = (await Equity.getAllTransactions()).filter(t => t.symbol === symbol && t.exchange === exchange);
    if (!txns.length) return;
    const imported = txns.filter(t => t.source === 'import');
    const h = txns[0];
    open({
      title: `Edit ${symbol}`,
      note: `Changes apply to the whole stock (all <b>${txns.length}</b> transaction${txns.length > 1 ? 's' : ''}). Use this to fix a wrong ticker or company name. <b>Dates and costs are edited lot by lot</b> — expand the stock's lots and use ✎ on a lot.`,
      fields: stockFields(h, imported.length ? { value: imported[0].price } : null),
      validate: stockValidate,
      save: (v) => applyStockEdit({ symbol, exchange }, { symbol: v.symbol.trim().toUpperCase(), exchange: v.exchange, companyName: v.companyName.trim(), rate: imported.length ? num(v.rate) : null })
    });
  }

  async function openMfTxn(id) {
    const t = (await Mf.getAllTransactions()).find(x => x.id === id);
    if (!t) return;
    const sign = t.type === 'redemption' ? -1 : 1;
    open({
      title: t.type === 'redemption' ? 'Edit redemption' : 'Edit purchase',
      note: `<b>${esc(t.schemeName)}</b><br>Enter positive numbers — the ${t.type} sign is applied for you.`,
      fields: [
        { key: 'date', label: 'Date', type: 'date', value: t.date, full: true },
        { key: 'units', label: 'Units', type: 'number', step: 'any', min: 0, value: Math.abs(t.units || 0) },
        { key: 'nav', label: 'NAV', type: 'number', step: 'any', min: 0, value: t.nav || 0 },
        { key: 'amount', label: 'Amount (₹)', type: 'number', step: 'any', min: 0, value: Math.abs(t.amount || 0), full: true }
      ],
      validate: (v) => !isDate(v.date) ? 'Please enter a valid date.' : (!(num(v.units) > 0) ? 'Units must be greater than zero.' : (!(num(v.amount) > 0) ? 'Amount must be greater than zero.' : null)),
      save: (v) => Mf.updateTransaction(t.id, { date: v.date, units: sign * num(v.units), nav: num(v.nav) || 0, amount: sign * num(v.amount) })
    });
  }

  async function openFolio(id) {
    const f = (await Mf.getAllFolios()).find(x => x.id === id);
    if (!f) return;
    open({
      title: 'Edit fund details',
      note: `Folio ${esc(f.folioNo || '')}. The new name is applied to the fund's transactions and statement history too. <b>Prices are matched by ISIN</b>, so renaming never changes the NAV used.`,
      fields: [
        { key: 'schemeName', label: 'Scheme name', value: f.schemeName, full: true },
        { key: 'amcName', label: 'AMC', value: f.amcName || '', full: true }
      ],
      validate: (v) => v.schemeName.trim() ? null : 'The scheme name cannot be empty.',
      save: (v) => Mf.renameFolio(f.id, { schemeName: v.schemeName.trim(), amcName: v.amcName.trim() })
    });
  }

  document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('editForm');
    if (form) {
      form.addEventListener('submit', submit);
      form.addEventListener('input', refreshVisibility);
      form.addEventListener('change', refreshVisibility);
    }
  });

  return { openEquityTxn, openLot, openHolding, openMfTxn, openFolio };
})();
