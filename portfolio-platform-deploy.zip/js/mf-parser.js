/* mf-parser.js — parses a CDSL Consolidated Account Statement (CAS) PDF, client-side,
   using pdf.js. Extracts:
     - the "Mutual Fund Units Held As On <date>" valuation summary table (source of truth
       for which folios exist — CDSL omits folios with zero activity from the ledger below)
     - the per-folio SIP/purchase/redemption transaction ledger, where present
   Output is designed to be shown in a review UI before anything is committed.
*/

const MfParser = (() => {

  const ISIN_RE = /[A-Z]{2}[A-Z0-9]{9}\d/;
  const ISIN_RE_G = /[A-Z]{2}[A-Z0-9]{9}\d/g;
  const DATE_RE = /^(\d{2}-\d{2}-\d{4})\b/;
  const NUM_TOKEN_RE = /^-?(?:[\d,]+\.?\d*|\.\d+)$/;

  const BOILERPLATE_RES = [
    /^Central Depository Services/i,
    /^A Wing, 25th Floor/i,
    /^Lower Parel/i,
    /^Page \d+ of \d+/i,
    /^CONSOLIDATED ACCOUNT STATEMENT/i,
    /^FORM AND INVESTMENTS IN MUTUAL FUNDS$/i,
    /^Summary of\s*$/i,
    /^Account Details/i,
    /^Investments\s+Account Details/i,
    /^MF Details\s+Notes\s+About CDSL/i,
    /^CDSL Demat\s+NSDL Demat/i
  ];
  // The account holder's name is printed at the top of every page. Rather than hard-coding one
  // name, it is detected per statement: the most frequent short all-caps line.
  let holderName = null;
  function detectHolderName(lines) {
    const counts = {};
    for (const l of lines) {
      const t = l.trim();
      if (/^[A-Z][A-Z.]+( [A-Z][A-Z.]+){1,3}$/.test(t)) counts[t] = (counts[t] || 0) + 1;
    }
    const best = Object.entries(counts).sort((a, b) => b[1] - a[1])[0];
    return best && best[1] >= 8 ? best[0] : null;
  }

  function isBoilerplate(line) {
    const t = line.trim();
    if (!t) return true;
    if (holderName && t.toUpperCase() === holderName) return true;
    return BOILERPLATE_RES.some(re => re.test(t));
  }

  /* ---------- 1. Load PDF + reconstruct text lines from real glyph positions ---------- */
  // Every distinct pdf.js text item is treated as its own token, always space-separated —
  // gap-based joining is unreliable in this document (adjacent right-aligned number columns
  // can sit with near-zero visual gap). Non-Latin (bilingual Hindi) duplicate text, rendered
  // at the same coordinates as its English twin, is dropped entirely.
  async function loadLines(arrayBuffer, password) {
    const loadingTask = pdfjsLib.getDocument({ data: arrayBuffer, password });
    const pdf = await loadingTask.promise;
    const allLines = [];

    for (let p = 1; p <= pdf.numPages; p++) {
      const page = await pdf.getPage(p);
      const content = await page.getTextContent();
      // Soft hyphens (U+00AD) mark where CDSL wrapped a long folio number across two lines.
      // They must be stripped, not filtered out with the non-Latin text — dropping the whole
      // item silently truncated wrapped folio numbers (e.g. "1041121688/0" became "8/0").
      const items = content.items
        .map(it => ({ it, s: (it.str || '').replace(/­/g, '') }))
        .filter(({ s }) => s.trim().length && /^[\x00-\x7F₹`]*$/.test(s))
        .map(({ it, s }) => ({ str: s.trim(), x: it.transform[4], y: Math.round(it.transform[5] * 2) / 2 }));

      items.sort((a, b) => b.y - a.y || a.x - b.x);
      const lines = [];
      let cur = null;
      const TOL = 2.5;
      for (const it of items) {
        if (!cur || Math.abs(cur.y - it.y) > TOL) {
          cur = { y: it.y, items: [] };
          lines.push(cur);
        }
        cur.items.push(it);
      }
      for (const line of lines) {
        line.items.sort((a, b) => a.x - b.x);
        const clean = line.items.map(it => it.str).join(' ').replace(/\s+/g, ' ').trim();
        if (clean) allLines.push(clean);
      }
    }
    return allLines;
  }

  function num(s) { return s == null || s === '' ? null : parseFloat(String(s).replace(/,/g, '')); }
  function toIsoDate(ddmmyyyy) {
    if (!ddmmyyyy) return null;
    const m = ddmmyyyy.match(/(\d{2})-(\d{2})-(\d{4})/);
    return m ? `${m[3]}-${m[2]}-${m[1]}` : null;
  }

  /* ---------- 2. Transaction ledger (per folio/scheme, only where CDSL printed activity) ---------- */
  function extractTransactionLedger(lines) {
    const startIdx = lines.findIndex(l => /MUTUAL FUND UNITS HELD WITH MF\/RTA/i.test(l));
    const endIdx = lines.findIndex(l => /MUTUAL FUND UNITS HELD AS ON/i.test(l));
    if (startIdx === -1) return [];
    const section = lines.slice(startIdx, endIdx === -1 ? lines.length : endIdx).filter(l => !isBoilerplate(l));

    const schemes = [];
    let cur = null;
    let pendingSchemeName = null;
    let pendingAmc = null;

    for (let i = 0; i < section.length; i++) {
      const line = section[i];

      if (/Mutual Fund$/.test(line) && line.length < 60 && !/ISIN|Scheme/i.test(line)) { pendingAmc = line.trim(); continue; }

      const isinMatch = line.match(/^ISIN\s*:\s*([A-Z0-9]+)(?:\s+UCC\s*:\s*(\S*))?/i);
      if (isinMatch) {
        cur = {
          amcName: pendingAmc || '',
          schemeName: pendingSchemeName || '',
          isin: isinMatch[1],
          ucc: isinMatch[2] || '',
          openingBalance: null,
          closingBalance: null,
          transactions: []
        };
        schemes.push(cur);
        pendingSchemeName = null;
        continue;
      }

      // Candidate scheme-name line: the line immediately preceding "ISIN :"
      if (section[i + 1] && /^ISIN\s*:/.test(section[i + 1])) { pendingSchemeName = line; continue; }

      if (!cur) continue;

      const obMatch = line.match(/^Opening Balance\s+([\d,]+\.?\d*)/i);
      if (obMatch) { cur.openingBalance = num(obMatch[1]); continue; }

      const cbMatch = line.match(/^Closing Balance\s+([\d,]+\.?\d*)/i);
      if (cbMatch) { cur.closingBalance = num(cbMatch[1]); continue; }

      if (DATE_RE.test(line)) {
        const tokens = line.split(' ');
        const dateTok = tokens[0];
        const tail = tokens.slice(1);
        if (tail.length >= 7) {
          const last7 = tail.slice(-7);
          if (last7.every(t => NUM_TOKEN_RE.test(t))) {
            const desc = tail.slice(0, -7).join(' ');
            const [amount, nav, price, units, stampDuty, incomeDist, capWithdrawal] = last7.map(num);
            // CDSL prints a unique transaction reference number on its own line right after the row —
            // capture it for reliable dedup when the same period reappears in a later monthly statement.
            let reference = null;
            if (section[i + 1] && /^\d{5,}$/.test(section[i + 1].trim())) { reference = section[i + 1].trim(); i++; }

            cur.transactions.push({
              date: toIsoDate(dateTok),
              description: desc.trim(),
              reference,
              amount, nav, price, units, stampDuty,
              incomeDistribution: incomeDist,
              capitalWithdrawal: capWithdrawal,
              // A redemption prints negative units/amount (its Capital Withdrawal column stays 0).
              type: (units < 0 || amount < 0 || capWithdrawal > 0) ? 'redemption' : 'purchase'
            });
          }
        }
      }
    }
    return schemes;
  }

  /* ---------- 3. Valuation summary table ("Mutual Fund Units Held As On ...") ---------- */
  // The table's Scheme Name / Folio No columns are visually taller than the numeric columns,
  // so their wrapped overflow spills onto lines that sit BELOW the row's own numeric line but
  // ABOVE the next row's ISIN. A single sequential cursor over the flattened token stream —
  // consume leading name tokens, then ISIN, then folio/ARN, then exactly 9 numbers, then any
  // trailing overflow up to the next ISIN — reconstructs each row correctly regardless of how
  // the wrapping fell. Repeated per-page column headers are stripped via a vocabulary filter
  // before tokenizing, since they'd otherwise be swept in as overflow text.
  const HEADER_VOCAB = new Set([
    'average', 'total', 'gross', 'expense', 'ratio', 'commission', 'unreal', 'unrealised', 'ised',
    'cumulative', 'closing', 'ter', 'in', '%', 'terms', 'paid', 'to', 'amount', 'scheme', 'name',
    'isin', 'folio', 'no', 'arn', 'code', 'bal', 'nav', 'valuation', 'distributors', 'profit',
    'profit/', 'loss', 'invested', 'units', 'absolute', 'inr', 'regular', 'direct', '-'
  ]);
  function isHeaderNoiseLine(line) {
    const toks = line.split(/\s+/).filter(Boolean).map(t => t.toLowerCase().replace(/[().,`]/g, ''));
    if (!toks.length) return true;
    return toks.every(t => t === '' || HEADER_VOCAB.has(t));
  }

  function extractSummaryTable(lines) {
    const startIdx = lines.findIndex(l => /MUTUAL FUND UNITS HELD AS ON/i.test(l));
    if (startIdx === -1) return { asOfDate: null, rows: [], grandTotal: null };
    const asOfMatch = lines[startIdx].match(/AS ON\s+([\d-]+)/i);

    const gtIdx = lines.findIndex((l, i) => i > startIdx && /^Grand Total/i.test(l));
    const stopIdx = gtIdx === -1 ? lines.findIndex((l, i) => i > startIdx && /Load Structures/i.test(l)) : gtIdx;
    const section = lines.slice(startIdx + 1, stopIdx === -1 ? lines.length : stopIdx)
      .filter(l => !isBoilerplate(l) && !isHeaderNoiseLine(l));

    const tokens = section.join(' ').split(/\s+/).filter(Boolean);

    const rows = [];
    let cursor = 0;
    while (cursor < tokens.length) {
      let isinIdx = -1;
      for (let i = cursor; i < tokens.length; i++) { if (ISIN_RE.test(tokens[i])) { isinIdx = i; break; } }
      if (isinIdx === -1) break;

      const leadTokens = tokens.slice(cursor, isinIdx);
      const m = tokens[isinIdx].match(ISIN_RE);
      const isin = m[0];

      let i = isinIdx + 1;
      const folioParts = [];
      while (i < tokens.length && !ISIN_RE.test(tokens[i]) && !/^ARN-?/i.test(tokens[i]) && !NUM_TOKEN_RE.test(tokens[i])) {
        folioParts.push(tokens[i]); i++;
      }
      if (!folioParts.length && i < tokens.length && NUM_TOKEN_RE.test(tokens[i]) && /^ARN-?/i.test(tokens[i + 1] || '')) {
        folioParts.push(tokens[i]); i++;
      }
      let arnCode = '';
      if (i < tokens.length && /^ARN-?$/i.test(tokens[i])) {
        arnCode = tokens[i]; i++;
        if (/-$/.test(arnCode) && tokens[i] && !NUM_TOKEN_RE.test(tokens[i])) { arnCode += tokens[i]; i++; }
      } else if (i < tokens.length && /^ARN-/i.test(tokens[i])) {
        arnCode = tokens[i]; i++;
      }

      const nums = [];
      let scanned = 0;
      while (i < tokens.length && nums.length < 9 && !ISIN_RE.test(tokens[i]) && scanned < 20) {
        if (NUM_TOKEN_RE.test(tokens[i])) nums.push(parseFloat(tokens[i].replace(/,/g, '')));
        i++; scanned++;
      }

      let overflowEnd = i;
      while (overflowEnd < tokens.length && !ISIN_RE.test(tokens[overflowEnd])) overflowEnd++;
      const overflowTokens = tokens.slice(i, overflowEnd);
      const folioContinuation = [];
      const nameOverflow = [];
      overflowTokens.forEach(t => {
        if (/^\d+\/\d+$/.test(t)) folioContinuation.push(t); else nameOverflow.push(t);
      });

      const schemeName = (leadTokens.join(' ') + ' ' + nameOverflow.join(' ')).replace(/\s+/g, ' ').trim();
      const folioNo = folioParts.join('') + folioContinuation.join('');
      const [closingUnits, nav, cumulativeInvested, valuation, terRegular, terDirect, grossCommission, unrealizedAbs, unrealizedPct] = nums;

      rows.push({ schemeName, isin, folioNo, arnCode, closingUnits, nav, cumulativeInvested, valuation, terRegular, terDirect, grossCommission, unrealizedAbs, unrealizedPct });
      cursor = overflowEnd;
    }

    let grandTotal = null;
    if (gtIdx !== -1) {
      const nums = (lines[gtIdx].match(/-?[\d,]+\.\d+/g) || []).map(s => parseFloat(s.replace(/,/g, '')));
      if (nums.length >= 2) grandTotal = { invested: nums[0], valuation: nums[1] };
    }

    return { asOfDate: asOfMatch ? toIsoDate(asOfMatch[1]) : null, rows, grandTotal };
  }

  /* ---------- 3b. MF Folios metadata list — clean scheme name + AMC for every folio,
     including inactive ones (unaffected by the summary table's wrapped-column mess). ---------- */
  function extractFolioMeta(lines) {
    const startIdx = lines.findIndex(l => /^MF Folios/i.test(l));
    const endIdx = lines.findIndex((l, i) => i > startIdx && /STATEMENT OF TRANSACTIONS/i.test(l));
    if (startIdx === -1) return { list: [], byIsin: {} };
    const section = lines.slice(startIdx, endIdx === -1 ? lines.length : endIdx).filter(l => !isBoilerplate(l));
    const list = [];
    const byIsin = {};
    let pendingAmc = '';
    let pendingScheme = '';
    let pendingFolio = '';
    for (const line of section) {
      const amcM = line.match(/^AMC Name\s*:\s*(.+)/i);
      if (amcM) { pendingAmc = amcM[1].trim(); pendingFolio = ''; continue; }
      const schemeM = line.match(/^Scheme Name\s*:\s*(.+?)(?:\s+Scheme Code\s*:.*)?$/i);
      if (schemeM) { pendingScheme = schemeM[1].replace(/\s+Scheme Code\s*:.*/i, '').trim(); continue; }
      const folioM = line.match(/^Folio No\s*:\s*(\S+)/i);
      if (folioM) { pendingFolio = folioM[1]; continue; }
      const isinM = line.match(/ISIN\s*:\s*([A-Z0-9]+)/i);
      if (isinM) {
        const cleanName = pendingScheme.replace(/\s*Scheme Code\s*:\s*\S*/i, '').replace(/\s+/g, ' ').trim();
        const entry = { isin: isinM[1], folioNo: pendingFolio, amcName: pendingAmc, schemeName: cleanName };
        list.push(entry);
        if (!byIsin[isinM[1]]) byIsin[isinM[1]] = entry;
      } else if (pendingScheme && !/^Folio No|^KYC|^Plan$|^Scheme Code\s*:/i.test(line) && line.length < 60) {
        // scheme name continuation line wrapped before "ISIN :" appears
        pendingScheme = (pendingScheme + ' ' + line).replace(/\s+/g, ' ').trim();
      }
    }
    return { list, byIsin };
  }

  // The summary table often prints only a fragment of a wrapped folio number (e.g. "8/0").
  // The "MF Folios" list prints every folio in full, so resolve the fragment against it.
  function resolveFolio(row, metaList) {
    const cands = metaList.filter(m => m.isin === row.isin && m.folioNo);
    const raw = row.folioNo || '';
    const exact = cands.find(c => c.folioNo === raw);
    if (exact) return exact;
    const bySuffix = raw ? cands.filter(c => c.folioNo.endsWith(raw)) : [];
    if (bySuffix.length === 1) return bySuffix[0];
    if (cands.length === 1) return cands[0];
    return null;
  }

  /* ---------- Orchestrator ---------- */
  // Summary table is the source of truth for "which folios exist" (17 rows) — CDSL only
  // prints a per-folio transaction ledger for folios that had activity this period.
  function extractPeriodStart(lines) {
    const line = lines.find(l => /PERIOD FROM\s+\d{2}-\d{2}-\d{4}\s+TO\s+\d{2}-\d{2}-\d{4}/i.test(l));
    if (!line) return null;
    const m = line.match(/PERIOD FROM\s+(\d{2}-\d{2}-\d{4})\s+TO\s+(\d{2}-\d{2}-\d{4})/i);
    return m ? toIsoDate(m[1]) : null;
  }

  async function parse(arrayBuffer, password) {
    const lines = await loadLines(arrayBuffer, password);
    holderName = detectHolderName(lines);
    const ledgerSchemes = extractTransactionLedger(lines);
    const summary = extractSummaryTable(lines);
    const { list: metaList, byIsin: metaByIsin } = extractFolioMeta(lines);
    const periodStart = extractPeriodStart(lines);

    const ledgerByIsin = {};
    ledgerSchemes.forEach(s => { (ledgerByIsin[s.isin] = ledgerByIsin[s.isin] || []).push(s); });

    const schemes = summary.rows.map(row => {
      const candidates = ledgerByIsin[row.isin] || [];
      let ledger = candidates.find(c => c.closingBalance != null && row.closingUnits != null && Math.abs(c.closingBalance - row.closingUnits) < 0.01);
      if (!ledger && candidates.length === 1) ledger = candidates[0];
      if (ledger) candidates.splice(candidates.indexOf(ledger), 1); // don't reuse for a duplicate-ISIN folio

      const meta = resolveFolio(row, metaList) || metaByIsin[row.isin];
      // Unrealised % is recomputed rather than read from the table: CDSL prints it in the
      // last column in FY25-26 statements but prints "Annualised Return" there in FY24-25.
      const pct = row.cumulativeInvested > 0 ? (row.unrealizedAbs / row.cumulativeInvested) * 100 : 0;
      return {
        schemeName: (meta && meta.schemeName) || row.schemeName,
        schemeNameRaw: row.schemeName,
        isin: row.isin,
        folioNo: (meta && meta.folioNo) || row.folioNo,
        arnCode: row.arnCode,
        amcName: (ledger && ledger.amcName) || (meta && meta.amcName) || '',
        closingUnits: row.closingUnits,
        nav: row.nav,
        cumulativeInvested: row.cumulativeInvested,
        valuation: row.valuation,
        terRegular: row.terRegular,
        terDirect: row.terDirect,
        grossCommission: row.grossCommission,
        unrealizedAbs: row.unrealizedAbs,
        unrealizedPct: pct,
        // With no ledger block the folio had no activity all period, so units never changed.
        openingBalance: ledger && ledger.openingBalance != null ? ledger.openingBalance : row.closingUnits,
        transactions: ledger ? ledger.transactions : []
      };
    });

    return { asOfDate: summary.asOfDate, periodStart, schemes, grandTotal: summary.grandTotal };
  }

  return { parse, loadLines, extractTransactionLedger, extractSummaryTable };
})();
