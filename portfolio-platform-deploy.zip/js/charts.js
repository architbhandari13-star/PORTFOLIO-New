/* charts.js — Chart.js configs, styled to match the light/premium theme. */

const Charts = (() => {
  const PALETTE = ['#1f4d36', '#b08a3c', '#5a7f97', '#8a5a44', '#6b6456', '#7a8f6b', '#c99a4a', '#4d6a80'];
  let valueTrendChart = null, allocationChart = null, stcgLtcgChart = null;

  Chart.defaults.font.family = "'Inter', sans-serif";
  Chart.defaults.font.size = 12;
  Chart.defaults.color = '#8a8478';
  Chart.defaults.borderColor = '#eeebe4';
  // a light, quiet tooltip that matches the cards
  Object.assign(Chart.defaults.plugins.tooltip, {
    backgroundColor: '#ffffff', titleColor: '#16140f', bodyColor: '#48433b', borderColor: '#e6e2d9', borderWidth: 1,
    padding: 12, cornerRadius: 12, boxPadding: 5, titleFont: { weight: '600', size: 12.5 }, bodyFont: { size: 12.5 }, usePointStyle: true
  });

  // soft fade under an area line
  function areaGradient(chart) {
    const { ctx, chartArea } = chart;
    if (!chartArea) return 'rgba(47,107,75,0.10)';
    const g = ctx.createLinearGradient(0, chartArea.top, 0, chartArea.bottom);
    g.addColorStop(0, 'rgba(47,107,75,0.24)');
    g.addColorStop(1, 'rgba(47,107,75,0)');
    return g;
  }

  function money(n) { return '₹' + Number(n || 0).toLocaleString('en-IN', { maximumFractionDigits: 0 }); }
  function moneyShort(n) {
    const v = Number(n || 0);
    if (Math.abs(v) >= 1e7) return '₹' + (v / 1e7).toFixed(1) + 'Cr';
    if (Math.abs(v) >= 1e5) return '₹' + (v / 1e5).toFixed(1) + 'L';
    if (Math.abs(v) >= 1e3) return '₹' + (v / 1e3).toFixed(0) + 'k';
    return '₹' + v.toFixed(0);
  }

  // series: [{ label, points: [{date, value}], style: 'area' | 'dashed' | 'line' }]
  // Series can cover different dates (e.g. a reconstructed history plus sparse daily
  // snapshots), so everything is aligned on the union of dates, with gaps bridged.
  function renderValueTrend(canvasId, series) {
    const ctx = document.getElementById(canvasId);
    if (valueTrendChart) valueTrendChart.destroy();
    const labels = [...new Set(series.flatMap(s => s.points.map(p => p.date)))].sort();
    const styles = {
      area: { borderColor: '#1f4d36', backgroundColor: (c) => areaGradient(c.chart), fill: true, borderWidth: 2.4, tension: 0.3 },
      dashed: { borderColor: '#b9b1a1', borderDash: [5, 4], fill: false, borderWidth: 1.6, tension: 0.1 },
      line: { borderColor: '#b08a3c', fill: false, borderWidth: 2.2, tension: 0.3 },
      eq: { borderColor: '#b08a3c', backgroundColor: '#b08a3c', fill: false, borderWidth: 2.4, tension: 0.25 },
      total: { borderColor: '#3a362f', backgroundColor: '#3a362f', fill: false, borderWidth: 1.8, tension: 0.25 },
      // exact figures printed on a CDSL statement: markers only, no line
      stmt: { showLine: false, borderColor: '#16140f', backgroundColor: '#ffffff', borderWidth: 2, pointStyle: 'rectRot', pointRadius: 5.5, pointHoverRadius: 7 }
    };
    valueTrendChart = new Chart(ctx, {
      type: 'line',
      data: {
        labels,
        datasets: series.map(s => {
          const byDate = {};
          s.points.forEach(p => { byDate[p.date] = p.value; });
          // sparse series (statement dates, monthly points) get visible markers; dense ones stay a clean line
          return { label: s.label, data: labels.map(d => (d in byDate ? byDate[d] : null)), spanGaps: true, pointRadius: s.points.length <= 40 ? 3.5 : 0, pointHoverRadius: 5, order: s.style === 'stmt' ? 0 : 1, ...styles[s.style || 'line'] };
        })
      },
      options: {
        responsive: true, maintainAspectRatio: false,
        interaction: { mode: 'index', intersect: false },
        plugins: {
          legend: { display: true, position: 'bottom', align: 'start', labels: { boxWidth: 8, boxHeight: 8, usePointStyle: true, padding: 16, font: { size: 11.5 } } },
          tooltip: { callbacks: { label: (c) => `${c.dataset.label}: ${money(c.raw)}` } }
        },
        scales: {
          x: {
            grid: { display: false }, border: { display: false },
            ticks: {
              maxTicksLimit: 7, padding: 8, maxRotation: 0, autoSkip: true,
              // "2025-07-11" -> "Jul 25"
              callback(v) { const d = new Date(this.getLabelForValue(v) + 'T00:00:00Z'); return isNaN(d) ? '' : d.toLocaleDateString('en-IN', { month: 'short', year: '2-digit', timeZone: 'UTC' }); }
            }
          },
          y: { grid: { color: '#f0ede6' }, border: { display: false }, ticks: { padding: 10, maxTicksLimit: 6, callback: v => moneyShort(v) } }
        }
      }
    });
  }

  function renderAllocation(canvasId, slices) {
    // slices: [{label, value}]
    const ctx = document.getElementById(canvasId);
    if (allocationChart) allocationChart.destroy();
    allocationChart = new Chart(ctx, {
      type: 'doughnut',
      data: {
        labels: slices.map(s => s.label),
        datasets: [{ data: slices.map(s => s.value), backgroundColor: PALETTE, borderColor: '#ffffff', borderWidth: 3, hoverOffset: 5, borderRadius: 4 }]
      },
      options: {
        responsive: true, maintainAspectRatio: false, cutout: '72%',
        plugins: {
          legend: { position: 'bottom', labels: { boxWidth: 10, boxHeight: 10, usePointStyle: true, padding: 12, font: { size: 11.5 } } },
          tooltip: { callbacks: { label: (ctx) => `${ctx.label}: ${money(ctx.raw)}` } }
        }
      }
    });
  }

  function renderStcgLtcg(canvasId, data) {
    // data: {stcg, ltcg}
    const ctx = document.getElementById(canvasId);
    if (stcgLtcgChart) stcgLtcgChart.destroy();
    stcgLtcgChart = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: ['Realized gains'],
        datasets: [
          { label: 'STCG', data: [data.stcg || 0], backgroundColor: '#b08a3c', borderRadius: 8, maxBarThickness: 40 },
          { label: 'LTCG', data: [data.ltcg || 0], backgroundColor: '#1f4d36', borderRadius: 8, maxBarThickness: 40 }
        ]
      },
      options: {
        indexAxis: 'y', responsive: true, maintainAspectRatio: false,
        plugins: { legend: { position: 'bottom', labels: { boxWidth: 10, boxHeight: 10, usePointStyle: true } } },
        scales: { x: { grid: { color: '#f0ede6' }, border: { display: false }, ticks: { callback: v => moneyShort(v) } }, y: { grid: { display: false }, border: { display: false } } }
      }
    });
  }

  return { renderValueTrend, renderAllocation, renderStcgLtcg, money, moneyShort, PALETTE };
})();
