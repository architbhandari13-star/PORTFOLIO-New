/* eq-import.js — the "Import from statements" flow for equity.

     CDSL statements (what is held, and every dated transaction)  +  Stock Details spreadsheet (cost)
       -> events added permanently to a ledger (never replaced; duplicates ignored)
       -> open lots recomputed from the WHOLE ledger with FIFO, each with its real purchase date
       -> tickers resolved from ISIN via TradingView
       -> a review table where everything can be corrected
       -> saved as ordinary `buy` transactions in `equity_transactions`, tagged source:'import'.

   Upload as many statements as you like, in any order, as often as you like: the ledger only
   ever grows, and the position is always rebuilt from all of it. That is what makes a monthly
   upload safe — earlier data is kept and simply extended.

   It sits beside the manual "Add transaction" model rather than replacing it: both write the same
   kind of document, so holdings, FIFO, prices and the transactions list treat imported and
   hand-entered trades identically.

   Cost per share still comes from the books (the CDSL carries no prices). Only shares older than
   the earliest statement uploaded, and shares that arrived by transfer, have no purchase date; those
   carry an *estimated* date (flagged `dateEstimated`) that can be edited here, and XIRR leaves such
   stocks out until it is set. */

const EqImport = (() => {
  const TV_SCAN = 'https://scanner.tradingview.com/india/scan';
  const BROKER_LABELS = [
    [/SMC/i, 'SMC Global'], [/PRABHUDAS/i, 'Prabhudas'], [/IIFL/i, 'IIFL'], [/RELIANCE/i, 'Reliance Securities'],
    [/SUNSHINE/i, 'Sunshine'], [/CHOKSEY/i, 'KR Choksey'], [/KOTAK/i, 'Kotak'], [/KARVY/i, 'Karvy Capital'], [/JOINDRE/i, 'Joindre Capital']
  ];
  const brokerLabel = (dp) => (BROKER_LABELS.find(([re]) => re.test(dp)) || [null, 'Other'])[1];

  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const inr = (n) => '₹' + Number(n || 0).toLocaleString('en-IN', { maximumFractionDigits: 0 });
  const qtyFmt = (n) => Number(n).toLocaleString('en-IN', { maximumFractionDigits: 3 });
  const fmtInt = (n) => Number(n).toLocaleString('en-IN');
  const fmtD = (iso) => new Date(iso + 'T00:00:00Z').toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric', timeZone: 'UTC' });
  const asArray = (x) => x == null ? [] : Array.isArray(x) ? x : [x];
  const chunks = (arr, n) => { const out = []; for (let i = 0; i < arr.length; i += n) out.push(arr.slice(i, i + n)); return out; };
  // Firestore rejects `undefined` field values (browser storage doesn't), so every document is
  // passed through this on its way out — it drops such fields.
  const clean = (o) => JSON.parse(JSON.stringify(o));

  let state = null;

  /* ---------- ticker lookup: ISIN -> NSE/BSE symbol (TradingView, unofficial) ---------- */
  // One request covers many ISINs. No explicit Content-Type: that keeps it a CORS "simple
  // request" (see pricing.js for why).
  async function resolveIsins(isins) {
    const listings = {};
    for (const chunk of chunks([...new Set(isins)], 50)) {
      const res = await fetch(TV_SCAN, {
        method: 'POST',
        body: JSON.stringify({ filter: [{ left: 'isin', operation: 'in_range', right: chunk }], columns: ['name', 'description', 'isin', 'close', 'exchange', 'type'], range: [0, 200] })
      });
      const json = await res.json();
      (json.data || []).forEach(r => {
        const [name, description, isin, close, exchange, type] = r.d;
        if (!['NSE', 'BSE'].includes(exchange) || !['stock', 'fund'].includes(type)) return;
        (listings[isin] = listings[isin] || {})[exchange] = { symbol: name, name: description, close };
      });
    }
    return listings;
  }

  /* ---------- stored state ---------- */
  const lotKeyOf = (row, lot) => `${row.acct}|${row.isin}|${lot.origin}`;

  function snapshotFrom(stmt) {
    const holdings = [], skipped = []; let zero = 0;
    stmt.accounts.forEach(a => a.holdings.forEach(h => {
      const acct = a.boId || a.dp;
      if (!(h.qty > 0)) { zero++; return; }
      const item = { acct, dp: a.dp, isin: h.isin, qty: h.qty, price: h.price, value: h.value, name: h.name, cleanName: h.cleanName, kind: h.kind };
      if (h.kind === 'equity' || h.kind === 'etf') holdings.push(item); else skipped.push(item);
    }));
    return { asOf: stmt.asOfDate, periods: stmt.periods.map(p => ({ acct: p.acct, dp: p.dp, from: p.from, to: p.to })), holdings, skipped, zero,
             monthly: stmt.monthly || [], classes: stmt.classes || null };
  }

  /* ---------- build the review model ---------- */
  async function build(pdfBufs, password, xlsxBufs, setStatus) {
    // 1) read every uploaded statement
    const stmts = [];
    for (let i = 0; i < pdfBufs.length; i++) {
      setStatus(`Reading statement ${i + 1} of ${pdfBufs.length}…`);
      stmts.push(await EqParser.parseCdslFull(pdfBufs[i], password));
    }
    const newSnaps = stmts.map(snapshotFrom);
    const newEvents = stmts.flatMap(s => s.events);

    // 2) what was uploaded before
    setStatus('Loading earlier uploads…');
    const [storedDocs, storedSnaps, storedCosts, storedTxns] = await Promise.all([
      DB.getAll('equity_ledger'), DB.getAll('equity_snapshots'), DB.getAll('equity_costs'), Equity.getAllTransactions()
    ]);

    // 3) merge: the ledger only ever grows; identical events are ignored
    const merged = EqLedger.mergeIntoDocs(storedDocs, newEvents);
    const changedIds = new Set(merged.docs.map(d => d.id));
    const allDocs = [...storedDocs.filter(d => !changedIds.has(d.id)), ...merged.docs];
    const snapMap = new Map(storedSnaps.map(s => [s.asOf, s]));
    newSnaps.forEach(s => snapMap.set(s.asOf, s));
    const allSnaps = [...snapMap.values()];

    // 4) open lots from the whole ledger
    const calc = EqLedger.compute(allDocs, allSnaps);
    const latest = calc.latest;
    const posByKey = new Map(calc.positions.map(p => [p.acct + '|' + p.isin, p]));

    // 5) cost source: the spreadsheet whose period ends latest
    let books = null, booksNote = '';
    if (xlsxBufs.length) {
      setStatus('Reading the Stock Details spreadsheet…');
      const parsed = [];
      for (const b of xlsxBufs) parsed.push(await EqParser.parseStockSummary(b));
      const endOf = (p) => { const d = p.period && parseBooksDate(p.period.to); return d ? d.getTime() : 0; };
      parsed.sort((a, b) => endOf(b) - endOf(a));
      books = parsed[0];
      if (parsed.length > 1) booksNote = `Cost is taken from the spreadsheet covering the latest period (${books.period ? books.period.from + ' to ' + books.period.to : '?'}); the other ${parsed.length - 1} ${parsed.length > 2 ? 'were' : 'was'} not needed.`;
    }

    // 6) rows
    const held = latest.holdings.map(h => ({ ...h, broker: brokerLabel(h.dp) }));
    const matches = books ? EqParser.matchCosts(held, books.rows) : new Map();
    setStatus('Looking up tickers…');
    let listings = {}, tvError = null;
    try { listings = await resolveIsins(held.map(h => h.isin)); } catch (e) { tvError = e; }

    const costsByKey = new Map(storedCosts.map(c => [c.acct + '|' + c.isin, c]));
    // real dates the owner entered on earlier imports survive a rebuild
    const editedDates = new Map(storedTxns.filter(t => t.source === 'import' && t.dateEdited && t.lotKey).map(t => [t.lotKey, t.date]));
    // ... and so does a cost the owner set for one particular lot
    const editedPrices = new Map(storedTxns.filter(t => t.source === 'import' && t.priceEdited && t.lotKey).map(t => [t.lotKey, t.price]));

    const rows = held.map(h => {
      const key = h.acct + '|' + h.isin;
      const pos = posByKey.get(key);
      const m = matches.get(h) || null;
      const st = costsByKey.get(key) || null;
      const ls = listings[h.isin] || {};
      // A ticker the owner corrected (Edit, or in an earlier review) beats TradingView's lookup.
      const keepTicker = !!(st && st.tickerEdited && st.symbol);
      const exchange = keepTicker ? st.exchange : (ls.NSE ? 'NSE' : (ls.BSE ? 'BSE' : (st && st.exchange) || 'NSE'));
      const listing = ls[exchange] || null;
      const row = {
        i: 0, acct: h.acct, isin: h.isin, broker: h.broker, dp: h.dp, kind: h.kind, cleanName: h.cleanName, qty: h.qty, statementPrice: h.price,
        listings: ls, exchange, symbol: keepTicker ? st.symbol : (listing ? listing.symbol : ((st && st.symbol) || '')),
        companyName: keepTicker ? (st.companyName || h.cleanName) : (listing ? listing.name : ((st && st.companyName) || h.cleanName)),
        livePrice: listing ? listing.close : null,
        tickerEdited: keepTicker, rateEdited: !!(st && st.rateEdited && st.rate > 0),
        match: m, booksRow: m ? m.row : null, rate: null, costSource: 'statement price',
        include: false, lots: (pos ? pos.lots : []).map(l => ({ ...l }))
      };
      // real dates entered on earlier imports survive the rebuild (any lot, not only the flagged ones)
      row.lots.forEach(l => {
        const k = lotKeyOf(row, l), ed = editedDates.get(k), ep = editedPrices.get(k);
        if (ed) { l.date = ed; l.userDate = true; }
        if (ep != null) l.userPrice = ep;
      });
      if (row.rateEdited) { row.rate = st.rate; row.costSource = 'entered'; }      // a cost the owner set beats the books
      else if (row.booksRow) { row.rate = EqParser.costRate(row.booksRow); row.costSource = 'books'; }
      else if (st && st.rate > 0) { row.rate = st.rate; row.costSource = st.costSource || 'entered'; }
      row.include = st ? !!st.include && !!row.symbol : !!row.symbol;
      return row;
    });
    rows.sort((a, b) => b.qty * b.statementPrice - a.qty * a.statementPrice);
    rows.forEach((r, k) => { r.i = k; });   // the table addresses rows by this index, so number them after sorting

    const usedRows = new Set(rows.map(r => r.booksRow).filter(Boolean));
    const booksLeft = books ? books.rows.filter(r => r.closing.qty !== 0 && !usedRows.has(r)) : [];

    const earliest = allSnaps.flatMap(s => s.periods || []).map(p => p.from).sort()[0] || null;
    state = {
      asOf: latest.asOf, period: books && books.period, rows, skipped: latest.skipped || [], zero: latest.zero || 0, booksLeft, books,
      warnings: calc.warnings, tvError, hasBooks: !!books, booksNote,
      pending: { docs: merged.docs, added: merged.added, snaps: newSnaps },
      ledger: { earliest, statements: allSnaps.length, newEvents: merged.added, totalEvents: allDocs.reduce((s, d) => s + d.events.length, 0) },
      storedCount: storedTxns.filter(t => t.source === 'import').length
    };
    return state;
  }

  // "1-Apr-25" / "31-Mar-2026" from the spreadsheet header
  const MONTHS = { jan: 0, feb: 1, mar: 2, apr: 3, may: 4, jun: 5, jul: 6, aug: 7, sep: 8, oct: 9, nov: 10, dec: 11 };
  function parseBooksDate(s) {
    const m = /^(\d{1,2})-([A-Za-z]{3})-(\d{2,4})$/.exec(String(s || '').trim());
    if (!m) return null;
    return new Date(Date.UTC(m[3].length === 2 ? 2000 + +m[3] : +m[3], MONTHS[m[2].toLowerCase()], +m[1]));
  }

  const effectiveRate = (row) => (row.rate != null && row.rate > 0) ? row.rate : row.statementPrice;
  // a lot's own cost (set by the owner via Edit) beats the stock's average
  const lotPrice = (row, l) => (l.userPrice != null ? l.userPrice : effectiveRate(row));
  const rowCost = (row) => row.lots.reduce((s, l) => s + l.qty * lotPrice(row, l), 0);
  const isFlagged = (l) => (l.undated || l.transfer) && !l.userDate;
  const needsDate = (l) => l.undated || l.transfer;

  /* ---------- review table ---------- */
  function booksOptions(row) {
    const b = state.books;
    if (!b) return '<option value="">—</option>';
    const used = new Set(state.rows.filter(r => r !== row && r.booksRow).map(r => r.booksRow));
    const opts = b.rows.filter(r => r.closing.qty || r.opening.qty || r.inwards.qty)
      .sort((x, y) => x.name.localeCompare(y.name))
      .map(r => `<option value="${r.rowNo}" ${row.booksRow === r ? 'selected' : ''}>${esc(r.name)} — ${qtyFmt(r.closing.qty)} @ ${r.closing.rate.toFixed(2)}${used.has(r) ? ' (used)' : ''}</option>`);
    return `<option value="">— no cost in books —</option>${opts.join('')}`;
  }

  function confidenceTag(row) {
    if (!row.match || row.booksRow !== row.match.row) return row.booksRow ? '<span class="tag tag-eq">chosen</span>' : '';
    if (row.match.confidence === 'high') return '<span class="tag tag-buy" title="' + esc(row.match.reason) + '">matched</span>';
    return '<span class="tag tag-warn" title="' + esc(row.match.reason) + '">check</span>';
  }

  // Dated lots are shown as a summary; only the lots with no purchase date get an input.
  function lotCell(row) {
    const dated = row.lots.filter(l => !needsDate(l));
    const flagged = row.lots.filter(needsDate);
    const parts = [];
    if (dated.length) {
      const ds = dated.map(l => l.date).sort();
      const tip = dated.map(l => `${qtyFmt(l.qty)} on ${fmtD(l.date)}`).join('\n');
      parts.push(`<div class="lot-summary" title="${esc(tip)}"><span class="tag tag-buy">${fmtInt(dated.length)} dated lot${dated.length > 1 ? 's' : ''}</span> <span class="cell-sub">${fmtD(ds[0])}${ds.length > 1 ? ' → ' + fmtD(ds[ds.length - 1]) : ''}</span></div>`);
    }
    flagged.forEach(l => {
      const k = row.lots.indexOf(l);
      const label = l.transfer ? 'transferred in — set real date' : `older than ${fmtD(state.ledger.earliest)}`;
      parts.push(`<div class="lot-line"><span class="lot-qty">${qtyFmt(l.qty)}</span><input type="date" data-lot="${row.i}|${k}" value="${l.date}"><span class="cell-sub ${l.userDate ? '' : 'warn-text'}">${l.userDate ? 'date set' : label}</span></div>`);
    });
    return parts.join('') || '<span class="cell-sub">—</span>';
  }

  function renderTable() {
    const table = document.getElementById('eqImpTable');
    table.innerHTML = `
      <thead><tr><th></th><th>Security</th><th>Ticker</th><th>Qty</th><th>Cost source (your books)</th><th>Avg cost / share</th><th>Purchase dates</th><th>Cost</th><th>Value now</th></tr></thead>
      <tbody>${state.rows.map(row => `
        <tr data-row="${row.i}" class="${row.include ? '' : 'row-off'}">
          <td><input type="checkbox" data-inc="${row.i}" ${row.include ? 'checked' : ''}></td>
          <td><div class="cell-name">${esc(row.cleanName)}</div><div class="cell-sub">${esc(row.isin)} · ${esc(row.broker)}${row.kind === 'etf' ? ' · ETF' : ''}</div></td>
          <td>
            <div class="tick">
              <select data-exch="${row.i}"><option ${row.exchange === 'NSE' ? 'selected' : ''}>NSE</option><option ${row.exchange === 'BSE' ? 'selected' : ''}>BSE</option></select>
              <input type="text" data-sym="${row.i}" value="${esc(row.symbol)}" placeholder="symbol" spellcheck="false">
            </div>
            <div class="cell-sub" data-sym-note="${row.i}">${row.symbol ? esc(row.companyName) : '<span class="warn-text">not found — type the symbol</span>'}</div>
          </td>
          <td class="num">${qtyFmt(row.qty)}</td>
          <td><select class="books-sel" data-books="${row.i}">${booksOptions(row)}</select><div class="cell-sub" data-conf="${row.i}">${confidenceTag(row)} ${row.match && row.booksRow === row.match.row && row.match.confidence !== 'high' ? esc(row.match.reason) : ''}</div></td>
          <td><input class="rate-in" type="number" step="any" min="0" data-rate="${row.i}" value="${row.rate != null ? row.rate : ''}" placeholder="${row.statementPrice}"><div class="cell-sub" data-rate-note="${row.i}">${row.rate == null ? 'statement price used' : ''}</div></td>
          <td data-lots="${row.i}">${lotCell(row)}</td>
          <td class="num" data-cost="${row.i}"></td>
          <td class="num" data-val="${row.i}"></td>
        </tr>`).join('')}</tbody>`;
    state.rows.forEach(updateRowNumbers);
    updateSummary();
  }

  function updateRowNumbers(row) {
    const cost = document.querySelector(`[data-cost="${row.i}"]`), val = document.querySelector(`[data-val="${row.i}"]`);
    if (cost) cost.textContent = inr(rowCost(row));
    if (val) val.textContent = inr(row.qty * (row.livePrice || row.statementPrice));
    const tr = document.querySelector(`tr[data-row="${row.i}"]`);
    if (tr) tr.classList.toggle('row-off', !row.include);
  }

  function updateSummary() {
    const sel = state.rows.filter(r => r.include);
    const cost = sel.reduce((s, r) => s + rowCost(r), 0);
    const val = sel.reduce((s, r) => s + r.qty * (r.livePrice || r.statementPrice), 0);
    const fromBooks = sel.filter(r => r.booksRow).reduce((s, r) => s + rowCost(r), 0);
    const noBooks = sel.filter(r => !r.booksRow && !(r.rate > 0)).length;
    const gain = val - cost;
    // share of the selected value whose every lot has a real date (that is what XIRR can use)
    const datedVal = sel.filter(r => r.lots.every(l => !isFlagged(l))).reduce((s, r) => s + r.qty * (r.livePrice || r.statementPrice), 0);
    document.getElementById('eqImpStats').innerHTML = [
      `<div class="imp-stat"><span>Selected</span><b>${sel.length} of ${state.rows.length}</b></div>`,
      `<div class="imp-stat"><span>Cost</span><b>${inr(cost)}</b></div>`,
      `<div class="imp-stat"><span>Value now</span><b>${inr(val)}</b></div>`,
      `<div class="imp-stat"><span>Unrealized</span><b class="${gain >= 0 ? 'pos' : 'neg'}">${inr(gain)}</b></div>`,
      `<div class="imp-stat"><span>Real purchase dates</span><b>${val > 0 ? Math.round(100 * datedVal / val) : 0}% of value</b></div>`
    ].join('');

    const L = state.ledger, info = [];
    info.push(`Latest statement <b>${fmtD(state.asOf)}</b> · history kept from <b>${L.earliest ? fmtD(L.earliest) : '—'}</b> across <b>${L.statements}</b> statement${L.statements > 1 ? 's' : ''} · ${fmtInt(L.newEvents)} new transaction${L.newEvents === 1 ? '' : 's'} added${L.totalEvents - L.newEvents > 0 ? `, ${fmtInt(L.totalEvents - L.newEvents)} already known` : ''}.`);
    if (state.hasBooks) info.push(`Books: ${esc(state.period ? state.period.from + ' to ' + state.period.to : '')}. Cost taken from your books for ${fmtInt(sel.length - noBooks)} selected positions (${inr(fromBooks)}).${state.booksNote ? ' ' + esc(state.booksNote) : ''}`);
    else info.push('No spreadsheet supplied — positions use their previously saved cost, or the statement price where there is none (profit/loss then starts from zero at the statement date).');
    if (noBooks) info.push(`<span class="warn-text">${noBooks} selected position${noBooks > 1 ? 's have' : ' has'} no cost — the statement price on ${esc(state.asOf)} is used. You can type a cost instead.</span>`);
    if (state.tvError) info.push('<span class="warn-text">Could not reach TradingView to look up tickers — type them in by hand.</span>');
    state.warnings.slice(0, 6).forEach(w => info.push(`<span class="warn-text">${esc(w)}</span>`));
    document.getElementById('eqImpInfo').innerHTML = info.map(t => `<p>${t}</p>`).join('');
  }

  function renderNotes() {
    const el = document.getElementById('eqImpNotes');
    const parts = [];
    const sk = state.skipped;
    if (sk.length) {
      const total = sk.reduce((s, h) => s + h.value, 0);
      parts.push(`<details><summary>${sk.length} non-equity holding${sk.length > 1 ? 's' : ''} left out (${inr(total)}) — bonds, gold bonds, mutual funds, rights</summary>
        <div class="table-wrap"><table class="data-table compact"><tbody>${sk.map(h => `<tr><td>${esc(h.cleanName || h.name)}</td><td class="cell-sub">${esc(h.isin)} · ${esc(h.kind)}</td><td>${esc(brokerLabel(h.dp))}</td><td class="num">${qtyFmt(h.qty)}</td><td class="num">${inr(h.value)}</td></tr>`).join('')}</tbody></table></div></details>`);
    }
    if (state.booksLeft.length) {
      parts.push(`<details><summary>${state.booksLeft.length} row${state.booksLeft.length > 1 ? 's' : ''} in your books not matched to any holding</summary>
        <div class="table-wrap"><table class="data-table compact"><tbody>${state.booksLeft.map(r => `<tr><td>${esc(r.name)}</td><td class="num">${qtyFmt(r.closing.qty)} @ ${r.closing.rate.toFixed(2)}</td><td class="num">${inr(r.closing.value)}</td></tr>`).join('')}</tbody></table></div>
        <p class="cell-sub">Gold bonds and stray entries usually. A row you do want can be picked in the "Cost source" column of the matching holding.</p></details>`);
    }
    if (state.zero) parts.push(`<p class="cell-sub">${state.zero} zero-balance entries on the statement (old ISINs, expired rights) were ignored.</p>`);
    el.innerHTML = parts.join('');
  }

  async function conflictNote() {
    // Manual trades dated on/before the statement date are already reflected in a position that
    // is "as at" that date — importing on top would count them twice.
    const existing = await Equity.getAllTransactions();
    const symbols = new Set(state.rows.filter(r => r.include && r.symbol).map(r => r.symbol + ':' + r.exchange));
    const isins = new Set(state.rows.map(r => r.isin));
    const clash = existing.filter(t => t.source !== 'import' && t.date <= state.asOf && (isins.has(t.isin) || symbols.has(t.symbol + ':' + t.exchange)));
    document.getElementById('eqImpConflict').innerHTML = clash.length
      ? `<p class="warn-text">${clash.length} manually-entered transaction${clash.length > 1 ? 's' : ''} dated on or before ${esc(state.asOf)} already exist for stocks in this import. The statements already include their effect, so they would be counted twice — delete them from the Transactions tab after saving (or untick those stocks here).</p>`
      : '';
  }

  /* ---------- events ---------- */
  function onTableInput(e) {
    const t = e.target;
    const get = (attr) => state.rows[+t.getAttribute(attr).split('|')[0]];
    if (t.hasAttribute('data-inc')) { const r = get('data-inc'); r.include = t.checked; updateRowNumbers(r); updateSummary(); conflictNote(); }
    else if (t.hasAttribute('data-sym')) {
      const r = get('data-sym'); r.symbol = t.value.trim().toUpperCase(); r.include = r.include || !!r.symbol; r.tickerEdited = !!r.symbol;
      const note = document.querySelector(`[data-sym-note="${r.i}"]`);
      if (note) note.innerHTML = r.symbol ? esc(r.listings[r.exchange] && r.listings[r.exchange].symbol === r.symbol ? r.companyName : '') : '<span class="warn-text">not found — type the symbol</span>';
      const cb = document.querySelector(`[data-inc="${r.i}"]`); if (cb) cb.checked = r.include;
      updateRowNumbers(r); updateSummary();
    }
    else if (t.hasAttribute('data-exch')) {
      const r = get('data-exch'); r.exchange = t.value; r.tickerEdited = true;
      const l = r.listings[r.exchange];
      if (l) { r.symbol = l.symbol; r.companyName = l.name; r.livePrice = l.close; const inp = document.querySelector(`[data-sym="${r.i}"]`); if (inp) inp.value = l.symbol; }
      updateRowNumbers(r);
    }
    else if (t.hasAttribute('data-books')) {
      const r = get('data-books');
      r.booksRow = t.value ? state.books.rows.find(b => String(b.rowNo) === t.value) : null;
      r.match = r.match && r.match.row === r.booksRow ? r.match : null;
      r.rate = r.booksRow ? EqParser.costRate(r.booksRow) : null;
      r.rateEdited = false;
      r.costSource = r.booksRow ? 'books' : 'statement price';
      document.querySelector(`[data-rate="${r.i}"]`).value = r.rate != null ? r.rate : '';
      document.querySelector(`[data-rate-note="${r.i}"]`).textContent = r.rate == null ? 'statement price used' : '';
      document.querySelector(`[data-conf="${r.i}"]`).innerHTML = confidenceTag(r);
      updateRowNumbers(r); updateSummary();
    }
    else if (t.hasAttribute('data-rate')) {
      const r = get('data-rate'); const v = parseFloat(t.value);
      r.rate = isNaN(v) || v <= 0 ? null : v;
      r.rateEdited = !!r.rate;
      if (!r.booksRow) r.costSource = r.rate ? 'entered' : 'statement price';
      document.querySelector(`[data-rate-note="${r.i}"]`).textContent = r.rate == null ? 'statement price used' : '';
      updateRowNumbers(r); updateSummary();
    }
    else if (t.hasAttribute('data-lot')) {
      const [ri, k] = t.getAttribute('data-lot').split('|').map(Number);
      const lot = state.rows[ri].lots[k];
      if (/^\d{4}-\d{2}-\d{2}$/.test(t.value)) {
        lot.date = t.value; lot.userDate = true;
        const note = t.nextElementSibling;
        if (note) { note.textContent = 'date set'; note.classList.remove('warn-text'); }
      }
      updateSummary();
    }
  }

  /* ---------- save ---------- */
  async function save() {
    const status = document.getElementById('eqImpStatus2');
    const btn = document.getElementById('eqImpSaveBtn');
    const chosen = state.rows.filter(r => r.include);
    const bad = chosen.filter(r => !r.symbol);
    if (bad.length) { status.textContent = `${bad.length} selected position${bad.length > 1 ? 's need' : ' needs'} a ticker — type it in or untick the row.`; status.className = 'status-line error'; return; }
    if (!chosen.length) { status.textContent = 'Nothing is selected.'; status.className = 'status-line error'; return; }
    if (chosen.some(r => r.lots.some(l => !/^\d{4}-\d{2}-\d{2}$/.test(l.date)))) { status.textContent = 'Every lot needs a valid purchase date.'; status.className = 'status-line error'; return; }

    btn.disabled = true;
    try {
      const now = new Date().toISOString();
      // 1) history first — it is permanent, and everything else can be rebuilt from it
      status.textContent = 'Saving statement history…'; status.className = 'status-line';
      const P = state.pending;
      for (const c of chunks(P.docs, 10)) await Promise.all(c.map(d => { const { id, ...rest } = d; return DB.setDoc('equity_ledger', id, clean(rest)); }));
      for (const s of P.snaps) await DB.setDoc('equity_snapshots', s.asOf, clean(s));
      // 2) the choices made in the review table (tickers, costs, which rows are in)
      const costDocs = state.rows.map(r => ({ id: 'C' + EqLedger.hash(r.acct + '|' + r.isin), doc: {
        acct: r.acct, isin: r.isin, dp: r.dp, symbol: r.symbol || null, exchange: r.exchange, companyName: r.companyName || r.cleanName,
        rate: r.rate, costSource: r.booksRow && !r.rateEdited ? 'books' : (r.rate ? 'entered' : 'statement price'),
        tickerEdited: !!r.tickerEdited, rateEdited: !!r.rateEdited, include: !!r.include, updatedAt: now } }));
      for (const c of chunks(costDocs, 10)) await Promise.all(c.map(x => DB.setDoc('equity_costs', x.id, clean(x.doc))));
      // 3) rebuild the imported transactions from the whole ledger (manual ones are never touched)
      status.textContent = 'Rebuilding positions…';
      const old = (await Equity.getAllTransactions()).filter(t => t.source === 'import');
      for (const c of chunks(old, 10)) await Promise.all(c.map(t => Equity.deleteTransaction(t.id)));
      const docs = [];
      chosen.forEach(r => r.lots.forEach(l => { if (l.qty > 1e-9) docs.push({
        type: 'buy', symbol: r.symbol, exchange: r.exchange, companyName: r.companyName || r.cleanName,
        qty: l.qty, price: Math.round(lotPrice(r, l) * 10000) / 10000, date: l.date, broker: r.broker, isin: r.isin,
        charges: { brokerage: 0, stt: 0, other: 0 },
        source: 'import', costSource: l.userPrice != null ? 'entered' : (r.booksRow && !r.rateEdited ? 'books' : (r.rate ? 'entered' : 'statement price')),
        priceEdited: l.userPrice != null,
        dateEstimated: needsDate(l) && !l.userDate, dateEdited: !!l.userDate,
        dateNote: l.transfer ? 'transferred in' : (l.undated ? 'older than the statements' : null),
        lotKey: lotKeyOf(r, l), statementDate: state.asOf, importedAt: now
      }); }));
      for (const c of chunks(docs, 10)) {
        status.textContent = `Saving ${docs.indexOf(c[0]) + c.length} of ${docs.length}…`;
        await Promise.all(c.map(d => Equity.addTransaction(clean(d))));
      }
      status.textContent = 'Fetching live prices…';
      try { await Pricing.refreshEquityPrices(await Equity.computeHoldings()); } catch (e) { /* prices refresh on the next visit anyway */ }
      // The holdings this import produced are different from whatever the Overview's cached chart
      // was built against — mark it stale so the next load rebuilds instead of showing old data.
      await EqHistory.bumpGeneration();
      status.textContent = `Saved ${chosen.length} positions (${docs.length} lots). ${P.added ? fmtInt(P.added) + ' new transactions added to your history.' : 'History was already up to date.'}`;
      status.className = 'status-line ok';
      setTimeout(() => { document.getElementById('eqImportModal').hidden = true; App.refreshCurrentView(); }, 1100);
    } catch (err) {
      status.textContent = 'Error: ' + err.message; status.className = 'status-line error';
    }
    btn.disabled = false;
  }

  /* ---------- entry points ---------- */
  function open() {
    state = null;
    document.getElementById('eqImpStep1').hidden = false;
    document.getElementById('eqImpStep2').hidden = true;
    document.getElementById('eqImpStatus1').textContent = '';
    document.getElementById('eqImportModal').hidden = false;
  }

  // Also the test hook: the same path the file inputs use, minus the file dialog.
  async function loadBuffers(pdfBufs, password, xlsxBufs) {
    const status = document.getElementById('eqImpStatus1');
    const setStatus = (t) => { status.textContent = t; status.className = 'status-line'; };
    try {
      await build(asArray(pdfBufs), password, asArray(xlsxBufs), setStatus);
      document.getElementById('eqImpStep1').hidden = true;
      document.getElementById('eqImpStep2').hidden = false;
      document.getElementById('eqImpStatus2').textContent = '';
      renderTable(); renderNotes(); await conflictNote();
    } catch (err) {
      const msg = /password/i.test(err.message || err.name || '') ? 'Wrong or missing PDF password.' : (err.message || String(err));
      status.textContent = msg; status.className = 'status-line error';
    }
  }

  async function readFiles() {
    const pdfs = [...document.getElementById('eqImpPdf').files];
    const xlsx = [...document.getElementById('eqImpXlsx').files];
    const status = document.getElementById('eqImpStatus1');
    if (!pdfs.length) { status.textContent = 'Choose at least one CDSL statement PDF first.'; status.className = 'status-line error'; return; }
    const btn = document.getElementById('eqImpReadBtn'); btn.disabled = true;
    await loadBuffers(await Promise.all(pdfs.map(f => f.arrayBuffer())), document.getElementById('eqImpPassword').value, await Promise.all(xlsx.map(f => f.arrayBuffer())));
    btn.disabled = false;
  }

  /* ---------- delete what was imported (two separate confirmation steps) ---------- */
  async function openDelete() {
    const st = document.getElementById('eqDelStatus');
    st.textContent = ''; st.className = 'status-line';
    document.getElementById('eqDelStep1').hidden = false;
    document.getElementById('eqDelStep2').hidden = true;
    document.getElementById('eqDelInput').value = '';
    document.getElementById('eqDelConfirm').disabled = true;
    const s = await Equity.importedSummary();
    const cont = document.getElementById('eqDelContinue');
    const box = document.getElementById('eqDelSummary');
    if (!s.lots && !s.ledgerEvents) {
      box.innerHTML = 'There is no imported equity data to delete.' + (s.manual ? ` (Your ${s.manual} manually added transaction${s.manual > 1 ? 's are' : ' is'} not affected by this anyway.)` : '');
      cont.hidden = true;
    } else {
      cont.hidden = false;
      box.innerHTML = `<b>Step 1 of 2.</b> This will permanently delete everything created by <b>Import from statements</b>:<ul class="del-list"><li><b>${s.lots} lot${s.lots === 1 ? '' : 's'}</b> across <b>${s.stocks} stock${s.stocks === 1 ? '' : 's'}</b> (cost ${inr(s.cost)})</li><li>the saved statement history — <b>${fmtInt(s.ledgerEvents)} transactions</b> and <b>${s.snapshots} holdings snapshot${s.snapshots === 1 ? '' : 's'}</b>, which are what a new upload builds on</li><li>the daily value snapshots that included equity</li></ul>`
        + `Your <b>${s.manual}</b> manually added transaction${s.manual === 1 ? '' : 's'} and your mutual funds are <b>not</b> touched.`;
    }
    document.getElementById('eqDeleteModal').hidden = false;
  }

  async function confirmDelete() {
    const st = document.getElementById('eqDelStatus');
    const btn = document.getElementById('eqDelConfirm');
    if (document.getElementById('eqDelInput').value.trim() !== 'DELETE') return;   // guard beyond the disabled button
    btn.disabled = true;
    try {
      st.textContent = 'Deleting…'; st.className = 'status-line';
      const r = await Equity.deleteImported();
      st.textContent = `Deleted ${r.lots} imported lot${r.lots === 1 ? '' : 's'}, ${fmtInt(r.ledgerDocs)} history records${r.snapshots ? ` and ${r.snapshots} value snapshot${r.snapshots === 1 ? '' : 's'}` : ''}.`;
      st.className = 'status-line ok';
      setTimeout(() => { document.getElementById('eqDeleteModal').hidden = true; App.refreshCurrentView(); }, 1000);
    } catch (err) {
      st.textContent = 'Error: ' + err.message; st.className = 'status-line error';
      btn.disabled = false;
    }
  }

  document.addEventListener('DOMContentLoaded', () => {
    const on = (id, ev, fn) => { const el = document.getElementById(id); if (el) el.addEventListener(ev, fn); };
    on('eqDelContinue', 'click', () => { document.getElementById('eqDelStep1').hidden = true; document.getElementById('eqDelStep2').hidden = false; document.getElementById('eqDelInput').focus(); });
    on('eqDelBack', 'click', () => { document.getElementById('eqDelStep1').hidden = false; document.getElementById('eqDelStep2').hidden = true; });
    on('eqDelInput', 'input', (e) => { document.getElementById('eqDelConfirm').disabled = e.target.value.trim() !== 'DELETE'; });
    on('eqDelConfirm', 'click', confirmDelete);
    on('eqImpReadBtn', 'click', readFiles);
    on('eqImpSaveBtn', 'click', save);
    on('eqImpBack', 'click', () => { document.getElementById('eqImpStep1').hidden = false; document.getElementById('eqImpStep2').hidden = true; });
    ['input', 'change'].forEach(ev => on('eqImpTable', ev, onTableInput));
  });

  return { open, openDelete, loadBuffers, resolveIsins, get state() { return state; } };
})();
