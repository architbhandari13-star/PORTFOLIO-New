/* eq-history.js — the equity value over time, from real daily share prices.

   Prices come from TradingView's chart data feed (the same one its own charts use): a WebSocket
   that returns daily OHLC bars, already adjusted for splits and bonuses. It is unofficial, but it
   was checked against the owner's CDSL statements (closing prices within 0.04% of the printed ones)
   and it accepts browser connections, so no server is needed.

   value(date) = Σ over every stock  quantity(date) × closing price(on or before date)

   Quantities come from the statement ledger (EqLedger.quantityTimeline), expressed in today's share
   units to match the adjusted prices. The result is only trusted if it reproduces the equity value
   CDSL itself printed at each statement date (see `validation`); otherwise the caller falls back to
   the month-end estimate. Everything fetched is cached in the browser for the day. */

const EqHistory = (() => {
  const SOCKET = 'wss://data.tradingview.com/socket.io/websocket';
  // Past closing prices never change (they are unadjusted), so once a symbol's history has been
  // downloaded it is kept in the database — one document per symbol — and later visits only fetch
  // the few days since. That also makes it survive clearing the browser and follow you to another device.
  const COLLECTION = 'equity_prices';
  const SYM_KEY = 'eqsym_v1';
  const BARS = 1000;                       // ~4 years of trading days, fetched once per symbol
  const DAY = 86400000;
  const today = () => new Date().toISOString().slice(0, 10);
  const lsGet = (k) => { try { return JSON.parse(localStorage.getItem(k)); } catch (e) { return null; } };
  const lsSet = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* quota — just refetch next time */ } };

  /* ---------- the chart data connection ---------- */
  // ONE connection serves many symbols, one after another (each symbol gets its own short-lived chart
  // session on it). Opening a fresh connection per symbol — 120 of them, five at a time — is what a
  // rate limiter dislikes; a couple of long-lived connections is what TradingView's own site does.
  // Every request resolves to { bars, reason }: `bars` = [[day number, close]…] or null, and `reason`
  // says why not ('unknown symbol', 'timed out', 'connection closed', …) so failures can be shown.
  class Feed {
    constructor() { this.ws = null; this.opening = null; this.pending = null; }
    frame(o) { const s = typeof o === 'string' ? o : JSON.stringify(o); return `~m~${s.length}~m~${s}`; }
    send(m, p) { this.ws.send(this.frame({ m, p })); }
    open() {
      if (this.ws && this.ws.readyState === 1) return Promise.resolve(true);
      if (this.opening) return this.opening;
      this.opening = new Promise((resolve) => {
        let ws;
        const giveUp = setTimeout(() => { try { ws.close(); } catch (e) { /* ignore */ } resolve(false); }, 10000);
        try { ws = new WebSocket(SOCKET); } catch (e) { clearTimeout(giveUp); resolve(false); return; }
        this.ws = ws;
        ws.onopen = () => { clearTimeout(giveUp); this.send('set_auth_token', ['unauthorized_user_token']); resolve(true); };
        ws.onerror = () => { /* onclose follows */ };
        ws.onclose = () => { clearTimeout(giveUp); this.ws = null; this.settle(null, 'connection closed'); resolve(false); };
        ws.onmessage = (ev) => this.onMessage(String(ev.data));
      }).finally(() => { this.opening = null; });
      return this.opening;
    }
    onMessage(data) {
      const hb = /~h~(\d+)/.exec(data);
      if (hb) { this.ws.send(this.frame('~h~' + hb[1])); return; }
      for (const part of data.split(/~m~\d+~m~/).filter(Boolean)) {
        let j; try { j = JSON.parse(part); } catch (e) { continue; }
        const p = this.pending;
        if (!p || !j.p || j.p[0] !== p.cs) continue;            // not about the symbol we are waiting for
        if (j.m === 'timescale_update') {
          const s = j.p[1] && j.p[1].sds_1 && j.p[1].sds_1.s;
          if (s) p.bars = s.map(b => [Math.round(b.v[0] / 86400), Math.round(b.v[4] * 100) / 100]);
        }
        if (j.m === 'series_completed') this.settle(p.bars && p.bars.length ? p.bars : null, p.bars && p.bars.length ? null : 'no data');
        if (j.m === 'symbol_error') this.settle(null, 'unknown symbol');
        if (j.m === 'critical_error') this.settle(null, 'feed error');
      }
    }
    settle(bars, reason) {
      const p = this.pending; if (!p) return;
      this.pending = null; clearTimeout(p.timer);
      try { this.send('chart_delete_session', [p.cs]); } catch (e) { /* connection already gone */ }
      p.resolve({ bars, reason });
    }
    async bars(symbol, count = BARS) {
      if (!(await this.open())) return { bars: null, reason: 'could not connect' };
      return new Promise((resolve) => {
        const cs = 'cs_' + Math.random().toString(36).slice(2, 12);
        const timer = setTimeout(() => {
          // a stuck request: drop the connection so the next symbol starts on a fresh one
          this.settle(null, 'timed out'); try { this.ws.close(); } catch (e) { /* ignore */ }
        }, 15000);
        this.pending = { cs, bars: null, resolve, timer };
        this.send('chart_create_session', [cs, '']);
        // 'none' = the price actually traded that day (not rescaled for later splits/bonuses)
        this.send('resolve_symbol', [cs, 'sds_sym_1', '=' + JSON.stringify({ symbol, adjustment: 'none' })]);
        this.send('create_series', [cs, 'sds_1', 's1', 'sds_sym_1', 'D', count, '']);
      });
    }
    close() { try { if (this.ws) this.ws.close(); } catch (e) { /* ignore */ } }
  }
  // (kept for callers that want a single one-off download)
  async function fetchBars(symbol, count = BARS) { const f = new Feed(); const r = await f.bars(symbol, count); f.close(); return r.bars; }

  // The stored history of every symbol, read once per page load: symbol -> {symbol, d:[day numbers], c:[closes], updated}.
  // The store is loaded ONCE and everyone waits for that same load. (An earlier version handed a
  // half-filled map to a second caller that arrived while the first was still reading the database —
  // it saw "nothing saved" and downloaded all 120 histories again on a reload.)
  let storePromise = null;
  function loadStore() {
    if (!storePromise) storePromise = (async () => {
      const memory = new Map();
      memory.stubs = new Map();     // symbols TradingView reported as unknown: remembered for a week so they aren't asked about again
      (await DB.getAll(COLLECTION)).forEach(x => {
        if (x.symbol && x.d && x.d.length) memory.set(x.symbol, x);
        else if (x.symbol && x.failed) memory.stubs.set(x.symbol, x);
      });
      // Histories cached by an earlier build lived in this browser only ("eqpx_v3_<symbol>", unadjusted
      // like today's); move them into the database once instead of downloading them again.
      try {
        for (const k of Object.keys(localStorage).filter(k => k.startsWith('eqpx_v3_'))) {
          const c = JSON.parse(localStorage.getItem(k)), symbol = k.slice('eqpx_v3_'.length);
          if (c && c.bars && c.bars.length && !memory.has(symbol)) {
            const doc = { symbol, d: c.bars.map(b => b[0]), c: c.bars.map(b => b[1]), updated: c.day || '' };
            memory.set(symbol, doc);
            await DB.setDoc(COLLECTION, EqLedger.hash(symbol), doc);
          }
          localStorage.removeItem(k);
        }
      } catch (e) { /* nothing to migrate */ }
      return memory;
    })();
    return storePromise;
  }

  // New symbol: the full history, once. Known symbol not yet checked today: only the days since
  // the last stored close (plus a small overlap, which also replaces an unfinished bar). Returns
  // Map(symbol -> {d:[iso…], c:[close…]}) for every symbol that has data.
  // Calls are run one after another: a second call that overlaps the first waits for it, then finds
  // everything already saved and current — so it downloads nothing.
  let priceQueue = Promise.resolve();
  function loadPrices(symbols, onProgress) {
    const run = priceQueue.then(() => loadPricesNow(symbols, onProgress));
    priceQueue = run.catch(() => {});
    return run;
  }
  // Failures seen during THIS page load. A symbol that failed is not asked for again until the page is
  // reloaded — otherwise every switch back to the Overview would retry all of them, which is the "it
  // keeps loading" loop. (Unknown symbols are additionally remembered in the database for a week.)
  const failedThisLoad = new Map();
  let lastRun = null;
  const daysSince = (iso) => (Date.now() - new Date(iso + 'T00:00:00Z').getTime()) / DAY;
  const sleep = (ms) => new Promise(r => setTimeout(r, ms));

  async function loadPricesNow(symbols, onProgress) {
    const store = await loadStore();
    const t = today();
    const todo = [], skipped = [];
    for (const s of symbols) {
      const st = store.get(s);
      const stub = store.stubs.get(s);
      if (failedThisLoad.has(s)) { skipped.push({ symbol: s, reason: failedThisLoad.get(s) + ' (not retried until you reload the page)' }); continue; }
      if (!st && stub && stub.updated && daysSince(stub.updated) < 7) { skipped.push({ symbol: s, reason: (stub.failed || 'unknown symbol') + ' (checked ' + stub.updated + ')' }); continue; }
      if (!st) todo.push({ s, count: BARS });
      else if (st.updated !== t) {
        const gapDays = Math.ceil(Date.now() / DAY - st.d[st.d.length - 1]);
        todo.push({ s, count: Math.min(BARS, Math.max(12, Math.ceil(gapDays * 0.75) + 8)) });
      }
    }
    let done = symbols.length - todo.length;
    if (onProgress) onProgress(done, symbols.length);
    const failed = [];
    const save = async (s, bars) => {
      const old = store.get(s);
      const first = bars[0][0];
      const keep = old ? old.d.map((day, i) => [day, old.c[i]]).filter(b => b[0] < first) : [];
      const all = keep.concat(bars);
      const doc = { symbol: s, ...normalize(all.map(b => b[0]), all.map(b => b[1])), updated: t };
      store.set(s, doc);
      try { await DB.setDoc(COLLECTION, EqLedger.hash(s), doc); } catch (e) { console.warn('could not store prices for', s, e); }
    };
    // two long-lived connections, each working through the queue; a transient failure gets one more try
    const queue = todo.map(x => ({ ...x, tries: 0 }));
    const worker = async () => {
      const feed = new Feed();
      while (queue.length) {
        const job = queue.shift();
        const r = await feed.bars(job.s, job.count);
        if (r.bars) { await save(job.s, r.bars); done++; if (onProgress) onProgress(done, symbols.length); }
        else if (r.reason !== 'unknown symbol' && job.tries < 1) { job.tries++; await sleep(1500); queue.push(job); }   // transient: try again later in this run
        else {
          failed.push({ symbol: job.s, reason: r.reason });
          failedThisLoad.set(job.s, r.reason);
          if (r.reason === 'unknown symbol' && !store.has(job.s)) {
            const stub = { symbol: job.s, d: [], c: [], updated: t, failed: r.reason };
            store.stubs.set(job.s, stub);
            try { await DB.setDoc(COLLECTION, EqLedger.hash(job.s), stub); } catch (e) { /* not essential */ }
          }
          done++; if (onProgress) onProgress(done, symbols.length);
        }
        await sleep(120);                      // small gap between symbols
      }
      feed.close();
    };
    await Promise.all([...Array(Math.min(2, todo.length))].map(worker));
    const out = new Map();
    for (const s of symbols) { const st = store.get(s); if (st) out.set(s, decode(st)); }
    out.downloaded = todo.length - failed.length;                 // symbols actually fetched now (0 when everything was already saved)
    out.failed = failed.concat(skipped.filter(x => !store.has(x.symbol)));
    out.saved = out.size;
    lastRun = { at: new Date().toISOString(), total: symbols.length, saved: out.size, downloaded: out.downloaded, failed: out.failed };
    return out;
  }
  // The date lookup (`closeOn`) is a binary search, so a series must be strictly ascending by day. A feed can
  // deliver two bars for one calendar day (e.g. a special evening session) or bars out of order, so every
  // series is sorted and de-duplicated (the later bar for a day wins) both when it is stored and when it is read.
  function normalize(days, closes) {
    const byDay = new Map();
    days.forEach((d, i) => byDay.set(d, closes[i]));
    const sorted = [...byDay.keys()].sort((a, b) => a - b);
    return { d: sorted, c: sorted.map(d => byDay.get(d)) };
  }
  const decode = (st) => {
    const n = normalize(st.d, st.c);
    return { d: n.d.map(day => new Date(day * DAY).toISOString().slice(0, 10)), c: n.c };
  };

  // last close on or before an ISO date (binary search); null if the series starts later
  function closeOn(series, iso) {
    if (!series) return null;
    let lo = 0, hi = series.d.length - 1, best = -1;
    while (lo <= hi) { const mid = (lo + hi) >> 1; if (series.d[mid] <= iso) { best = mid; lo = mid + 1; } else hi = mid - 1; }
    return best >= 0 ? series.c[best] : null;
  }

  /* ---------- ISIN -> TradingView symbol ---------- */
  // Held stocks already have a symbol (and any correction the owner made) in equity_costs; stocks
  // that were sold before the latest statement have none, so they are looked up by ISIN.
  // Every lookup made is kept in the database too (`equity_symbols`, one document: ISIN -> symbol, or
  // null for "TradingView has no listing"), loaded once and shared, so it is never repeated.
  let symbolsPromise = null;
  function loadSymbolMap() {
    if (!symbolsPromise) symbolsPromise = (async () => {
      const doc = await DB.getDoc('equity_symbols', 'map');
      const map = (doc && doc.isins) || {};
      // an earlier build kept these in this browser only — move them across once
      try {
        const legacy = JSON.parse(localStorage.getItem(SYM_KEY));
        if (legacy) {
          let changed = false;
          for (const [i, v] of Object.entries(legacy)) if (!(i in map) && v && v.sym !== undefined) { map[i] = v.sym; changed = true; }
          if (changed) await DB.setDoc('equity_symbols', 'map', { isins: map });
          localStorage.removeItem(SYM_KEY);
        }
      } catch (e) { /* nothing to migrate */ }
      return map;
    })();
    return symbolsPromise;
  }

  async function resolveSymbols(isins, costs) {
    const map = new Map();
    const fromCosts = new Map(costs.filter(c => c.symbol && c.include !== false).map(c => [c.isin, `${c.exchange}:${c.symbol}`]));
    const known = await loadSymbolMap();
    const missing = [];
    for (const i of isins) {
      if (fromCosts.has(i)) map.set(i, fromCosts.get(i));
      else if (i in known) { if (known[i]) map.set(i, known[i]); }
      else missing.push(i);
    }
    if (missing.length) {
      let listings = null;
      try { listings = await EqImport.resolveIsins(missing); } catch (e) { /* offline: try again next time, remember nothing */ }
      if (listings) {
        missing.forEach(i => {
          const l = listings[i] || {};
          const pick = l.NSE ? `NSE:${l.NSE.symbol}` : (l.BSE ? `BSE:${l.BSE.symbol}` : null);
          known[i] = pick;
          if (pick) map.set(i, pick);
        });
        try { await DB.setDoc('equity_symbols', 'map', { isins: known }); } catch (e) { console.warn('could not store ticker lookups', e); }
      }
    }
    return map;
  }

  /* ---------- the series ---------- */
  // dates: ISO dates to value (ascending). onProgress(done, total) reports price downloads.
  // Returns null when there is nothing to build from; otherwise
  //   { points:[{date,value}], validation:[{date, computed, reference, diffPct}], ok, coverage, missing:[isin], symbols }
  async function buildEquitySeries({ dates, onProgress }) {
    const [docs, snaps, costs] = await Promise.all([DB.getAll('equity_ledger'), DB.getAll('equity_snapshots'), DB.getAll('equity_costs')]);
    if (!docs.length || !snaps.length) return null;
    const latest = [...snaps].sort((a, b) => (a.asOf < b.asOf ? 1 : -1))[0];
    const tl = EqLedger.quantityTimeline(docs, latest.holdings.map(h => ({ isin: h.isin, qty: h.qty })));

    const finals = [...tl.finals.keys()];
    const symbols = await resolveSymbols(finals, costs);
    const wanted = [...new Set(symbols.values())];
    const prices = await loadPrices(wanted, onProgress);
    // A stock TradingView cannot price (delisted, unlisted, a ticker it doesn't know) falls back to the
    // prices CDSL printed on the statements that held it — a step line through those dates. Coarser,
    // but it keeps the total honest at every statement date instead of leaving a hole.
    const statementSeries = (final) => {
      const isins = tl.members.get(final) || new Set([final]);     // every ISIN this security has had
      const pts = snaps.flatMap(s => s.holdings.filter(h => isins.has(h.isin) && h.price > 0).map(h => [s.asOf, h.price])).sort((a, b) => a[0].localeCompare(b[0]));
      return pts.length ? { d: pts.map(p => p[0]), c: pts.map(p => p[1]), fallback: true } : null;
    };
    const seriesOf = (isin) => prices.get(symbols.get(isin)) || statementSeries(isin);
    const missing = finals.filter(i => !seriesOf(i));
    const usedFallback = finals.filter(i => !prices.get(symbols.get(i)) && seriesOf(i));

    const valueOn = (iso) => {
      let v = 0;
      for (const i of finals) {
        const s = seriesOf(i); if (!s) continue;
        const q = tl.qtyAt(i, iso); if (q <= 0) continue;
        let px = closeOn(s, iso);
        if (px == null && s.fallback) px = s.c[0];          // before its first statement: flat back
        if (px != null) v += q * px;
      }
      return v;
    };
    const points = dates.map(date => ({ date, value: valueOn(date) }));

    // Reconcile with what CDSL printed: the equity value at each statement date.
    const validation = snaps.map(s => {
      const reference = s.classes && s.classes.equity ? s.classes.equity : s.holdings.reduce((a, h) => a + h.value, 0);
      const computed = valueOn(s.asOf);
      return { date: s.asOf, computed, reference, diffPct: reference ? (100 * (computed - reference)) / reference : 0 };
    }).sort((a, b) => a.date.localeCompare(b.date));
    // a stock without any price history would leave a hole, so it counts against "ok"
    const heldValue = latest.holdings.reduce((a, h) => a + h.value, 0);
    const missingHeldValue = latest.holdings.filter(h => missing.includes(h.isin)).reduce((a, h) => a + h.value, 0);
    const coverage = heldValue ? 1 - missingHeldValue / heldValue : 1;
    const ok = validation.length > 0 && validation.every(v => Math.abs(v.diffPct) <= 4) && coverage >= 0.9;
    return { points, validation, ok, coverage, missing, usedFallback, symbols: symbols.size, roundTrips: tl.roundTrips, downloaded: prices.downloaded || 0, total: wanted.length, saved: prices.saved || 0, failed: prices.failed || [] };
  }

  /* ---------- the finished chart, cached ---------- */
  // Building the series above means reading every symbol's saved price history (~120 documents)
  // and re-running the whole reconciliation — cheap next to actually downloading anything, but
  // still enough to be visible on every single page load, on every device, forever. Since the
  // owner's holdings only change when a statement is imported or a lot/ticker is corrected, the
  // *finished* series is cached in Firestore too: one document (`equity_history_cache/latest`)
  // holding exactly what the chart needs to draw, plus the generation it was built against.
  //
  // `meta/equityGeneration` is a small counter bumped only by the handful of places that actually
  // change equity_ledger/equity_snapshots/equity_costs (import, delete-imported, a ticker/cost
  // edit) — see eq-import.js, equity.js, edit.js. A cache whose generation still matches is known
  // to reflect the current holdings; it just might be a day stale on prices, same as the note in
  // buildEquitySeries above.
  const GEN_DOC = { collection: 'meta', id: 'equityGeneration' };
  const CACHE_DOC = { collection: 'equity_history_cache', id: 'latest' };

  async function getGeneration() {
    const doc = await DB.getDoc(GEN_DOC.collection, GEN_DOC.id);
    return (doc && doc.v) || 0;
  }
  async function bumpGeneration() {
    const cur = await getGeneration();
    try { await DB.setDoc(GEN_DOC.collection, GEN_DOC.id, { v: cur + 1, updated: new Date().toISOString() }); }
    catch (e) { console.warn('could not bump the equity data generation — the cached chart may go a step stale', e); }
  }
  async function readCachedSeries() {
    try { return await DB.getDoc(CACHE_DOC.collection, CACHE_DOC.id); } catch (e) { return null; }
  }
  // generation: the value getGeneration() returned right before `result` was built, so a reader
  // can tell whether this cache still matches the holdings it reflects.
  async function writeCachedSeries(result, generation) {
    const doc = {
      points: result.points, validation: result.validation, ok: result.ok, coverage: result.coverage,
      saved: result.saved, total: result.total, downloaded: 0, failed: result.failed || [],
      generation, computedDate: today(), updated: new Date().toISOString()
    };
    // Firestore rejects `undefined` fields outright — none of the fields above can currently be
    // undefined, but every other write in this app goes through this same JSON round-trip (see
    // eq-import.js's `clean`) precisely so a future field addition can't silently break the write.
    try { await DB.setDoc(CACHE_DOC.collection, CACHE_DOC.id, JSON.parse(JSON.stringify(doc))); }
    catch (e) { console.warn('could not store the cached equity chart', e); }
  }
  async function clearCachedSeries() {
    try { await DB.deleteDoc(CACHE_DOC.collection, CACHE_DOC.id); } catch (e) { /* not essential */ }
  }

  return { buildEquitySeries, fetchBars, loadPrices, resolveSymbols, closeOn, forgetMemory: () => { storePromise = null; symbolsPromise = null; failedThisLoad.clear(); },
           getGeneration, bumpGeneration, readCachedSeries, writeCachedSeries, clearCachedSeries,
           get lastRun() { return lastRun; } };
})();
