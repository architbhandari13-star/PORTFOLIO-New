/* firebase-config.js
   -------------------------------------------------------------
   Fill this in once you've created your Firebase project:
     1. https://console.firebase.google.com -> Add project (free "Spark" plan, no card needed)
     2. Build > Firestore Database -> Create database -> Start in test mode -> pick a region
     3. Project settings (gear icon) > General > Your apps > Add app > Web (</>)
     4. Copy the firebaseConfig object it gives you and paste the values below.
   Until this is filled in, the app runs entirely on browser localStorage —
   fully usable on this device, just without cross-device sync.
   See SETUP.md for full step-by-step instructions.
   ------------------------------------------------------------- */
const FIREBASE_CONFIG = {
  apiKey: "AIzaSyAPGLHZJg2A2GvQW7fHJgO3bWDM0bCti1k",
  authDomain: "portfolio-analysis-6312f.firebaseapp.com",
  projectId: "portfolio-analysis-6312f",
  storageBucket: "portfolio-analysis-6312f.firebasestorage.app",
  messagingSenderId: "326714726631",
  appId: "1:326714726631:web:2770da23d3dad958b5aa42"
};
