/* mf.js — CDSL statement upload flow (parse -> review -> commit) and MF data access. */

const Mf = (() => {
  const FOLIOS = 'mf_folios';
  const TXNS = 'mf_transactions';
  const PERIODS = 'mf_periods';

  function folioId(isin, folioNo) {
    return `${isin}_${(folioNo || 'na').replace(/[^a-zA-Z0-9]/g, '')}`;
  }

  async function getAllFolios() { return DB.getAll(FOLIOS); }
  async function getAllTransactions() { return DB.getAll(TXNS); }
  async function getAllPeriods() { return DB.getAll(PERIODS); }
  async function deleteTransaction(id) { return DB.deleteDoc(TXNS, id); }
  async function deleteFolio(id) { return DB.deleteDoc(FOLIOS, id); }
  async function updateTransaction(id, patch) { return DB.updateDoc(TXNS, id, patch); }

  /* Wipes all mutual fund data (folios, statement periods, transactions) so statements can be
     re-imported from scratch. Never touches equity or the price cache. */
  async function resetAll() {
    const [folios, periods, txns] = await Promise.all([getAllFolios(), getAllPeriods(), getAllTransactions()]);
    await Promise.all([
      ...folios.map(f => DB.deleteDoc(FOLIOS, f.id)),
      ...periods.map(p => DB.deleteDoc(PERIODS, p.id)),
      ...txns.map(t => DB.deleteDoc(TXNS, t.id))
    ]);
    return { folios: folios.length, periods: periods.length, txns: txns.length };
  }

  /* Commit a parsed+reviewed statement. Statements can be uploaded in any order and for any
     year: every statement adds its period + transactions to the history, but a folio's
     *current* state (units, NAV, invested) only moves forward — an older statement never
     overwrites a newer one. */
  async function commitStatement(parsed) {
    const [existingFolios, existingTxns] = await Promise.all([getAllFolios(), getAllTransactions()]);
    const folioById = {};
    existingFolios.forEach(f => { folioById[f.id] = f; });
    const existingRefs = new Set(existingTxns.filter(t => t.reference).map(t => t.reference));
    const existingKeys = new Set(existingTxns.map(t => `${t.isin}|${t.date}|${t.amount}|${t.units}`));

    let inserted = 0, skipped = 0, newFolios = 0, staleFolios = 0, migrated = 0;
    for (const scheme of parsed.schemes) {
      const id = folioId(scheme.isin, scheme.folioNo);

      // Earlier versions of the parser stored some wrapped folio numbers truncated (e.g. "8/0"
      // instead of "1041121688/0"). Fold any such legacy record into the correctly-numbered one,
      // keeping its already-resolved mfapi scheme code, instead of leaving a duplicate fund behind.
      let carriedCode = null;
      for (const f of existingFolios) {
        if (f.isin === scheme.isin && f.id !== id && f.folioNo && scheme.folioNo && scheme.folioNo.endsWith(f.folioNo) && folioById[f.id]) {
          carriedCode = carriedCode || f.mfapiSchemeCode || null;
          await DB.deleteDoc(FOLIOS, f.id);
          delete folioById[f.id];
          migrated++;
        }
      }

      const existing = folioById[id];
      const isNewer = !existing || (parsed.asOfDate || '') >= (existing.lastStatementDate || '');

      // Cost of whatever was already held before this statement's period — only a lump total,
      // used as a fallback approximation when no NAV history is available for the fund.
      const periodTxnTotal = scheme.transactions.reduce((s, t) => s + (t.type === 'purchase' ? (t.amount || 0) : 0), 0);
      const preOpeningInvested = Math.max(0, (scheme.cumulativeInvested || 0) - periodTxnTotal);

      // One record per folio per statement period — this is what lets history be rebuilt.
      await DB.setDoc(PERIODS, `${id}_${parsed.periodStart}`, {
        folioId: id, isin: scheme.isin, schemeName: scheme.schemeName, amcName: scheme.amcName,
        periodStart: parsed.periodStart, periodEnd: parsed.asOfDate,
        openingUnits: scheme.openingBalance, closingUnits: scheme.closingUnits,
        closingNav: scheme.nav, cumulativeInvested: scheme.cumulativeInvested, valuation: scheme.valuation
      });

      if (!existing || isNewer) {
        await DB.setDoc(FOLIOS, id, {
          isin: scheme.isin,
          folioNo: scheme.folioNo,
          schemeName: scheme.schemeName,
          amcName: scheme.amcName,
          arnCode: scheme.arnCode,
          closingUnits: scheme.closingUnits,
          nav: scheme.nav,
          navDate: parsed.asOfDate,
          cumulativeInvested: scheme.cumulativeInvested,
          preOpeningInvested,
          periodStart: parsed.periodStart,
          lastStatementValuation: scheme.valuation,
          terRegular: scheme.terRegular,
          terDirect: scheme.terDirect,
          grossCommission: scheme.grossCommission,
          lastStatementDate: parsed.asOfDate,
          mfapiSchemeCode: (existing && existing.mfapiSchemeCode) || carriedCode || scheme.mfapiSchemeCode || null
        });
        if (!existing) newFolios++;
      } else {
        staleFolios++;
      }

      for (const t of scheme.transactions) {
        const key = `${scheme.isin}|${t.date}|${t.amount}|${t.units}`;
        const isDup = t.reference ? existingRefs.has(t.reference) : existingKeys.has(key);
        if (isDup) { skipped++; continue; }
        await DB.addDoc(TXNS, {
          // periodStart: the statement period this was reported in. A transaction can carry a
          // date just before that period (allotted late) yet still be counted in it — the
          // statement's opening balance excludes it — so history needs to know the period.
          folioId: id, periodStart: parsed.periodStart, isin: scheme.isin, folioNo: scheme.folioNo, schemeName: scheme.schemeName,
          date: t.date, description: t.description, reference: t.reference,
          amount: t.amount, nav: t.nav, units: t.units, type: t.type
        });
        if (t.reference) existingRefs.add(t.reference);
        existingKeys.add(key);
        inserted++;
      }
    }
    return { inserted, skipped, newFolios, staleFolios, migrated };
  }

  // Correct a fund's name/AMC after upload: the folio and every record derived from it carry the
  // name, so all of them are updated together.
  async function renameFolio(id, { schemeName, amcName }) {
    const [txns, periods] = await Promise.all([getAllTransactions(), getAllPeriods()]);
    const mine = (x) => x.folioId === id;
    const patch = {};
    if (schemeName != null) patch.schemeName = schemeName;
    if (amcName != null) patch.amcName = amcName;
    await DB.updateDoc(FOLIOS, id, patch);
    const tp = { ...(schemeName != null ? { schemeName } : {}) };
    if (Object.keys(tp).length) {
      await Promise.all([
        ...txns.filter(mine).map(t => DB.updateDoc(TXNS, t.id, tp)),
        ...periods.filter(mine).map(p => DB.updateDoc(PERIODS, p.id, { ...tp, ...(amcName != null ? { amcName } : {}) }))
      ]);
    }
    return { txns: txns.filter(mine).length, periods: periods.filter(mine).length };
  }

  return { getAllFolios, getAllTransactions, getAllPeriods, commitStatement, folioId, deleteTransaction, deleteFolio, updateTransaction, renameFolio, resetAll };
})();


/* ---------- Upload modal UI ---------- */
(function () {
  let parsedResult = null;

  function openMfModal() {
    document.getElementById('mfStep1').hidden = false;
    document.getElementById('mfStep2').hidden = true;
    document.getElementById('mfFileName').textContent = '';
    document.getElementById('mfParseStatus').textContent = '';
    document.getElementById('mfPasswordInput').value = '';
    parsedResult = null;
    document.getElementById('mfUploadModal').hidden = false;
  }

  async function handleParse() {
    const fileInput = document.getElementById('mfFileInput');
    const status = document.getElementById('mfParseStatus');
    const file = fileInput.files[0];
    const password = document.getElementById('mfPasswordInput').value;
    if (!file) { status.textContent = 'Choose a PDF first.'; status.className = 'status-line error'; return; }
    status.textContent = 'Parsing… this can take a few seconds.'; status.className = 'status-line';
    try {
      const buf = await file.arrayBuffer();
      const result = await MfParser.parse(buf, password);
      if (!result.schemes.length) {
        status.textContent = 'No mutual fund holdings found in this statement.'; status.className = 'status-line error'; return;
      }
      parsedResult = result;
      renderReview(result);
      document.getElementById('mfStep1').hidden = true;
      document.getElementById('mfStep2').hidden = false;
    } catch (err) {
      status.textContent = 'Could not parse: ' + err.message + ' (check the password?)';
      status.className = 'status-line error';
    }
  }

  function fmtIsoDate(iso) { return iso ? new Date(iso + 'T00:00:00Z').toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric', timeZone: 'UTC' }) : '?'; }

  function renderReview(result) {
    const nTxns = result.schemes.reduce((s, x) => s + x.transactions.length, 0);
    const nRedeem = result.schemes.reduce((s, x) => s + x.transactions.filter(t => t.type === 'redemption').length, 0);
    document.getElementById('mfReviewInfo').innerHTML =
      `Statement period <b>${fmtIsoDate(result.periodStart)} – ${fmtIsoDate(result.asOfDate)}</b> · ${result.schemes.length} folios · ${nTxns} transactions` +
      (nRedeem ? ` · <b>${nRedeem} redemption${nRedeem > 1 ? 's' : ''}</b>` : '') +
      `. Review before saving — fix anything that looks off, then confirm. You can upload statements for other years afterwards; older ones add history without changing current holdings.`;
    const table = document.getElementById('mfReviewTable');
    const rows = result.schemes.map((s, i) => `
      <tr data-idx="${i}">
        <td><input class="rv-input rv-name" value="${escapeAttr(s.schemeName)}" style="width:240px"></td>
        <td>${s.isin}</td>
        <td>${s.folioNo || ''}</td>
        <td class="num">${fmtNum(s.closingUnits)}</td>
        <td class="num">${fmtMoney(s.cumulativeInvested)}</td>
        <td class="num">${fmtMoney(s.valuation)}</td>
        <td class="num ${s.unrealizedPct >= 0 ? 'pos' : 'neg'}">${fmtPct(s.unrealizedPct)}</td>
        <td class="num">${s.transactions.length}</td>
      </tr>`).join('');
    table.innerHTML = `
      <thead><tr><th>Scheme</th><th>ISIN</th><th>Folio</th><th>Units</th><th>Invested</th><th>Valuation</th><th>P&amp;L %</th><th>Txns</th></tr></thead>
      <tbody>${rows}</tbody>
      <tfoot><tr><td colspan="4"></td><td class="num"><b>${fmtMoney(result.grandTotal?.invested)}</b></td><td class="num"><b>${fmtMoney(result.grandTotal?.valuation)}</b></td><td colspan="2"></td></tr></tfoot>`;
    table.querySelectorAll('.rv-name').forEach((input, i) => {
      input.addEventListener('change', () => { parsedResult.schemes[i].schemeName = input.value; });
    });
  }

  async function handleCommit() {
    const status = document.getElementById('mfCommitStatus');
    if (!parsedResult) return;
    status.textContent = 'Saving…'; status.className = 'status-line';
    try {
      const r = await Mf.commitStatement(parsedResult);
      status.textContent = `Saved. ${r.inserted} new transactions added, ${r.skipped} already on file.` +
        (r.staleFolios ? ` ${r.staleFolios} folios were already up to date from a newer statement — history added, current holdings unchanged.` : '') +
        (r.migrated ? ` ${r.migrated} folio record${r.migrated > 1 ? 's' : ''} with a truncated folio number were merged.` : '');
      status.className = 'status-line ok';
      setTimeout(() => { document.getElementById('mfUploadModal').hidden = true; App.refreshCurrentView(); }, r.staleFolios || r.migrated ? 2600 : 900);
    } catch (err) {
      status.textContent = 'Error saving: ' + err.message; status.className = 'status-line error';
    }
  }

  function fmtNum(n) { return n == null ? '—' : Number(n).toLocaleString('en-IN', { maximumFractionDigits: 3 }); }
  function fmtMoney(n) { return n == null ? '—' : '₹' + Number(n).toLocaleString('en-IN', { maximumFractionDigits: 0 }); }
  function fmtPct(n) { return n == null ? '—' : (n >= 0 ? '+' : '') + Number(n).toFixed(2) + '%'; }
  function escapeAttr(s) { return String(s || '').replace(/"/g, '&quot;'); }

  document.addEventListener('DOMContentLoaded', () => {
    pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';

    const dropzone = document.getElementById('mfDropzone');
    const fileInput = document.getElementById('mfFileInput');
    dropzone.addEventListener('click', () => fileInput.click());
    dropzone.addEventListener('dragover', (e) => e.preventDefault());
    dropzone.addEventListener('drop', (e) => {
      e.preventDefault();
      if (e.dataTransfer.files.length) { fileInput.files = e.dataTransfer.files; showFileName(); }
    });
    fileInput.addEventListener('change', showFileName);
    function showFileName() {
      document.getElementById('mfFileName').textContent = fileInput.files[0] ? fileInput.files[0].name : '';
    }

    document.getElementById('mfParseBtn').addEventListener('click', handleParse);
    document.getElementById('mfCommitBtn').addEventListener('click', handleCommit);
  });

  window.MfUI = { openMfModal };
})();
