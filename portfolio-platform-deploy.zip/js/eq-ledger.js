/* eq-ledger.js — turns CDSL transaction events into dated, FIFO-correct open lots.
   Pure logic: no DOM, no database.

   Why a ledger. A statement is a *period*, not a snapshot: the events in it are facts that never
   change. So they are stored permanently (deduplicated by a deterministic key), and the open lots
   are always recomputed from *everything ever uploaded*. That makes uploading in any order, or
   re-uploading an overlapping statement, harmless — and each month's upload simply adds events.

   Replay rules (all verified against the owner's statements — every security's replayed balance
   equals the balance CDSL prints, 192 of 192 across two years):
     BUY / TRANSFER_IN / CA_NEW  add a lot dated that day (bonus/rights shares: the allotment date)
     SELL                        consumes the oldest lots first (FIFO — what Indian tax rules use)
     CA_MOVE (split, listing)    the old ISIN's lots move to the new ISIN with their ORIGINAL dates,
                                 quantities scaled by the new/old ratio
     OPEN                        the opening balance printed on a security's first line seeds the
                                 oldest lot, whose date is unknown (before the earliest statement)
   The position that remains is then reconciled with the latest statement's holdings table. */

const EqLedger = (() => {
  const PRI = { BUY: 0, TRANSFER_IN: 0, CA_NEW: 1, CA_MOVE: 2, SELL: 3 };
  const r6 = (n) => Math.round(n * 1e6) / 1e6;
  const sum = (lots) => lots.reduce((s, l) => s + l.qty, 0);
  const dayBefore = (iso) => new Date(new Date(iso + 'T00:00:00Z').getTime() - 86400000).toISOString().slice(0, 10);

  // 64-bit-ish hex hash of a string (two independent 32-bit FNV variants) — used for document ids.
  function hash(str) {
    let a = 0x811c9dc5, b = 0x01000193 ^ str.length;
    for (let i = 0; i < str.length; i++) {
      const c = str.charCodeAt(i);
      a = Math.imul(a ^ c, 0x01000193) >>> 0;
      b = Math.imul(b + c, 0x85ebca6b) >>> 0; b ^= b >>> 13;
    }
    return a.toString(16).padStart(8, '0') + b.toString(16).padStart(8, '0');
  }

  // Deterministic key per event. Identical events inside one statement (same day, quantity and
  // reference) are numbered so genuine repeats are kept; a re-uploaded or overlapping statement
  // numbers them identically, so they deduplicate.
  function withKeys(events) {
    const seen = {};
    return events.map(e => {
      const base = e.kind === 'OPEN'
        ? ['OPEN', e.acct, e.isin, e.periodStart].join('|')
        : [e.acct, e.isin, e.date, e.kind, e.side, e.qty, e.caRef || '', e.ref || ''].join('|');
      seen[base] = (seen[base] || 0) + 1;
      return { ...e, key: base + '#' + (seen[base] - 1) };
    });
  }

  // Ledger documents are one per (account, ISIN): { acct, dp, isin, events:[…] }.
  // Returns only the documents that actually change, plus how many events were new.
  function mergeIntoDocs(existingDocs /* [{id,...}] */, newEvents) {
    const byId = new Map(existingDocs.map(d => [d.id, d]));
    const changed = new Map();
    let added = 0;
    for (const e of withKeys(newEvents)) {
      const id = 'L' + hash(e.acct + '|' + e.isin);
      let doc = changed.get(id) || byId.get(id);
      if (!doc) doc = { id, acct: e.acct, dp: e.dp, isin: e.isin, events: [] };
      if (doc.events.some(x => x.key === e.key)) continue;
      const slim = { key: e.key, kind: e.kind, date: e.date, qty: e.qty, side: e.side || null, caRef: e.caRef || null, code: e.code || null, ref: e.ref || null, periodStart: e.periodStart || null };
      const next = { ...doc, events: [...doc.events, slim] };
      changed.set(id, next); added++;
    }
    return { docs: [...changed.values()], added };
  }

  function flatten(docs) {
    return docs.flatMap(d => d.events.map(e => ({ ...e, acct: d.acct, dp: d.dp, isin: d.isin })));
  }

  /* ---------- replay ---------- */
  function replay(events) {
    const book = new Map();
    const get = (acct, isin, dp) => {
      const k = acct + '|' + isin; let b = book.get(k);
      if (!b) { b = { acct, isin, dp, lots: [], short: 0, touched: false }; book.set(k, b); }
      return b;
    };
    const byDate = (a, b) => ((a.date || '0000') < (b.date || '0000') ? -1 : (a.date || '0000') > (b.date || '0000') ? 1 : 0);
    const sortLots = (lots) => lots.sort(byDate);   // stable: unknown-date lots first, then oldest

    // The earliest opening balance of each security seeds its oldest lot.
    const seeded = new Set();
    events.filter(e => e.kind === 'OPEN').sort((a, b) => (a.periodStart < b.periodStart ? -1 : 1)).forEach(o => {
      const k = o.acct + '|' + o.isin;
      if (seeded.has(k)) return;
      seeded.add(k);
      const b = get(o.acct, o.isin, o.dp);
      if (o.qty > 0) b.lots.push({ qty: o.qty, date: null, src: 'opening', origin: 'OPEN|' + k });
    });

    const evs = events.filter(e => PRI[e.kind] != null)
      .sort((a, b) => byDate(a, b) || PRI[a.kind] - PRI[b.kind] || (a.key < b.key ? -1 : 1));
    const moves = {};
    evs.filter(e => e.kind === 'CA_MOVE').forEach(e => { (moves[e.caRef + '|' + e.acct] = moves[e.caRef + '|' + e.acct] || []).push(e); });
    const done = new Set();
    const warnings = [];

    for (const e of evs) {
      const b = get(e.acct, e.isin, e.dp);
      b.touched = true;
      if (e.kind === 'BUY') b.lots.push({ qty: e.qty, date: e.date, src: 'buy', origin: e.key });
      else if (e.kind === 'TRANSFER_IN') b.lots.push({ qty: e.qty, date: e.date, src: 'transfer', origin: e.key });
      else if (e.kind === 'CA_NEW') b.lots.push({ qty: e.qty, date: e.date, src: 'bonus', origin: e.key });
      else if (e.kind === 'SELL') {
        let rem = e.qty; sortLots(b.lots);
        while (rem > 1e-9 && b.lots.length) { const l = b.lots[0]; const m = Math.min(l.qty, rem); l.qty -= m; rem -= m; if (l.qty <= 1e-9) b.lots.shift(); }
        if (rem > 1e-9) b.short += rem;
      } else if (e.kind === 'CA_MOVE') {
        const gk = e.caRef + '|' + e.acct;
        if (done.has(gk)) continue;
        done.add(gk);
        const grp = moves[gk] || [];
        const dbs = grp.filter(x => x.side === 'Db'), crs = grp.filter(x => x.side === 'Cr');
        if (dbs.length === 1 && crs.length === 1) {
          const from = get(dbs[0].acct, dbs[0].isin, dbs[0].dp), to = get(crs[0].acct, crs[0].isin, crs[0].dp);
          to.touched = true;
          const ratio = crs[0].qty / dbs[0].qty;
          let rem = dbs[0].qty; sortLots(from.lots); const moved = [];
          while (rem > 1e-9 && from.lots.length) {
            const l = from.lots[0]; const m = Math.min(l.qty, rem);
            moved.push({ ...l, qty: m * ratio }); l.qty -= m; rem -= m; if (l.qty <= 1e-9) from.lots.shift();
          }
          if (rem > 1e-9) { from.short += rem; moved.push({ qty: rem * ratio, date: null, src: 'opening', origin: 'GAP|' + gk }); }
          to.lots.push(...moved); sortLots(to.lots);
        } else {
          warnings.push(`A corporate action (ref ${e.caRef}) could not be paired — its shares may be missing.`);
        }
      }
    }
    return { book, warnings };
  }

  /* ---------- reconcile with the latest statement and produce the open lots ---------- */
  // holdings: [{acct, dp, isin, qty}] from the latest statement.  preDate(acct): the day before the
  // earliest statement period covering that account (undated shares are older than that).
  function openLots(book, holdings, preDate, warnings = []) {
    const out = [];
    for (const h of holdings) {
      const k = h.acct + '|' + h.isin;
      const b = book.get(k) || { lots: [], short: 0, touched: false };
      const lots = b.lots.map(l => ({ ...l }));
      let have = sum(lots);
      const diff = r6(h.qty - have);
      if (diff > 1e-6) {
        // Held but not explained by any event: either it was simply held throughout (no activity
        // in the periods covered — normal), or a statement is missing (only if it had activity).
        lots.unshift({ qty: diff, date: null, src: 'opening', origin: 'PRE|' + k });
        if (b.touched) warnings.push(`${h.isin}: statements explain ${r6(have)} of ${h.qty} shares — a statement covering earlier activity may be missing.`);
      } else if (diff < -1e-6) {
        warnings.push(`${h.isin}: the uploaded history shows ${r6(have)} shares but the latest statement holds ${h.qty}.`);
        let over = -diff; sortLots(lots);
        while (over > 1e-9 && lots.length) { const l = lots[lots.length - 1]; const m = Math.min(l.qty, over); l.qty -= m; over -= m; if (l.qty <= 1e-9) lots.pop(); }
      }
      // stable, unique origin per lot (a lot can be split by a partial corporate action)
      const used = {};
      const final = lots.map(l => {
        used[l.origin] = (used[l.origin] || 0) + 1;
        const undated = l.date == null;
        return {
          qty: r6(l.qty), date: undated ? preDate(h.acct) : l.date, undated, transfer: l.src === 'transfer', src: l.src,
          origin: l.origin + (used[l.origin] > 1 ? '#' + used[l.origin] : '')
        };
      });
      out.push({ acct: h.acct, dp: h.dp, isin: h.isin, qty: h.qty, lots: final });
    }
    return out;
  }

  // Convenience: everything at once.
  //   docs: ledger documents (already including any new events); snapshots: [{asOf, periods:[{acct,from,to}], holdings:[{acct,dp,isin,qty,price,...}]}]
  function compute(docs, snapshots) {
    if (!snapshots.length) return { positions: [], warnings: ['No statement holdings have been uploaded yet.'], asOf: null };
    const latest = [...snapshots].sort((a, b) => (a.asOf < b.asOf ? 1 : -1))[0];
    const { book, warnings } = replay(flatten(docs));
    const from = {};
    snapshots.forEach(s => (s.periods || []).forEach(p => { if (!from[p.acct] || p.from < from[p.acct]) from[p.acct] = p.from; }));
    const globalFrom = Object.values(from).sort()[0];
    const preDate = (acct) => dayBefore(from[acct] || globalFrom || latest.asOf);
    const positions = openLots(book, latest.holdings, preDate, warnings);
    return { positions, warnings, asOf: latest.asOf, latest };
  }

  /* ---------- how many shares, on any date (for the value-over-time chart) ---------- */
  // Prices are the *actual* traded price on each day (unadjusted), so the quantity must be the number
  // of shares actually held on that day, in the units of that day: a split multiplies the quantity on
  // its date and the price falls by the same factor on the same date, so the value doesn't move.
  // (Adjusted-to-today prices would need quantities converted to today's units, and that is impossible
  // for a stock sold before a split — the statements never record a corporate action on shares you no
  // longer held.)
  //
  // A "chain" is one security through its ISIN changes (old ISIN -> new ISIN after a split, a temporary
  // bonus ISIN -> the main one); it is identified by its final ISIN, which is also its ticker. Within a
  // chain the quantity is a·q0 + b: `q0` is what was held before the first event (shares no event
  // explains — held throughout the covered period), `a` accumulates the corporate-action ratios and `b`
  // the buys/sells/bonuses. q0 is chosen so the total lands exactly on the latest holdings.
  //   holdings: [{isin, qty}] — the latest statement, summed over accounts
  // Returns { finals: Map(isin -> {q0, steps:[{date, a, b}]}), members: Map(final -> Set(isins)),
  //           qtyAt(final, iso), roundTrips }.
  function quantityTimeline(docs, holdings) {
    const events = flatten(docs);
    const byRef = {};
    events.filter(e => e.kind === 'CA_MOVE').forEach(e => { (byRef[e.caRef + '|' + e.acct] = byRef[e.caRef + '|' + e.acct] || []).push(e); });
    const moves = {};
    const moveEvents = [];
    Object.values(byRef).forEach(grp => {
      const dbs = grp.filter(x => x.side === 'Db'), crs = grp.filter(x => x.side === 'Cr');
      if (dbs.length === 1 && crs.length === 1 && dbs[0].qty > 0) {
        const m = { date: dbs[0].date, ratio: crs[0].qty / dbs[0].qty, from: dbs[0].isin, to: crs[0].isin };
        (moves[m.from] = moves[m.from] || []).push(m);
        moveEvents.push(m);
      }
    });
    Object.values(moves).forEach(a => a.sort((x, y) => (x.date < y.date ? -1 : 1)));
    // the ISIN a holding of `isin` on `date` ends up as
    const finalOf = (isin, date) => {
      let cur = isin, d = date;
      for (let g = 0; g < 8; g++) { const m = (moves[cur] || []).find(x => x.date >= d); if (!m) break; cur = m.to; d = m.date; }
      return cur;
    };

    const members = new Map();
    const remember = (final, isin) => { if (!members.has(final)) members.set(final, new Set([final])); members.get(final).add(isin); };
    const chainEvents = new Map();                       // final ISIN -> [{date, kind, qty|ratio}]
    const add = (final, ev) => { if (!chainEvents.has(final)) chainEvents.set(final, []); chainEvents.get(final).push(ev); };
    events.filter(e => ['BUY', 'TRANSFER_IN', 'CA_NEW', 'SELL'].includes(e.kind)).forEach(e => {
      const f = finalOf(e.isin, e.date); remember(f, e.isin);
      add(f, { date: e.date, kind: e.kind, qty: e.qty });
    });
    moveEvents.forEach(m => { const f = finalOf(m.from, m.date); remember(f, m.from); remember(f, m.to); add(f, { date: m.date, kind: 'MOVE', ratio: m.ratio }); });

    // Shares that leave by a delivery and come back by a transfer of the same quantity within a few
    // months are the same shares moving between the owner's own accounts, not a sale — cancel both,
    // or the chart would show them vanishing and reappearing.
    let roundTrips = 0;
    const order = { BUY: 0, TRANSFER_IN: 0, CA_NEW: 1, MOVE: 2, SELL: 3 };
    chainEvents.forEach(list => {
      list.sort((a, b) => (a.date < b.date ? -1 : a.date > b.date ? 1 : order[a.kind] - order[b.kind]));
      list.filter(t => t.kind === 'TRANSFER_IN').forEach(t => {
        const s = list.find(x => x.kind === 'SELL' && !x.cancelled && !t.cancelled && Math.abs(x.qty - t.qty) < 1e-6
          && x.date <= t.date && (new Date(t.date) - new Date(x.date)) <= 120 * 86400000);
        if (s) { s.cancelled = t.cancelled = true; roundTrips++; }
      });
    });

    const held = new Map();
    holdings.forEach(h => held.set(h.isin, (held.get(h.isin) || 0) + h.qty));
    const finals = new Map();
    new Set([...chainEvents.keys(), ...held.keys()]).forEach(final => {
      let a = 1, b = 0;
      const steps = [];
      (chainEvents.get(final) || []).filter(x => !x.cancelled).forEach(x => {
        if (x.kind === 'MOVE') { a *= x.ratio; b *= x.ratio; }
        else if (x.kind === 'SELL') b -= x.qty;
        else b += x.qty;
        steps.push({ date: x.date, a, b });
      });
      const end = steps.length ? steps[steps.length - 1] : { a: 1, b: 0 };
      finals.set(final, { q0: ((held.get(final) || 0) - end.b) / end.a, steps });
      if (!members.has(final)) members.set(final, new Set([final]));
    });
    const qtyAt = (final, iso) => {
      const f = finals.get(final);
      if (!f) return 0;
      let lo = 0, hi = f.steps.length - 1, a = 1, b = 0;
      while (lo <= hi) { const mid = (lo + hi) >> 1; if (f.steps[mid].date <= iso) { a = f.steps[mid].a; b = f.steps[mid].b; lo = mid + 1; } else hi = mid - 1; }
      return Math.max(0, a * f.q0 + b);
    };
    return { finals, members, qtyAt, roundTrips };
  }

  return { compute, replay, openLots, quantityTimeline, mergeIntoDocs, withKeys, flatten, hash, dayBefore };
})();
