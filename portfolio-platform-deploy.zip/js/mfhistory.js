/* mfhistory.js — everything that turns several years of CDSL statements into history:
     - matching each folio to the right mfapi.in scheme, verified by ISIN
     - NAV history (cached per day in localStorage)
     - the reconstructed daily-ish value / net-invested series
     - a true XIRR over the covered window, and per-financial-year performance

   The idea: a statement gives exact units at period start, every dated purchase/redemption
   inside the period, and exact units at period end. Multiply units held on any date by that
   date's NAV (mfapi.in keeps the full history) and the portfolio's value can be replayed
   for the whole time the uploaded statements cover — no need to wait for snapshots to pile up. */

const MfHistory = (() => {
  const API = 'https://api.mfapi.in/mf';
  const CACHE_PREFIX = 'navhist_v1_';
  const memo = {};

  const DAY = 86400000;
  const toTime = (iso) => new Date(iso + 'T00:00:00Z').getTime();
  const toIso = (ms) => new Date(ms).toISOString().slice(0, 10);
  const dmyToIso = (s) => { const m = String(s).match(/(\d{2})-(\d{2})-(\d{4})/); return m ? `${m[3]}-${m[2]}-${m[1]}` : null; };
  const todayIso = () => new Date().toISOString().slice(0, 10);

  // mfapi.in occasionally stalls a request indefinitely — never errors, never completes (confirmed
  // live: a "Refresh prices" run hung forever on one fund's /latest call while every other request,
  // including a fresh probe of that exact URL seconds later, worked fine). Plain fetch() has no
  // built-in timeout, so one stuck request used to block the whole sequential refresh loop for
  // every fund after it, permanently — this is the actual cause of "refresh prices takes forever".
  async function fetchTimeout(url, ms = 8000) {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), ms);
    try { return await fetch(url, { signal: ctrl.signal }); }
    finally { clearTimeout(t); }
  }

  /* ---------- Matching a folio to the right mfapi.in scheme (ISIN-verified) ---------- */

  function isinMatches(meta, isin) {
    return !!meta && (meta.isin_growth === isin || meta.isin_div_reinvestment === isin);
  }

  async function fetchLatest(code) {
    const res = await fetchTimeout(`${API}/${code}/latest`);
    return res.json();
  }

  // mfapi.in's search matches whole words, and fund houses are inconsistent about spelling
  // ("Mid Cap" vs "Midcap", "Flexicap" vs "Flexi Cap"), so each name is tried both ways.
  function searchQueries(schemeName) {
    const base = schemeName
      .replace(/\(.*?\)/g, ' ')
      .replace(/\b(regular|direct|plan|growth|option|idcw|fund of funds?|fof)\b/gi, ' ')
      .replace(/[^A-Za-z0-9& ]/g, ' ')
      .replace(/\s+/g, ' ').trim();
    const joined = base.replace(/\b(mid|small|large|multi|flexi|blue)\s+(cap|chip)\b/gi, '$1$2');
    const split = base.replace(/\b(mid|small|large|multi|flexi|blue)(cap|chip)\b/gi, '$1 $2');
    const qs = [];
    for (const variant of [base, joined, split]) {
      const words = variant.split(' ');
      for (const n of [5, 4, 3, 2]) if (words.length >= n) qs.push(words.slice(0, n).join(' '));
    }
    return [...new Set(qs)];
  }

  // Name matching is only used to decide which candidates to *try first*; the fund is only
  // accepted once its ISIN actually matches. (An earlier name-only match picked "Aditya Birla
  // Sun Life Gilt Plus" for a Digital India fund and "Axis Large & Mid Cap" for Axis Mid Cap.)
  async function resolveSchemeCode(folio) {
    const wantDirect = /direct/i.test(folio.schemeName || '') || /direct/i.test(folio.arnCode || '');
    const tried = new Set();
    for (const q of searchQueries(folio.schemeName || '')) {
      let list = [];
      try { list = await (await fetchTimeout(`${API}/search?q=${encodeURIComponent(q)}`)).json(); } catch (e) { continue; }
      if (!Array.isArray(list)) continue;
      const scored = list.filter(c => !tried.has(c.schemeCode)).map(c => {
        const n = c.schemeName.toLowerCase();
        let s = 0;
        if (/growth/.test(n)) s += 3;
        if (/idcw|dividend|payout|reinvest|bonus/.test(n)) s -= 4;
        if (/direct/.test(n) === wantDirect) s += 3; else s -= 3;
        return { c, s };
      }).sort((a, b) => b.s - a.s).slice(0, 8);
      for (const { c } of scored) {
        tried.add(c.schemeCode);
        try {
          const data = await fetchLatest(c.schemeCode);
          if (isinMatches(data.meta, folio.isin)) return c.schemeCode;
        } catch (e) { /* try the next candidate */ }
      }
    }
    return null;
  }

  /* ---------- NAV history ---------- */

  async function getNavSeries(code, sinceIso) {
    if (memo[code]) return memo[code];
    try {
      const raw = localStorage.getItem(CACHE_PREFIX + code);
      if (raw) {
        const c = JSON.parse(raw);
        if (c.fetched === todayIso() && c.series && c.series.length) { memo[code] = c.series; return c.series; }
      }
    } catch (e) { /* ignore cache problems */ }

    const res = await fetchTimeout(`${API}/${code}`, 15000);   // the full history is a bigger payload — a little more room
    const json = await res.json();
    const cutoff = toIso(toTime(sinceIso || '2000-01-01') - 40 * DAY);
    const series = (json.data || [])
      .map(r => ({ d: dmyToIso(r.date), nav: parseFloat(r.nav) }))
      .filter(r => r.d && r.d >= cutoff && r.nav > 0)
      .sort((a, b) => a.d.localeCompare(b.d));
    memo[code] = series;
    try { localStorage.setItem(CACHE_PREFIX + code, JSON.stringify({ fetched: todayIso(), series })); } catch (e) { /* quota */ }
    return series;
  }

  // NAV on a date, carrying the last published NAV forward over weekends/holidays.
  function navOn(series, iso) {
    if (!series || !series.length) return null;
    let lo = 0, hi = series.length - 1, ans = -1;
    while (lo <= hi) {
      const mid = (lo + hi) >> 1;
      if (series[mid].d <= iso) { ans = mid; lo = mid + 1; } else hi = mid - 1;
    }
    return ans === -1 ? null : series[ans].nav;
  }

  /* ---------- Model: per-folio timeline ---------- */

  function txnBelongsTo(t, folio) {
    if (t.folioId) return t.folioId === folio.id;
    if (t.isin !== folio.isin) return false;
    return t.folioNo === folio.folioNo || (folio.folioNo || '').endsWith(t.folioNo || '~') || (t.folioNo || '').endsWith(folio.folioNo || '~');
  }

  async function loadModel() {
    const [folios, periods, txns] = await Promise.all([Mf.getAllFolios(), Mf.getAllPeriods(), Mf.getAllTransactions()]);
    const models = folios.map(f => {
      const ps = periods.filter(p => p.folioId === f.id).sort((a, b) => a.periodStart.localeCompare(b.periodStart));
      // eff = the date a transaction counts from: a purchase allotted just before the period
      // (dated e.g. 28-Mar but reported in the period starting 1-Apr) belongs to that period.
      const ft = txns.filter(t => txnBelongsTo(t, f))
        .map(t => ({ ...t, eff: t.periodStart && t.date < t.periodStart ? t.periodStart : t.date }))
        .sort((a, b) => a.eff.localeCompare(b.eff));
      return { folio: f, periods: ps, txns: ft, start: ps.length ? ps[0].periodStart : null, series: null };
    }).filter(m => m.periods.length);
    return { models, periods, txns };
  }

  async function attachNavSeries(models) {
    const startAll = models.reduce((m, x) => (!m || x.start < m ? x.start : m), null);
    for (const m of models) {
      let code = m.folio.mfapiSchemeCode;
      if (!code) {
        // A failed lookup is remembered for the day so an unmatchable fund doesn't trigger
        // a dozen search requests on every page load.
        const key = 'navresolve_' + m.folio.isin;
        let triedToday = false;
        try { triedToday = localStorage.getItem(key) === todayIso(); } catch (e) { /* ignore */ }
        if (!triedToday) {
          try { code = await resolveSchemeCode(m.folio); } catch (e) { code = null; }
          // A failed cache write (offline, a Firestore hiccup) shouldn't take down the whole chart —
          // the code just gets looked up again next time.
          if (code) { try { await DB.updateDoc('mf_folios', m.folio.id, { mfapiSchemeCode: code }); } catch (e) { /* try again next load */ } }
          else { try { localStorage.setItem(key, todayIso()); } catch (e) { /* ignore */ } }
        }
      }
      m.code = code || null;
      if (code) {
        try { m.series = await getNavSeries(code, startAll); } catch (e) { m.series = null; }
      }
    }
  }

  function unitsAt(m, iso) {
    if (!m.start || iso < m.start) return 0;
    let u = m.periods[0].openingUnits || 0;
    for (const t of m.txns) if (t.eff >= m.start && t.eff <= iso) u += t.units || 0;
    return u;
  }

  // Price for a folio on a date. Falls back to the statement's own NAVs (nearest period-end)
  // when the fund has no NAV history — coarser, but never leaves a fund out of the total.
  function priceAt(m, iso) {
    // On a statement's own date, trust the statement: CDSL sometimes values at the next NAV
    // when that date was a market holiday (31-Mar-2026 was), which the NAV feed doesn't repeat.
    const stmt = m.periods.find(per => per.periodEnd === iso && per.closingNav != null);
    if (stmt) return { nav: stmt.closingNav, exact: true };
    const p = navOn(m.series, iso);
    if (p != null) return { nav: p, exact: true };
    // Known price points: each statement's closing NAV, plus the NAV printed on every transaction.
    const points = m.periods.filter(per => per.closingNav != null).map(per => ({ d: per.periodEnd, nav: per.closingNav }))
      .concat(m.txns.filter(t => t.nav > 0).map(t => ({ d: t.date, nav: t.nav })));
    let best = null;
    for (const pt of points) {
      const dist = Math.abs(toTime(pt.d) - toTime(iso));
      if (!best || dist < best.dist) best = { dist, nav: pt.nav };
    }
    return best ? { nav: best.nav, exact: false } : { nav: 0, exact: false };
  }

  /* ---------- Reconstructed series ---------- */

  // extraDates: dates the caller also wants exact values for (e.g. month-ends, to pair with
  // the CDSL's month-end portfolio totals).
  async function buildSeries(extraDates = []) {
    const { models, periods } = await loadModel();
    if (!models.length) return { points: [], startDate: null, unresolved: [] };
    await attachNavSeries(models);

    const startDate = models.reduce((m, x) => (!m || x.start < m ? x.start : m), null);
    const today = todayIso();

    const dates = new Set([startDate, today, ...extraDates]);
    periods.forEach(p => { if (p.periodEnd) dates.add(p.periodEnd); });
    for (let t = toTime(startDate); t <= toTime(today); t += 7 * DAY) dates.add(toIso(t));
    const sorted = [...dates].filter(d => d >= startDate && d <= today).sort();

    // Net invested = market value at the start + purchases − redemption proceeds up to each date.
    const openingValue = models.reduce((s, m) => s + unitsAt(m, m.start) * priceAt(m, m.start).nav, 0);
    const points = sorted.map(d => {
      let value = 0, netInvested = openingValue;
      for (const m of models) {
        value += unitsAt(m, d) * priceAt(m, d).nav;
        for (const t of m.txns) {
          if (t.eff > startDate && t.eff <= d) netInvested += t.type === 'redemption' ? -Math.abs(t.amount || 0) : (t.amount || 0);
        }
      }
      return { date: d, value, netInvested };
    });
    const unresolved = models.filter(m => !m.series).map(m => m.folio.schemeName);
    return { points, startDate, unresolved, models };
  }

  /* ---------- XIRR over the window the statements cover ---------- */

  async function xirrWindow() {
    const { models } = await loadModel();
    if (!models.length) return null;
    await attachNavSeries(models);
    const startDate = models.reduce((m, x) => (!m || x.start < m ? x.start : m), null);
    const today = todayIso();
    const flows = [];
    let current = 0;
    for (const m of models) {
      const open = unitsAt(m, m.start) * priceAt(m, m.start).nav;
      if (open > 0) flows.push({ date: new Date(m.start + 'T00:00:00Z'), amount: -open });
      for (const t of m.txns) {
        if (t.eff <= m.start) continue; // already inside the opening value
        // purchases are money in (negative for XIRR), redemptions are money out (positive)
        const amt = t.type === 'redemption' ? Math.abs(t.amount || 0) : -(t.amount || 0);
        if (amt) flows.push({ date: new Date(t.eff + 'T00:00:00Z'), amount: amt });
      }
      current += unitsAt(m, today) * priceAt(m, today).nav;
    }
    flows.sort((a, b) => a.date - b.date);
    // `flows` excludes the closing value so callers can add other assets' flows before solving.
    const x = Calc.xirr([...flows, { date: new Date(today + 'T00:00:00Z'), amount: current }]);
    return { xirr: x, startDate, currentValue: current, flows };
  }

  /* ---------- Performance per statement period (financial year) ---------- */

  async function performanceByPeriod() {
    const { models, periods } = await loadModel();
    if (!models.length) return [];
    await attachNavSeries(models);
    const starts = [...new Set(periods.map(p => p.periodStart))].sort();
    const rows = [];
    for (const ps of starts) {
      const inPeriod = periods.filter(p => p.periodStart === ps);
      const periodEnd = inPeriod[0].periodEnd;
      const prevEnd = toIso(toTime(ps) - DAY);

      let begin = 0, end = 0, purchases = 0, redemptions = 0, weighted = 0;
      const span = toTime(periodEnd) - toTime(ps);
      for (const p of inPeriod) {
        const m = models.find(x => x.folio.id === p.folioId);
        if (!m) continue;
        // start-of-period value: the previous statement's exact closing figure if one exists,
        // otherwise opening units at that date's NAV.
        const prev = periods.find(q => q.folioId === p.folioId && q.periodEnd === prevEnd);
        begin += prev ? (prev.valuation || 0) : (p.openingUnits || 0) * priceAt(m, prevEnd).nav;
        end += p.valuation || 0;
        for (const t of m.txns) {
          if (t.eff < ps || t.eff > periodEnd) continue;
          const amt = Math.abs(t.amount || 0);
          const frac = span > 0 ? (toTime(periodEnd) - toTime(t.eff)) / span : 0;
          if (t.type === 'redemption') { redemptions += amt; weighted -= amt * frac; }
          else { purchases += amt; weighted += amt * frac; }
        }
      }
      const gain = end - begin - purchases + redemptions;
      const base = begin + weighted;
      rows.push({ periodStart: ps, periodEnd, begin, end, purchases, redemptions, gain, returnPct: base > 0 ? (gain / base) * 100 : null });
    }
    return rows;
  }

  /* ---------- Redemptions / realized gains (cost basis is user-supplied) ---------- */

  async function realizedSummary() {
    const txns = (await Mf.getAllTransactions()).filter(t => t.type === 'redemption');
    let stcg = 0, ltcg = 0, proceeds = 0, needCost = [];
    txns.forEach(t => {
      const p = Math.abs(t.amount || 0);
      proceeds += p;
      if (t.costBasis == null) { needCost.push(t); return; }
      const gain = p - t.costBasis;
      if (t.term === 'STCG') stcg += gain; else ltcg += gain;
    });
    return { redemptions: txns, proceeds, stcg, ltcg, total: stcg + ltcg, needCost };
  }

  return { resolveSchemeCode, isinMatches, fetchLatest, getNavSeries, navOn, buildSeries, xirrWindow, performanceByPeriod, realizedSummary };
})();
