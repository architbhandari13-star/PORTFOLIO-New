/* app.js — bootstrap, navigation, and view rendering. */

const App = (() => {
  let currentView = 'dashboard';

  const VIEW_META = {
    dashboard: { title: 'Overview', subtitle: 'Everything, in one place.' },
    mf: { title: 'Mutual Funds', subtitle: 'Holdings sourced from your CDSL statements.' },
    equity: { title: 'Equity', subtitle: 'Imported from your statements, plus anything you add by hand.' },
    transactions: { title: 'Transactions', subtitle: 'Full history across both asset classes.' }
  };

  /* ---------- Data joins ---------- */
  async function computeMfHoldings() {
    const [folios, cache] = await Promise.all([Mf.getAllFolios(), Pricing.getCache()]);
    return folios.map(f => {
      const live = cache[Pricing.mfKey(f.isin)];
      const nav = (live && live.price) || f.nav;
      const value = (f.closingUnits || 0) * (nav || 0);
      const invested = f.cumulativeInvested || 0;
      return {
        ...f, liveNav: nav, navIsLive: !!live, navDate: (live && live.navDate) || f.navDate,
        value, invested, gain: value - invested, gainPct: invested > 0 ? ((value - invested) / invested) * 100 : 0
      };
    });
  }

  async function computeEquityHoldings() {
    const [holdings, cache] = await Promise.all([Equity.computeHoldings(), Pricing.getCache()]);
    return holdings.map(h => {
      const live = cache[Pricing.eqKey(h.symbol, h.exchange)];
      const ltp = (live && live.price) || h.avgCost;
      const invested = h.qty * h.avgCost;
      const value = h.qty * ltp;
      return {
        ...h, ltp, ltpIsLive: !!live, dayChangePct: live && live.changePct,
        invested, value, gain: value - invested, gainPct: invested > 0 ? ((value - invested) / invested) * 100 : 0
      };
    });
  }

  async function snapshotValueHistory(totalInvested, totalValue, mfValue, eqValue) {
    const today = new Date().toISOString().slice(0, 10);
    await DB.setDoc('value_history', today, { date: today, invested: totalInvested, value: totalValue, mfValue, eqValue });
  }

  /* ---------- KPI rendering ---------- */
  function kpiCard(label, value, sub, subClass, valueId) {
    return `<div class="kpi-card">
      <div class="kpi-label">${label}</div>
      <div class="kpi-value" ${valueId ? `id="${valueId}"` : ''}>${value}</div>
      ${sub ? `<div class="kpi-sub ${subClass || ''}">${sub}</div>` : ''}
    </div>`;
  }

  function pctSpan(pct) {
    if (pct == null || isNaN(pct)) return '';
    const cls = pct >= 0 ? 'up' : 'down';
    return { cls, text: (pct >= 0 ? '+' : '') + pct.toFixed(2) + '%' };
  }

  // profit/loss as a soft coloured chip: "₹1,23,456 · +12.3%"
  function pnlChip(gain, pct) {
    const up = gain >= 0;
    return `<span class="chip ${up ? 'up' : 'down'}">${Charts.money(gain)}<i>${up ? '+' : ''}${pct.toFixed(1)}%</i></span>`;
  }

  const fmtDate = (iso) => new Date(iso + 'T00:00:00Z').toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric', timeZone: 'UTC' });
  const fyLabel = (start, end) => `FY ${start.slice(0, 4)}-${end.slice(2, 4)}`;

  // Equity that goes into a return figure: only stocks whose every trade date is real. Imported
  // positions have estimated dates (the books hold none), so including them would print a
  // made-up percentage — they are left out of both the cash flows and the closing value.
  function equityXirrInputs(eqH) {
    const usable = eqH.filter(h => !h.hasEstimatedDates);
    return {
      flows: usable.flatMap(h => h.cashflows),
      value: usable.reduce((s, h) => s + h.value, 0),
      excluded: eqH.filter(h => h.hasEstimatedDates && h.qty > 1e-9).length
    };
  }

  // Used only until a fund's statements cover it: pre-period capital approximated as one lump.
  function legacyXirr(mfTxns, mfFolios, eqH, totalValue) {
    const eq = equityXirrInputs(eqH);
    const cashflows = [];
    mfTxns.forEach(t => { if (t.type === 'purchase') cashflows.push({ date: new Date(t.date), amount: -(t.amount || t.units * t.nav) }); });
    mfFolios.forEach(f => { if (f.preOpeningInvested > 0 && f.periodStart) cashflows.push({ date: new Date(f.periodStart), amount: -f.preOpeningInvested }); });
    eq.flows.forEach(cf => cashflows.push(cf));
    cashflows.sort((a, b) => a.date - b.date);
    if (!cashflows.length) return null;
    // totalValue counts all equity; only the equity that has flows above belongs in the terminal value
    const allEq = eqH.reduce((s, h) => s + h.value, 0);
    cashflows.push({ date: new Date(), amount: totalValue - allEq + eq.value });
    return cashflows.length > 1 ? Calc.xirr(cashflows) : null;
  }

  /* ---------- Views ---------- */
  async function renderDashboard() {
    const [mfAll, eqH, mfTxns, mfFolios, mfReal] = await Promise.all([
      computeMfHoldings(), computeEquityHoldings(), Mf.getAllTransactions(), Mf.getAllFolios(), MfHistory.realizedSummary()
    ]);
    const mfH = mfAll.filter(h => (h.closingUnits || 0) > 1e-9);

    const mfInvested = mfH.reduce((s, h) => s + h.invested, 0);
    const mfValue = mfH.reduce((s, h) => s + h.value, 0);
    const eqInvested = eqH.reduce((s, h) => s + h.invested, 0);
    const eqValue = eqH.reduce((s, h) => s + h.value, 0);
    const totalInvested = mfInvested + eqInvested;
    const totalValue = mfValue + eqValue;
    const totalGain = totalValue - totalInvested;
    const totalGainPct = totalInvested > 0 ? (totalGain / totalInvested) * 100 : 0;

    const eqRealized = eqH.reduce((s, h) => s + (h.realizedSum ? h.realizedSum.total : 0), 0);
    const stcg = eqH.reduce((s, h) => s + (h.realizedSum ? h.realizedSum.stcg : 0), 0) + mfReal.stcg;
    const ltcg = eqH.reduce((s, h) => s + (h.realizedSum ? h.realizedSum.ltcg : 0), 0) + mfReal.ltcg;
    const realizedTotal = eqRealized + mfReal.total;
    const realizedNote = mfReal.needCost.length
      ? `${mfReal.needCost.length} MF redemption${mfReal.needCost.length > 1 ? "s need" : " needs"} a cost basis`
      : '';

    await snapshotValueHistory(totalInvested, totalValue, mfValue, eqValue);

    const gp = pctSpan(totalGainPct);
    document.getElementById('kpiRow').innerHTML = [
      kpiCard('Total invested', Charts.money(totalInvested)),
      kpiCard('Current value', Charts.money(totalValue)),
      kpiCard('Unrealized P&amp;L', Charts.money(totalGain), gp.text, gp.cls),
      kpiCard('XIRR', '…', '', '', 'kpiXirrVal'),
      kpiCard('Realized gains', Charts.money(realizedTotal), realizedNote, '')
    ].join('');

    Charts.renderAllocation('allocationChart', [
      { label: 'Mutual Funds', value: mfValue },
      { label: 'Equity', value: eqValue }
    ].filter(s => s.value > 0));
    Charts.renderStcgLtcg('stcgLtcgChart', { stcg, ltcg });

    const movers = eqH.filter(h => h.qty > 1e-9).concat(mfH)
      .map(h => ({ name: h.companyName || h.schemeName, pct: h.gainPct }))
      .sort((a, b) => Math.abs(b.pct) - Math.abs(a.pct)).slice(0, 6);
    document.getElementById('topMovers').innerHTML = movers.length ? movers.map(m =>
      `<div class="mover-row"><span class="mover-name">${m.name}</span><span class="mover-pct ${m.pct >= 0 ? 'pos' : 'neg'}">${(m.pct >= 0 ? '+' : '') + m.pct.toFixed(1)}%</span></div>`
    ).join('') : '<p class="muted">No holdings yet.</p>';

    // Chart + XIRR need NAV history from the network, so they fill in after the page is usable.
    paintDashboardHistory({ eqH, eqValue, mfTxns, mfFolios, totalValue }).catch(err => console.warn('history failed', err));
  }

  // Equity over time. There is no free source of historical share prices, so the line is built
  // from what the CDSL itself prints: every statement carries the value of the WHOLE CDSL portfolio
  // at each month-end. Equity at a month-end = that total − mutual funds (reconstructed from NAV
  // history) − bonds/gold/demat funds (known at each statement date, interpolated between them).
  // At statement dates the equity figure is CDSL's own, exact; between them it is an estimate whose
  // error is the drift of the small non-equity slice and of the fund NAVs (~1%).
  // After the last statement, the daily snapshots (live prices) continue the line.
  function equityTimeline(eqSnaps, snapshots, mfBuilt) {
    const monthly = new Map(), classPts = [];
    eqSnaps.forEach(s => {
      (s.monthly || []).forEach(m => monthly.set(m.date, m.total));
      if (s.classes) classPts.push({ date: s.asOf, ...s.classes });
    });
    classPts.sort((a, b) => a.date.localeCompare(b.date));
    const t = (d) => new Date(d + 'T00:00:00Z').getTime();
    const nonEq = (d) => {
      const pts = classPts.map(c => ({ d: c.date, v: (c.debt || 0) + (c.others || 0) + (c.mfDemat || 0) }));
      if (!pts.length) return 0;
      if (d <= pts[0].d) return pts[0].v;
      if (d >= pts[pts.length - 1].d) return pts[pts.length - 1].v;
      const i = pts.findIndex(p => p.d >= d), a = pts[i - 1], b = pts[i];
      return a.v + (b.v - a.v) * (t(d) - t(a.d)) / (t(b.d) - t(a.d));
    };
    const mfAt = (d) => { const p = mfBuilt.points.find(x => x.date === d); return p ? p.value : (mfBuilt.points.length ? null : 0); };

    const eq = new Map(), total = new Map();
    for (const d of [...monthly.keys()].sort()) {
      const exact = classPts.find(c => c.date === d);
      const mf = mfAt(d);
      if (mf == null) continue;
      const v = exact ? exact.equity : Math.max(0, monthly.get(d) - mf - nonEq(d));
      eq.set(d, v); total.set(d, v + mf);
    }
    classPts.forEach(c => { if (!eq.has(c.date) && c.equity) { const mf = mfAt(c.date); if (mf != null) { eq.set(c.date, c.equity); total.set(c.date, c.equity + mf); } } });
    const lastStatement = [...eq.keys()].sort().pop() || '';
    snapshots.filter(s => (s.eqValue || 0) > 0 && s.date > lastStatement).forEach(s => { eq.set(s.date, s.eqValue); total.set(s.date, s.value); });
    const toPts = (m) => [...m.entries()].sort((a, b) => a[0].localeCompare(b[0])).map(([date, value]) => ({ date, value }));
    return { equity: toPts(eq), total: toPts(total), monthEnds: [...monthly.keys()].sort() };
  }

  // What the Overview chart last showed, so switching to another tab and back doesn't redo the work.
  // It is only reused while nothing that feeds it has changed (DB.version), it is still the same day,
  // and the live equity/total values are the same.
  let historyCache = null;

  // Builds the chart's equity + total series from a result (either freshly computed, or read
  // straight from the cache) and draws it — the one path both the cache hit and a live rebuild
  // use, so the line is replaced in one step either way, never redrawn twice in view.
  function applyEquitySeries(series, built, eqSnaps, points, cache) {
    const mfAt = new Map(built.points.map(p => [p.date, p.value]));
    const equity = points.filter(p => p.value > 0);
    const total = equity.filter(p => mfAt.has(p.date)).map(p => ({ date: p.date, value: p.value + mfAt.get(p.date) }));
    const stmt = eqSnaps.filter(s => s.classes && s.classes.equity).map(s => ({ date: s.asOf, value: s.classes.equity }));
    const next = series.filter(s => !['eq', 'total'].includes(s.style));
    next.push({ label: 'Equity (daily prices)', style: 'eq', points: equity });
    if (total.length) next.push({ label: 'Total (MF + equity)', style: 'total', points: total });
    if (stmt.length) next.push({ label: 'Equity per CDSL statement', style: 'stmt', points: stmt });
    Charts.renderValueTrend('valueTrendChart', next);
    if (cache) cache.series = next;
    return next;
  }
  function describeResult(res) {
    const worst = res.validation.length ? Math.max(...res.validation.map(v => Math.abs(v.diffPct))) : 0;
    // The source/match-rate detail and any per-symbol failures aren't dropped, just moved off the
    // visible line and into the hover tooltip, so the subtitle stays short.
    const detail = `${priceSourceNote(res)} — matches your CDSL statements within ${worst.toFixed(1)}%`;
    const failures = priceFailureDetail(res);
    return {
      text: 'Funds from NAV history · equity from daily share prices',
      tip: failures ? `${detail}\n\n${failures}` : detail
    };
  }

  async function upgradeEquityLine(series, built, eqSnaps, cache) {
    const sub = document.getElementById('valueTrendSub');
    // Equity's daily-price line doesn't need mutual fund history to exist — only "Total (MF +
    // equity)" does. Bailing out here whenever MF history was empty or hadn't resolved yet (the
    // ordinary state before any MF statement is uploaded, or while a scheme code is being looked
    // up) used to leave the subtitle on its static placeholder forever, looking like the chart
    // had simply stopped working.
    if (!eqSnaps.length) return;
    const dates = [...new Set([...built.points.map(p => p.date), ...eqSnaps.map(s => s.asOf)])].sort();
    const setSub = (t, tip) => { if (sub) { sub.textContent = t; sub.title = tip || ''; } };
    const today = new Date().toISOString().slice(0, 10);

    // Fast path: nothing about the holdings has changed since this was last built (same
    // generation) — read the finished series straight from Firestore instead of re-reading every
    // symbol's price history and re-validating. No progress text: there is nothing to wait for.
    const [generation, cached] = await Promise.all([EqHistory.getGeneration(), EqHistory.readCachedSeries()]);
    const cacheMatches = cached && cached.generation === generation;
    // Only true once something has actually been drawn from the cache — a stale-but-once-failed
    // cache (ok:false) never put a line on screen, so there is nothing to "leave in place" below.
    let shownFromCache = false;
    if (cacheMatches && cached.ok && cached.points && cached.points.length) {
      applyEquitySeries(series, built, eqSnaps, cached.points, cache);
      const d = describeResult(cached);
      setSub(d.text, d.tip); if (cache) { cache.sub = d.text; cache.subTitle = d.tip; }
      shownFromCache = true;
      // one day stale: the line above is already showing (correct as of yesterday's close), so the
      // catch-up below can run silently and just replace it in place when it's ready.
    }
    if (cacheMatches && cached.computedDate === today) {
      // Already tried today under these exact holdings — whether it reconciled or not, retrying
      // right now would just get the same answer (prices haven't moved again yet). Skip the search
      // entirely; a data change (bumps the generation) or a new day will trigger the next attempt.
      if (!cached.ok) {
        const t = 'Funds from NAV history · equity estimated from your CDSL month-end totals';
        setSub(t, 'Daily prices did not reconcile with your statements.'); if (cache) { cache.sub = t; cache.subTitle = 'Daily prices did not reconcile with your statements.'; }
      }
      return;
    }

    // Live rebuild — either there was no usable cache, it's a day (or more) old, or the last
    // attempt today failed to reconcile. Silent: the search itself is never shown, the line is
    // only ever swapped once, when the new result lands.
    const res = await EqHistory.buildEquitySeries({ dates });
    if (!res) return;
    if (!res.ok) {
      // the price-based figure did not reproduce CDSL's own equity value: don't show a number we can't stand behind
      if (!shownFromCache) {
        const t = 'Funds from NAV history · equity estimated from your CDSL month-end totals';
        setSub(t, 'Daily prices did not reconcile with your statements.'); if (cache) { cache.sub = t; cache.subTitle = 'Daily prices did not reconcile with your statements.'; }
      }
      // else: leave yesterday's still-reconciled cached line on screen rather than replace it with an estimate
      await EqHistory.writeCachedSeries(res, generation);
      return;
    }
    applyEquitySeries(series, built, eqSnaps, res.points, cache);
    const d = describeResult(res);
    setSub(d.text, d.tip); if (cache) { cache.sub = d.text; cache.subTitle = d.tip; }
    await EqHistory.writeCachedSeries(res, generation);
  }

  // "all 120 price histories from saved data" / "117 of 120 …, 3 updated just now" / "39 of 120 …; 81 unavailable (timed out ×80, unknown symbol ×1)"
  function priceSourceNote(res) {
    const failed = res.failed || [];
    let s = res.saved >= res.total ? `all ${res.total} price histories` : `${res.saved} of ${res.total} price histories`;
    s += res.downloaded ? `, ${res.downloaded} updated just now, the rest from saved data` : ' from saved data';
    if (failed.length) {
      const counts = {};
      failed.forEach(f => { const r = String(f.reason).replace(/\s*\(.*\)$/, ''); counts[r] = (counts[r] || 0) + 1; });
      s += `; ${failed.length} unavailable (${Object.entries(counts).map(([r, n]) => `${r} ×${n}`).join(', ')})`;
    }
    return s;
  }
  const priceFailureDetail = (res) => (res.failed || []).length ? (res.failed.map(f => `${f.symbol}: ${f.reason}`).join('\n')) : '';

  async function paintDashboardHistory({ eqH, eqValue, mfTxns, mfFolios, totalValue }) {
    // Back on the Overview with nothing changed since it was last drawn: show what was worked out then.
    const key = `${DB.version}|${new Date().toISOString().slice(0, 10)}|${Math.round(eqValue)}|${Math.round(totalValue)}`;
    if (historyCache && historyCache.key === key && historyCache.ready) {
      Charts.renderValueTrend('valueTrendChart', historyCache.series);
      const sub = document.getElementById('valueTrendSub');
      if (sub && historyCache.sub) { sub.textContent = historyCache.sub; sub.title = historyCache.subTitle || ''; }
      const el = document.getElementById('kpiXirrVal');
      if (el) {
        el.textContent = historyCache.xirrText;
        if (historyCache.xirrNote && !el.parentElement.querySelector('.kpi-sub')) el.parentElement.insertAdjacentHTML('beforeend', historyCache.xirrNote);
      }
      return;
    }
    const cache = { key, series: null, sub: null, subTitle: '', xirrText: '—', xirrNote: '', ready: false };
    historyCache = cache;
    try {
      const [eqSnaps, snaps] = await Promise.all([DB.getAll('equity_snapshots'), DB.getAll('value_history')]);
      const snapshots = snaps.sort((a, b) => a.date.localeCompare(b.date));
      const monthEnds = [...new Set(eqSnaps.flatMap(s => (s.monthly || []).map(m => m.date)))].sort();
      // MF history and the XIRR window each do their own scheme-code lookups over the network;
      // one failing (a flaky NAV lookup, a Firestore write hiccup) must not also take down the
      // other, or the equity side, or leave the chart blank with nothing but a console warning.
      const [built, win] = await Promise.all([
        MfHistory.buildSeries(monthEnds).catch(err => { console.warn('MF history failed', err); return { points: [], startDate: null, unresolved: [] }; }),
        MfHistory.xirrWindow().catch(err => { console.warn('XIRR window failed', err); return null; })
      ]);

      const series = [];
      if (built.points.length) {
        series.push({ label: 'Mutual funds', style: 'area', points: built.points.map(p => ({ date: p.date, value: p.value })) });
        series.push({ label: `MF net invested (from ${fmtDate(built.startDate)})`, style: 'dashed', points: built.points.map(p => ({ date: p.date, value: p.netInvested })) });
      }
      const tl = equityTimeline(eqSnaps, snapshots, built);
      if (tl.equity.length) {
        series.push({ label: 'Equity', style: 'eq', points: tl.equity });
        series.push({ label: 'Total (MF + equity)', style: 'total', points: tl.total });
      }
      if (!series.length) series.push({ label: 'Portfolio value', style: 'area', points: snapshots.map(s => ({ date: s.date, value: s.value })) });
      Charts.renderValueTrend('valueTrendChart', series);
      cache.series = series;

      // The month-end estimate above is instant. The real thing — quantity held × the actual daily share
      // price — is read from the saved price history (and only what is missing is downloaded), so it
      // upgrades the chart afterwards.
      upgradeEquityLine(series, built, eqSnaps, cache).catch(err => console.warn('daily-price equity line failed', err));

      let xirr = null;
      const eq = equityXirrInputs(eqH);
      if (win) {
        const flows = [...win.flows, ...eq.flows];
        flows.sort((a, b) => a.date - b.date);
        flows.push({ date: new Date(), amount: win.currentValue + eq.value });
        xirr = Calc.xirr(flows);
      } else {
        xirr = legacyXirr(mfTxns, mfFolios, eqH, totalValue);
      }
      const el = document.getElementById('kpiXirrVal');
      if (el) el.textContent = xirr != null ? (xirr * 100).toFixed(1) + '%' : '—';
      const sub = el && el.parentElement.querySelector('.kpi-sub');
      cache.xirrText = xirr != null ? (xirr * 100).toFixed(1) + '%' : '—';
      if (el && !sub && win) {
        const note = eq.excluded ? ` · excludes ${eq.excluded} imported stock${eq.excluded > 1 ? 's' : ''} (no trade dates)` : '';
        cache.xirrNote = `<div class="kpi-sub muted-sub">since ${fmtDate(win.startDate)}${note}</div>`;
        el.parentElement.insertAdjacentHTML('beforeend', cache.xirrNote);
      }
      cache.ready = true;
    } catch (err) {
      // Something in the chain above threw outright (not just a rejected fetch) — the chart must
      // still show *something* rather than sit blank with only a console message the owner never sees.
      console.error('Overview chart failed to build', err);
      let fallback = [];
      try {
        const snaps = await DB.getAll('value_history');
        const pts = snaps.sort((a, b) => a.date.localeCompare(b.date)).map(s => ({ date: s.date, value: s.value }));
        if (pts.length) fallback = [{ label: 'Portfolio value', style: 'area', points: pts }];
      } catch (e) { /* even the plain fallback failed — leave the chart empty, not broken */ }
      Charts.renderValueTrend('valueTrendChart', fallback);
      cache.series = fallback;
      const sub = document.getElementById('valueTrendSub');
      const msg = "Couldn't rebuild the chart from your mutual fund / equity history" + (fallback.length ? ' — showing the plain daily total instead.' : '.') + ' Reload the page to try again.';
      if (sub) { sub.textContent = msg; sub.title = String((err && err.message) || err); }
      cache.sub = msg; cache.subTitle = String((err && err.message) || err);
      cache.ready = true;
    }
  }

  async function renderMfView() {
    const mfAll = (await computeMfHoldings());
    const mfH = mfAll.filter(h => (h.closingUnits || 0) > 1e-9).sort((a, b) => b.value - a.value);
    const closed = mfAll.filter(h => (h.closingUnits || 0) <= 1e-9);
    const invested = mfH.reduce((s, h) => s + h.invested, 0);
    const value = mfH.reduce((s, h) => s + h.value, 0);
    const gp = pctSpan(invested > 0 ? ((value - invested) / invested) * 100 : 0);
    document.getElementById('mfKpiRow').innerHTML = [
      kpiCard('Invested', Charts.money(invested)),
      kpiCard('Current value', Charts.money(value)),
      kpiCard('Unrealized P&amp;L', Charts.money(value - invested), gp.text, gp.cls),
      kpiCard('XIRR', '…', '', '', 'mfXirrVal'),
      kpiCard('Funds held', mfH.length, closed.length ? `${closed.length} fully redeemed` : '', '')
    ].join('');

    const table = document.getElementById('mfHoldingsTable');
    if (!mfH.length) {
      table.innerHTML = '<tbody><tr><td class="muted">No mutual fund holdings yet — upload a CDSL statement to get started.</td></tr></tbody>';
    } else {
      table.innerHTML = `
        <thead><tr><th>Scheme</th><th>AMC</th><th class="num">Units</th><th class="num">NAV</th><th class="num">Invested</th><th class="num">Value</th><th class="num">P&amp;L</th><th></th></tr></thead>
        <tbody>${mfH.map(h => `
          <tr>
            <td><div class="cell-name">${h.schemeName}</div><div class="cell-sub">${h.folioNo || ''}</div></td>
            <td class="amc">${h.amcName || '—'}</td>
            <td class="num">${(h.closingUnits || 0).toLocaleString('en-IN', { maximumFractionDigits: 3 })}</td>
            <td class="num">${h.liveNav ? h.liveNav.toFixed(2) : '—'}${h.navIsLive ? '<span class="live-dot" title="Live NAV"></span>' : ''}</td>
            <td class="num">${Charts.money(h.invested)}</td>
            <td class="num">${Charts.money(h.value)}</td>
            <td class="num">${pnlChip(h.gain, h.gainPct)}</td>
            <td><button class="icon-btn" title="Edit scheme name" data-edit-folio="${h.id}">✎</button></td>
          </tr>`).join('')}</tbody>`;
    }

    paintMfExtras(closed).catch(err => console.warn('mf extras failed', err));
  }

  // Year-by-year performance, fully-redeemed funds, and the XIRR — these depend on statement
  // history and NAV history, so they load after the holdings table is already on screen.
  async function paintMfExtras(closedFolios) {
    const perfEl = document.getElementById('mfPerfTable');
    const closedCard = document.getElementById('mfClosedCard');
    const closedEl = document.getElementById('mfClosedTable');
    perfEl.innerHTML = '<tbody><tr><td class="muted">Loading history…</td></tr></tbody>';

    const [win, perf, real] = await Promise.all([MfHistory.xirrWindow(), MfHistory.performanceByPeriod(), MfHistory.realizedSummary()]);

    const x = document.getElementById('mfXirrVal');
    if (x) {
      x.textContent = win && win.xirr != null ? (win.xirr * 100).toFixed(1) + '%' : '—';
      if (win && !x.parentElement.querySelector('.kpi-sub')) x.parentElement.insertAdjacentHTML('beforeend', `<div class="kpi-sub muted-sub">since ${fmtDate(win.startDate)}</div>`);
    }

    perfEl.innerHTML = !perf.length
      ? '<tbody><tr><td class="muted">Upload a statement to see year-by-year performance.</td></tr></tbody>'
      : `<thead><tr><th>Period</th><th class="num">Opening value</th><th class="num">Added</th><th class="num">Withdrawn</th><th class="num">Closing value</th><th class="num">Gain</th><th class="num">Return</th></tr></thead>
         <tbody>${perf.map(r => `
           <tr>
             <td><div class="cell-name">${fyLabel(r.periodStart, r.periodEnd)}</div><div class="cell-sub">${fmtDate(r.periodStart)} – ${fmtDate(r.periodEnd)}</div></td>
             <td class="num">${Charts.money(r.begin)}</td>
             <td class="num">${Charts.money(r.purchases)}</td>
             <td class="num">${r.redemptions ? Charts.money(r.redemptions) : '—'}</td>
             <td class="num">${Charts.money(r.end)}</td>
             <td class="num ${r.gain >= 0 ? 'pos' : 'neg'}">${Charts.money(r.gain)}</td>
             <td class="num ${r.returnPct >= 0 ? 'pos' : 'neg'}">${r.returnPct == null ? '—' : (r.returnPct >= 0 ? '+' : '') + r.returnPct.toFixed(1) + '%'}</td>
           </tr>`).join('')}</tbody>`;

    const redeemed = real.redemptions;
    closedCard.hidden = !redeemed.length;
    if (redeemed.length) {
      closedEl.innerHTML = `
        <thead><tr><th>Fund</th><th>Redeemed on</th><th class="num">Units</th><th class="num">Proceeds</th><th class="num">Cost basis</th><th class="num">Gain</th><th></th></tr></thead>
        <tbody>${redeemed.sort((a, b) => b.date.localeCompare(a.date)).map(t => {
          const proceeds = Math.abs(t.amount || 0);
          const hasCost = t.costBasis != null;
          const gain = hasCost ? proceeds - t.costBasis : null;
          return `<tr>
            <td><div class="cell-name">${t.schemeName}</div></td>
            <td class="nowrap">${fmtDate(t.date)}</td>
            <td class="num">${Math.abs(t.units || 0).toLocaleString('en-IN', { maximumFractionDigits: 3 })}</td>
            <td class="num">${Charts.money(proceeds)}</td>
            <td class="num">${hasCost ? Charts.money(t.costBasis) : '<span class="cell-sub">not entered</span>'}</td>
            <td class="num ${gain == null ? '' : gain >= 0 ? 'pos' : 'neg'}">${gain == null ? '—' : Charts.money(gain) + ' <span class="tag tag-eq">' + (t.term || 'LTCG') + '</span>'}</td>
            <td><button class="btn-ghost btn-inline" data-mf-cost="${t.id}">${hasCost ? 'Edit cost' : 'Add cost'}</button></td>
          </tr>`;
        }).join('')}</tbody>`;
    }
  }

  async function renderEquityView() {
    const everything = await computeEquityHoldings();
    const eqH = everything.filter(h => h.qty > 1e-9).sort((a, b) => b.value - a.value);
    const invested = eqH.reduce((s, h) => s + h.invested, 0);
    const value = eqH.reduce((s, h) => s + h.value, 0);
    const gp = pctSpan(invested > 0 ? ((value - invested) / invested) * 100 : 0);

    // XIRR over stocks with real trade dates only (closed positions included — their flows count).
    const eqx = equityXirrInputs(everything);
    let eqXirr = null;
    if (eqx.flows.length) {
      const flows = [...eqx.flows].sort((a, b) => a.date - b.date);
      flows.push({ date: new Date(), amount: eqx.value });
      eqXirr = Calc.xirr(flows);
    }
    const xirrSub = eqx.excluded
      ? `excludes ${eqx.excluded} imported stock${eqx.excluded > 1 ? 's' : ''} — dates unknown`
      : '';
    document.getElementById('eqKpiRow').innerHTML = [
      kpiCard('Invested', Charts.money(invested)),
      kpiCard('Current value', Charts.money(value)),
      kpiCard('Unrealized P&amp;L', Charts.money(value - invested), gp.text, gp.cls),
      kpiCard('XIRR', eqXirr != null ? (eqXirr * 100).toFixed(1) + '%' : '—', xirrSub, 'muted-sub'),
      kpiCard('Holdings', eqH.length)
    ].join('');

    const table = document.getElementById('eqHoldingsTable');
    if (!eqH.length) {
      table.innerHTML = '<tbody><tr><td class="muted">No equity holdings yet — import them from your statements, or add a transaction by hand.</td></tr></tbody>';
      return;
    }
    table.innerHTML = `
      <thead><tr><th>Stock</th><th class="num">Qty</th><th class="num">Avg cost</th><th class="num">LTP</th><th class="num">Invested</th><th class="num">Value</th><th class="num">P&amp;L</th><th></th></tr></thead>
      <tbody>${eqH.map(h => equityRow(h)).join('')}</tbody>`;
  }

  // Which holdings are showing their individual lots (kept across re-renders).
  const expandedLots = new Set();
  const lotKey = (h) => `${h.symbol}|${h.exchange}`;

  function heldLabel(days) {
    if (days < 31) return `${days}d`;
    const m = Math.floor(days / 30.44);
    return m < 12 ? `${m}m` : `${Math.floor(m / 12)}y ${m % 12}m`;
  }

  // Every remaining lot on its own: what it cost, what it is worth, and how long it has been held
  // (12 months or more = long-term). Lot-level figures are what make cost and profit accurate.
  function lotsTable(h) {
    const now = Date.now();
    const lots = [...h.lots].sort((a, b) => a.date - b.date);
    const editable = !h.hasCorpAction;
    return `<table class="lots-table">
      <thead><tr><th>Bought</th><th>Held</th><th class="num">Qty</th><th class="num">Cost / share</th><th class="num">Cost</th><th class="num">Value</th><th class="num">P&amp;L</th><th></th></tr></thead>
      <tbody>${lots.map(l => {
        const days = Math.max(0, Math.floor((now - l.date.getTime()) / 86400000));
        const cost = l.qty * l.price, val = l.qty * h.ltp, gain = val - cost;
        const iso = l.date.toISOString().slice(0, 10);
        const btn = l.id && editable
          ? `<button class="icon-btn" title="Edit this lot's date or cost" data-edit-lot="${l.id}">✎</button>`
          : `<button class="icon-btn" disabled title="${l.id ? 'This stock has a split/bonus entry, so lot figures are adjusted — edit the raw entries on the Transactions tab' : ''}">✎</button>`;
        return `<tr>
          <td class="nowrap">${iso}${l.dateEstimated ? ` <span class="tag tag-est" title="${l.dateNote || 'Not a real purchase date'} — edit to set the real date">est.</span>` : ''}</td>
          <td class="nowrap">${heldLabel(days)} <span class="tag ${days >= 365 ? 'tag-buy' : 'tag-warn'}">${days >= 365 ? 'long-term' : 'short-term'}</span></td>
          <td class="num">${l.qty.toLocaleString('en-IN', { maximumFractionDigits: 3 })}</td>
          <td class="num">${l.price.toFixed(2)}${l.priceEdited ? ' <span class="tag tag-eq" title="Cost entered by you">edited</span>' : ''}</td>
          <td class="num">${Charts.money(cost)}</td>
          <td class="num">${Charts.money(val)}</td>
          <td class="num">${pnlChip(gain, cost > 0 ? (gain / cost) * 100 : 0)}</td>
          <td>${btn}</td>
        </tr>`;
      }).join('')}</tbody></table>`;
  }

  function equityRow(h) {
    const open = expandedLots.has(lotKey(h));
    const n = h.lots.length;
    return `
        <tr class="${open ? 'row-open' : ''}">
          <td><div class="cell-name">${h.companyName || h.symbol}${h.hasEstimatedDates ? ' <span class="tag tag-est" title="Some shares have no purchase date (older than the uploaded statements, or transferred in), so this stock is left out of XIRR. Set the real dates on the Transactions tab.">est. dates</span>' : ''}</div><div class="cell-sub">${h.symbol} · ${h.exchange}${h.broker ? ' · ' + h.broker : ''}</div>
            <button class="lots-btn" data-toggle-lots="${lotKey(h)}" aria-expanded="${open}">${open ? '▾' : '▸'} ${n} lot${n === 1 ? '' : 's'}</button></td>
          <td class="num">${h.qty.toLocaleString('en-IN')}</td>
          <td class="num">${h.avgCost.toFixed(2)}</td>
          <td class="num">${h.ltp.toFixed(2)}${h.ltpIsLive ? '<span class="live-dot" title="Live price"></span>' : ' <span class="cell-sub" title="No live price — showing average cost">avg</span>'}</td>
          <td class="num">${Charts.money(h.invested)}</td>
          <td class="num">${Charts.money(h.value)}</td>
          <td class="num">${pnlChip(h.gain, h.gainPct)}</td>
          <td><span class="row-actions"><button class="icon-btn" title="Edit the stock's ticker or name (dates and costs are edited lot by lot)" data-edit-holding="${h.symbol}|${h.exchange}">✎</button><button class="icon-btn" title="Remove this stock (deletes all its transactions)" data-del-holding="${h.symbol}|${h.exchange}">✕</button></span></td>
        </tr>${open ? `<tr class="lots-row"><td colspan="8">${lotsTable(h)}</td></tr>` : ''}`;
  }

  async function renderTransactionsView(filter = 'all') {
    const [mfTxns, eqTxns] = await Promise.all([Mf.getAllTransactions(), Equity.getAllTransactions()]);
    let rows = [];
    if (filter !== 'equity') rows.push(...mfTxns.map(t => ({ ...t, asset: 'mf', name: t.schemeName, qty: Math.abs(t.units || 0), price: t.nav, amount: Math.abs(t.amount || 0), txType: t.type })));
    if (filter !== 'mf') rows.push(...eqTxns.map(t => ({ ...t, asset: 'equity', name: t.companyName || t.symbol, qty: t.qty, price: t.price, amount: t.qty * t.price, txType: t.type })));
    rows.sort((a, b) => new Date(b.date) - new Date(a.date));

    const table = document.getElementById('txnTable');
    if (!rows.length) { table.innerHTML = '<tbody><tr><td class="muted">No transactions yet.</td></tr></tbody>'; return; }
    table.innerHTML = `
      <thead><tr><th>Date</th><th>Asset</th><th>Name</th><th>Type</th><th class="num">Qty</th><th class="num">Price</th><th class="num">Amount</th><th></th></tr></thead>
      <tbody>${rows.slice(0, 300).map(r => `
        <tr>
          <td class="nowrap">${r.date}${r.dateEstimated ? ` <span class="tag tag-est" title="${r.dateNote ? r.dateNote + ' — ' : ''}not a real purchase date; use Set date once known">est.</span>` : ''}</td>
          <td><span class="tag ${r.asset === 'mf' ? 'tag-mf' : 'tag-eq'}">${r.asset === 'mf' ? 'MF' : 'Equity'}</span></td>
          <td>${r.name}</td>
          <td><span class="tag ${/buy|purchase/.test(r.txType) ? 'tag-buy' : 'tag-sell'}">${r.txType}</span></td>
          <td class="num">${r.qty != null ? Number(r.qty).toLocaleString('en-IN', { maximumFractionDigits: 3 }) : '—'}</td>
          <td class="num">${r.price != null ? Number(r.price).toFixed(2) : '—'}</td>
          <td class="num">${Charts.money(r.amount)}</td>
          <td><span class="row-actions">${r.dateEstimated ? `<button class="btn-ghost btn-inline" title="Enter the real purchase date" data-set-date="${r.id}">Set date</button>` : ''}<button class="icon-btn" title="Edit this transaction" data-edit-txn="${r.asset}|${r.id}">✎</button><button class="icon-btn" title="Delete this transaction" data-del-txn="${r.asset}|${r.id}">✕</button></span></td>
        </tr>`).join('')}</tbody>`;
  }

  /* ---------- Navigation ---------- */
  function renderViewActions(view) {
    const el = document.getElementById('viewActions');
    if (view === 'mf') el.innerHTML = `<button class="btn-ghost" id="actResetMf" title="Delete all mutual fund data so statements can be re-imported from scratch">Reset MF data</button><button class="btn-primary" id="actUploadMf">Upload CDSL statement</button>`;
    else if (view === 'equity') el.innerHTML = `<button class="btn-ghost" id="actDeleteImported" title="Permanently delete everything the statement import created (manual entries are kept)">Delete imported data</button><button class="btn-ghost" id="actImportEquity" title="Read holdings from a CDSL statement and cost from the Stock Details spreadsheet">Import from statements</button><button class="btn-primary" id="actAddEquity">Add transaction</button>`;
    else el.innerHTML = '';

    const uploadBtn = document.getElementById('actUploadMf');
    if (uploadBtn) uploadBtn.addEventListener('click', () => MfUI.openMfModal());
    const resetBtn = document.getElementById('actResetMf');
    if (resetBtn) resetBtn.addEventListener('click', async () => {
      if (!confirm('Delete ALL mutual fund data (holdings, statement history and transactions)?\n\nEquity is not affected. You can then re-import your CDSL statements from scratch. This cannot be undone.')) return;
      const r = await Mf.resetAll();
      alert(`Removed ${r.folios} folios, ${r.txns} transactions and ${r.periods} statement periods.`);
      refreshCurrentView();
    });
    const addBtn = document.getElementById('actAddEquity');
    if (addBtn) addBtn.addEventListener('click', () => EquityUI.openEquityModal());
    const importBtn = document.getElementById('actImportEquity');
    if (importBtn) importBtn.addEventListener('click', () => EqImport.open());
    const delImportedBtn = document.getElementById('actDeleteImported');
    if (delImportedBtn) delImportedBtn.addEventListener('click', () => EqImport.openDelete());
  }

  async function refreshCurrentView() {
    document.querySelectorAll('.view').forEach(v => v.hidden = v.id !== `view-${currentView}`);
    if (currentView === 'dashboard') await renderDashboard();
    else if (currentView === 'mf') await renderMfView();
    else if (currentView === 'equity') await renderEquityView();
    else if (currentView === 'transactions') await renderTransactionsView();
  }

  function switchView(view) {
    currentView = view;
    document.querySelectorAll('.nav-item').forEach(el => el.classList.toggle('active', el.dataset.view === view));
    document.getElementById('viewTitle').textContent = VIEW_META[view].title;
    document.getElementById('viewSubtitle').textContent = VIEW_META[view].subtitle;
    renderViewActions(view);
    refreshCurrentView();
  }

  function updateSyncPill() {
    const dot = document.getElementById('syncDot');
    const label = document.getElementById('syncLabel');
    if (DB.mode === 'cloud') { dot.className = 'dot ok'; label.textContent = 'Synced'; }
    else { dot.className = 'dot local'; label.textContent = 'Local only — see SETUP.md'; }
  }

  async function boot() {
    DB.init();
    updateSyncPill();

    document.querySelectorAll('.nav-item').forEach(el => el.addEventListener('click', () => switchView(el.dataset.view)));
    document.querySelectorAll('[data-close-modal]').forEach(el => el.addEventListener('click', (e) => {
      e.target.closest('.modal-overlay').hidden = true;
    }));
    document.querySelectorAll('.modal-overlay').forEach(el => el.addEventListener('click', (e) => {
      if (e.target === el) el.hidden = true;
    }));
    document.getElementById('txnFilter').addEventListener('click', (e) => {
      if (!e.target.classList.contains('seg-btn')) return;
      document.querySelectorAll('#txnFilter .seg-btn').forEach(b => b.classList.remove('active'));
      e.target.classList.add('active');
      renderTransactionsView(e.target.dataset.filter);
    });
    const refreshBtn = document.getElementById('refreshPricesBtn');
    refreshBtn.title = 'Refreshes live equity prices and mutual fund NAVs. Mutual funds are skipped 08:00–17:00 IST, since AMFI only publishes each day’s NAV once, at night.';
    refreshBtn.addEventListener('click', async (e) => {
      e.target.disabled = true; e.target.textContent = 'Refreshing…';
      try {
        const r = await Pricing.refreshAll();
        await refreshCurrentView();
        if (r && r.skippedMf) {
          e.target.textContent = 'Equity refreshed (MF skipped)';
          setTimeout(() => { e.target.textContent = 'Refresh prices'; e.target.disabled = false; }, 2200);
          return;
        }
      } catch (err) { console.error(err); }
      e.target.disabled = false; e.target.textContent = 'Refresh prices';
    });

    // Delete buttons on the equity holdings table and the transactions table — delegated,
    // since both tables' rows are fully re-rendered on every refresh.
    document.getElementById('mfHoldingsTable').addEventListener('click', (e) => {
      const btn = e.target.closest('[data-edit-folio]');
      if (btn) EditUI.openFolio(btn.dataset.editFolio);
    });
    document.getElementById('eqHoldingsTable').addEventListener('click', async (e) => {
      const toggle = e.target.closest('[data-toggle-lots]');
      if (toggle) {
        const k = toggle.dataset.toggleLots;
        if (expandedLots.has(k)) expandedLots.delete(k); else expandedLots.add(k);
        renderEquityView();
        return;
      }
      const lotBtn = e.target.closest('[data-edit-lot]');
      if (lotBtn) { EditUI.openLot(lotBtn.dataset.editLot); return; }
      const editBtn = e.target.closest('[data-edit-holding]');
      if (editBtn) { const [s, x] = editBtn.dataset.editHolding.split('|'); EditUI.openHolding(s, x); return; }
      const btn = e.target.closest('[data-del-holding]');
      if (!btn) return;
      const [symbol, exchange] = btn.dataset.delHolding.split('|');
      if (!confirm(`Remove ${symbol} (${exchange}) — this deletes all of its transactions. Continue?`)) return;
      await Equity.deleteHolding(symbol, exchange);
      refreshCurrentView();
    });
    // A redemption's purchase cost isn't in a CDSL statement, so it's entered by hand; that
    // also needs to know whether the units were held over a year (long-term) or not.
    document.getElementById('mfClosedTable').addEventListener('click', async (e) => {
      const btn = e.target.closest('[data-mf-cost]');
      if (!btn) return;
      const id = btn.dataset.mfCost;
      const txn = (await Mf.getAllTransactions()).find(t => t.id === id);
      if (!txn) return;
      const proceeds = Math.abs(txn.amount || 0);
      const input = prompt(`Total purchase cost of the ${Math.abs(txn.units || 0).toLocaleString('en-IN')} units redeemed from\n${txn.schemeName}\n\nProceeds were ₹${proceeds.toLocaleString('en-IN')}. Enter what you originally paid (₹):`, txn.costBasis != null ? txn.costBasis : '');
      if (input === null) return;
      const cost = parseFloat(String(input).replace(/,/g, ''));
      if (isNaN(cost) || cost < 0) { alert('Please enter a valid amount.'); return; }
      const longTerm = confirm('Were these units held for more than 12 months before redemption?\n\nOK = long-term (LTCG), Cancel = short-term (STCG).');
      await Mf.updateTransaction(id, { costBasis: cost, term: longTerm ? 'LTCG' : 'STCG' });
      refreshCurrentView();
    });
    document.getElementById('txnTable').addEventListener('click', async (e) => {
      const editTxn = e.target.closest('[data-edit-txn]');
      if (editTxn) {
        const [asset, id] = editTxn.dataset.editTxn.split('|');
        if (asset === 'mf') EditUI.openMfTxn(id); else EditUI.openEquityTxn(id);
        return;
      }
      // Imported lots start with an estimated date; entering the real one makes the stock
      // count towards XIRR once none of its lots are estimated any more.
      const dateBtn = e.target.closest('[data-set-date]');
      if (dateBtn) {
        const id = dateBtn.dataset.setDate;
        const txn = (await Equity.getAllTransactions()).find(t => t.id === id);
        if (!txn) return;
        const input = prompt(`Real purchase date of these ${Number(txn.qty).toLocaleString('en-IN')} shares of ${txn.companyName || txn.symbol}\n(currently a placeholder: ${txn.date}${txn.dateNote ? ' — ' + txn.dateNote : ''}). Use YYYY-MM-DD:`, txn.date);
        if (input === null) return;
        const d = String(input).trim();
        if (!/^\d{4}-\d{2}-\d{2}$/.test(d) || isNaN(new Date(d))) { alert('Please enter the date as YYYY-MM-DD, e.g. 2024-11-05.'); return; }
        await Equity.updateTransaction(id, { date: d, dateEstimated: false, dateEdited: true });
        refreshCurrentView();
        return;
      }
      const btn = e.target.closest('[data-del-txn]');
      if (!btn) return;
      const [asset, id] = btn.dataset.delTxn.split('|');
      if (!confirm('Delete this transaction?')) return;
      if (asset === 'mf') await Mf.deleteTransaction(id);
      else await Equity.deleteTransaction(id);
      refreshCurrentView();
    });

    switchView('dashboard');
  }

  document.addEventListener('DOMContentLoaded', boot);

  return { refreshCurrentView, switchView, equityTimeline };
})();
