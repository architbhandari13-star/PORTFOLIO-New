/* db.js — storage abstraction.
   Uses Firestore when js/firebase-config.js has real values; otherwise
   transparently falls back to browser localStorage so the app is fully
   usable before Firebase is wired up. Same async interface either way. */

const DB = (() => {
  let mode = 'local';
  let fs = null; // firestore instance

  const LOCAL_KEY = 'ppdb_v1';

  function loadLocal() {
    try {
      const raw = localStorage.getItem(LOCAL_KEY);
      return raw ? JSON.parse(raw) : {};
    } catch (e) { return {}; }
  }
  function saveLocal(data) {
    try { localStorage.setItem(LOCAL_KEY, JSON.stringify(data)); } catch (e) { /* quota etc — ignore */ }
  }
  function uid() {
    return 'id_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 9);
  }

  function init() {
    const hasConfig = typeof FIREBASE_CONFIG !== 'undefined' && FIREBASE_CONFIG.projectId && FIREBASE_CONFIG.apiKey;
    // Appending ?local=1 to the URL forces browser-only storage even when Firebase is
    // configured — useful for trying things out without touching the real database.
    const forceLocal = /[?&]local=1\b/.test(location.search);
    if (hasConfig && !forceLocal && typeof firebase !== 'undefined') {
      try {
        firebase.initializeApp(FIREBASE_CONFIG);
        fs = firebase.firestore();
        mode = 'cloud';
      } catch (e) {
        console.warn('Firebase init failed, falling back to local storage.', e);
        mode = 'local';
      }
    } else {
      mode = 'local';
    }
    return mode;
  }

  async function getAll(collection) {
    if (mode === 'cloud') {
      const snap = await fs.collection(collection).get();
      return snap.docs.map(d => ({ id: d.id, ...d.data() }));
    }
    const data = loadLocal();
    const c = data[collection] || {};
    return Object.keys(c).map(id => ({ id, ...c[id] }));
  }

  async function getDoc(collection, id) {
    if (mode === 'cloud') {
      const doc = await fs.collection(collection).doc(id).get();
      return doc.exists ? { id: doc.id, ...doc.data() } : null;
    }
    const data = loadLocal();
    const c = data[collection] || {};
    return c[id] ? { id, ...c[id] } : null;
  }

  // A counter that goes up whenever your data changes. Screens use it to know whether what they worked
  // out last time is still valid (e.g. the Overview chart when you switch away and back). Writes the
  // app itself makes while drawing — the daily value snapshot, live prices, saved market data —
  // don't count, or every draw would invalidate itself.
  let version = 0;
  // 'meta' (the equity data-generation counter) and 'equity_history_cache' are also bookkeeping the
  // app writes to itself while rendering, not a real data change — bumping DB.version for them would
  // make the Overview's own cached chart invalidate itself the moment it finishes caching.
  const QUIET = new Set(['value_history', 'price_cache', 'equity_prices', 'equity_symbols', 'equity_history_cache', 'meta']);
  const bump = (collection) => { if (!QUIET.has(collection)) version++; };

  async function setDoc(collection, id, obj) {
    bump(collection);
    if (mode === 'cloud') {
      await fs.collection(collection).doc(id).set(obj);
      return id;
    }
    const data = loadLocal();
    if (!data[collection]) data[collection] = {};
    data[collection][id] = obj;
    saveLocal(data);
    return id;
  }

  async function addDoc(collection, obj) {
    const id = uid();
    await setDoc(collection, id, obj);
    return id;
  }

  async function updateDoc(collection, id, patch) {
    bump(collection);
    if (mode === 'cloud') {
      await fs.collection(collection).doc(id).set(patch, { merge: true });
      return id;
    }
    const data = loadLocal();
    if (!data[collection]) data[collection] = {};
    data[collection][id] = { ...(data[collection][id] || {}), ...patch };
    saveLocal(data);
    return id;
  }

  async function deleteDoc(collection, id) {
    bump(collection);
    if (mode === 'cloud') {
      await fs.collection(collection).doc(id).delete();
      return;
    }
    const data = loadLocal();
    if (data[collection]) delete data[collection][id];
    saveLocal(data);
  }

  return { init, getAll, getDoc, setDoc, addDoc, updateDoc, deleteDoc, get mode() { return mode; }, get version() { return version; } };
})();
