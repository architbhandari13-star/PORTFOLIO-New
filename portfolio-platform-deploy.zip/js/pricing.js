/* pricing.js — live price refresh for equity and mutual funds. Both are fetched directly
   from the browser, on demand, whenever the app is opened or "Refresh prices" is clicked —
   no backend, no scheduled job required for either.

   MF NAV: api.mfapi.in (official, CORS-open, no key).

   Equity: TradingView's internal scanner endpoint (scanner.tradingview.com), the same one
   their own website's screener uses. This is undocumented/unofficial — not a published API —
   found after every other free option was ruled out: Twelve Data's free plan excludes India
   price data entirely, and NSE/BSE both block scripted access (their live-quote endpoints
   outright, and even their bulk end-of-day bhavcopy files specifically from cloud/datacenter
   IP ranges like Google Apps Script's, confirmed by direct testing). TradingView's endpoint
   is CORS-open, covers NSE and BSE natively, and batches multiple symbols in one call — but
   being unofficial, it could change or stop working without notice. If that ever happens,
   the options are the same as before: a scheduled job (fighting the same IP-blocking that
   ruled out bhavcopy), a manual price field, or a paid data plan. */

const Pricing = (() => {
  const CACHE = 'price_cache';

  function eqKey(symbol, exchange) { return `eq_${symbol}_${exchange}`; }
  function mfKey(isin) { return `mf_${isin}`; }

  async function getCache() {
    const rows = await DB.getAll(CACHE);
    const map = {};
    rows.forEach(r => { map[r.id] = r; });
    return map;
  }

  async function refreshEquityPrices(holdings) {
    const items = holdings.filter(h => h.qty > 1e-9).map(h => ({ symbol: h.symbol, exchange: h.exchange }));
    if (!items.length) return getCache();
    const tickers = items.map(h => `${h.exchange}:${h.symbol}`);
    try {
      // No explicit Content-Type header: TradingView's CORS preflight doesn't allow
      // "application/json" in Access-Control-Allow-Headers, which the browser then blocks
      // client-side before the request ever goes out. Letting fetch default to
      // text/plain keeps this a CORS "simple request" (no preflight needed at all) — their
      // server parses the JSON body fine regardless of the declared content type (verified).
      // A hard timeout: a stalled fetch (seen live on mfapi.in — never errors, never completes)
      // must not be able to leave "Refresh prices" spinning forever.
      const ctrl = new AbortController();
      const t = setTimeout(() => ctrl.abort(), 10000);
      let res;
      try {
        res = await fetch('https://scanner.tradingview.com/india/scan', {
          method: 'POST',
          body: JSON.stringify({ symbols: { tickers, query: { types: [] } }, columns: ['close', 'change'] }),
          signal: ctrl.signal
        });
      } finally { clearTimeout(t); }
      const json = await res.json();
      const now = new Date().toISOString();
      await Promise.all((json.data || []).map(row => {
        const [exchange, symbol] = row.s.split(':');
        const [close, changePct] = row.d;
        if (close == null) return null;
        return DB.setDoc(CACHE, eqKey(symbol, exchange), { price: close, changePct, asOf: now, source: 'tradingview' });
      }));
    } catch (e) { console.warn('TradingView quote fetch failed', e); }
    return getCache();
  }

  // A stored scheme code is only trusted if mfapi.in reports the folio's own ISIN for it.
  // If it doesn't (or there's no code yet) the fund is re-matched by ISIN, and only once that
  // re-match genuinely fails is any earlier NAV cached for it removed rather than left to mislead.
  //
  // A plain network failure (offline, mfapi.in briefly down/rate-limited) is NOT treated as a
  // mismatch: it used to wipe the folio's mfapiSchemeCode, which forced the expensive multi-query
  // re-search (resolveSchemeCode) on every following refresh — the fund never got to "settle",
  // so "Refresh prices" kept taking a long time. Now a fetch failure just skips that fund for
  // this run and leaves everything as it was, to be tried again next time.
  async function refreshMfNav(folios) {
    const now = new Date().toISOString();
    const byIsin = {};
    folios.forEach(f => { (byIsin[f.isin] = byIsin[f.isin] || []).push(f); });

    for (const [isin, group] of Object.entries(byIsin)) {
      if (!group.some(f => (f.closingUnits || 0) > 0)) continue; // fully redeemed — nothing to price
      const savedCode = (group.find(f => f.mfapiSchemeCode) || {}).mfapiSchemeCode || null;
      let code = savedCode, data = null, networkFailed = false;

      if (code) {
        try { data = await MfHistory.fetchLatest(code); }
        catch (e) { networkFailed = true; }
      }
      if (!networkFailed && (!data || !MfHistory.isinMatches(data.meta, isin))) {
        try {
          code = await MfHistory.resolveSchemeCode(group[0]);
          data = null;
          if (code) { try { data = await MfHistory.fetchLatest(code); } catch (e) { networkFailed = true; } }
        } catch (e) { networkFailed = true; }
      }
      if (networkFailed) continue; // couldn't reach mfapi.in this time — leave the stored code alone, retry next refresh

      const nav = data && data.data && data.data[0] && parseFloat(data.data[0].nav);
      if (code && nav && MfHistory.isinMatches(data.meta, isin)) {
        await Promise.all(group.filter(f => f.mfapiSchemeCode !== code).map(f => DB.updateDoc('mf_folios', f.id, { mfapiSchemeCode: code })));
        await DB.setDoc(CACHE, mfKey(isin), { price: nav, asOf: now, navDate: data.data[0].date, source: 'mfapi.in' });
      } else {
        // reached mfapi.in, but no listing verifies against this ISIN — a genuine mismatch, not a blip
        await DB.deleteDoc(CACHE, mfKey(isin));
        await Promise.all(group.filter(f => f.mfapiSchemeCode).map(f => DB.updateDoc('mf_folios', f.id, { mfapiSchemeCode: null })));
      }
    }
    return getCache();
  }

  // AMFI publishes each day's NAV once, at night — searching mfapi.in for it during market hours
  // (08:00–17:00 IST) can only ever return the same value that's already cached, so "Refresh
  // prices" skips the MF search in that window and only refreshes equity, which does move
  // intraday. Computed from actual India time, not the device's own clock/timezone.
  function inMfQuietHours() {
    const hour = Number(new Intl.DateTimeFormat('en-GB', { timeZone: 'Asia/Kolkata', hour: 'numeric', hourCycle: 'h23' }).format(new Date()));
    return hour >= 8 && hour < 17;
  }

  async function refreshAll() {
    const [folios, eqHoldings] = await Promise.all([Mf.getAllFolios(), Equity.computeHoldings()]);
    const skippedMf = inMfQuietHours();
    await Promise.all([skippedMf ? Promise.resolve() : refreshMfNav(folios), refreshEquityPrices(eqHoldings)]);
    return { cache: await getCache(), skippedMf };
  }

  return { getCache, refreshMfNav, refreshEquityPrices, refreshAll, inMfQuietHours, eqKey, mfKey };
})();
