/* api-config.js
   -------------------------------------------------------------
   Twelve Data powers equity live prices + the stock search/autocomplete.
   Get a free key (no card required): https://twelvedata.com/pricing -> "Basic" (free)
   Paste it below. mutual fund NAVs need no key (api.mfapi.in is fully open).
   ------------------------------------------------------------- */
const TWELVEDATA_API_KEY = "6c6af128351c4a248adb47cce1ba4613";
