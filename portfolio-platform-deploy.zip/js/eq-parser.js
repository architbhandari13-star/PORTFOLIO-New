/* eq-parser.js — reads the two documents the equity import is built from, entirely in the
   browser, and joins them. No DOM or database access.

     1. CDSL Consolidated Account Statement (PDF) -> the equity positions held at each demat
        account on the statement date (ISIN, security name, quantity, market price, value).
     2. Stock Summary spreadsheet (a Tally-style export from the owner's books) -> the average
        cost of each closing position. It has no per-trade dates.

   CDSL's own layout is the awkward part. Extracted as plain text, the ISIN, name and number
   columns of a holdings table look shuffled — but pdf.js reports real glyph coordinates, and
   in those the ISIN, balances, price and value of one holding sit on exactly the same
   baseline, while its (wrapped, vertically centred) security name sits in a separate column.
   So a holding is read as "everything on one baseline", and the name lines are attached to
   whichever holding's baseline they are nearest to.

   Reconciliation is built in: every account's parsed values are summed and compared with the
   "Portfolio Value" figure CDSL prints under that account. */

const EqParser = (() => {

  const ISIN_TOKEN = /^(IN[A-Z0-9]{10})([*#@$^<>~!]*)$/;
  const NUM_TOKEN = /^-?(?:[\d,]+\.?\d*|\.\d+)$/;
  const HEADER_WORDS = /^([ab]\)|Security|ISIN|Current|Frozen|Pledge|Pledged|Setup|Bal|Face|Value|Market|Price \/|Free Bal|Free bal|Locked|Locked in|in Bal|Transit|Confirmed|Remat|Demat|Pending|DEMAT)\b/;

  const NAME_COL = [95, 245];   // x-range of the wrapped security-name column
  const ISIN_COL_MAX = 90;      // ISINs are left of this

  const num = (s) => (s == null || s === '' || s === '--') ? 0 : parseFloat(String(s).replace(/,/g, ''));
  const toIso = (dmy) => { const m = /(\d{2})-(\d{2})-(\d{4})/.exec(dmy || ''); return m ? `${m[3]}-${m[2]}-${m[1]}` : null; };

  /* ---------- PDF -> positioned text items, page by page ---------- */
  // Same clean-up as the mutual fund parser: soft hyphens stripped, bilingual (Hindi) twins dropped.
  async function loadPages(arrayBuffer, password) {
    const pdf = await pdfjsLib.getDocument({ data: arrayBuffer, password }).promise;
    const pages = [];
    for (let p = 1; p <= pdf.numPages; p++) {
      const content = await (await pdf.getPage(p)).getTextContent();
      const items = content.items
        .map(it => ({ it, s: (it.str || '').replace(/­/g, '') }))
        .filter(({ s }) => s.trim().length && /^[\x00-\x7F₹`]*$/.test(s))
        .map(({ it, s }) => ({ s: s.trim(), x: it.transform[4], w: it.width, y: it.transform[5] }));
      pages.push({ number: p, items });
    }
    return pages;
  }

  function groupLines(items, tol = 0.8) {
    const sorted = [...items].sort((a, b) => b.y - a.y || a.x - b.x);
    const lines = [];
    for (const it of sorted) {
      const last = lines[lines.length - 1];
      if (last && Math.abs(last.y - it.y) <= tol) last.items.push(it);
      else lines.push({ y: it.y, items: [it] });
    }
    lines.forEach(l => l.items.sort((a, b) => a.x - b.x));
    return lines;
  }

  /* ---------- classify an ISIN so non-equity holdings can be set aside ---------- */
  // Indian ISIN: IN + issuer type (E company / F fund / G government) + issuer code, then a
  // 2-digit security type — 01 equity shares, 20 rights entitlement, 07/08 debentures.
  function classifyIsin(isin, name) {
    if (/^INE/.test(isin)) {
      const type = isin.slice(7, 9);
      if (type === '01') return 'equity';
      if (type === '20') return 'rights';
      if (type === '07' || type === '08') return 'debt';
      return 'other';
    }
    if (/^INF/.test(isin)) return /ETF|BEES/i.test(name || '') ? 'etf' : 'fund';
    if (/^IN00/.test(isin) || /^IN0/.test(isin)) return 'govt';
    return 'other';
  }

  /* ---------- clean a CDSL security name for display / matching ---------- */
  // "BALU FORGE INDUSTRIES LIMITED # NEW EQ SH WITH FV RS.10/- AFTER CAPITAL REDUCTION"
  //   -> "Balu Forge Industries Limited"
  function cleanSecurityName(raw) {
    let s = String(raw || '').replace(/\s+/g, ' ').trim();
    // Exchange-traded funds are listed as "<AMC>#<AMC> MF-<FUND NAME>": the fund name is what matters.
    const mf = /#.*?\bMF-(.+)$/i.exec(s);
    s = mf ? mf[1] : s.split('#')[0];
    s = s.replace(/\s*[-–]\s*(NEW\s+)?(EQUITY|EQ|EQTY)\b.*$/i, '');
    s = s.replace(/\s+(NEW\s+)?(EQUITY|EQTY|EQ)\s+SH(ARES?)?\b.*$/i, '');
    s = s.replace(/\s+(NEW\s+)?EQUITY\b.*$/i, '');
    s = s.replace(/\s*[-–]\s*$/, '').trim();
    return s.toLowerCase().replace(/\b([a-z])([a-z]*)/g, (m, a, b) => a.toUpperCase() + b)
      .replace(/\bLtd\b/g, 'Ltd').replace(/\bPvt\b/g, 'Pvt');
  }

  /* ---------- 1. CDSL holdings ---------- */
  function parseHoldingsFromPages(pages) {
    const accounts = [];
    let market = 'CDSL';
    let pendingDp = null;          // last "DP Name" seen, waiting for its holdings heading
    let cur = null;                // account whose holdings table we are inside
    let hold = false;
    let asOf = null;

    for (const page of pages) {
      let rows = [];
      let nameItems = [];
      const flush = () => {
        // A wrapped name can be taller than the spacing between holdings, so "nearest baseline"
        // mis-assigns its outer lines. Names and holdings are in the same top-to-bottom order,
        // though, and a name's lines are evenly spaced (~9pt) with a visibly larger gap between
        // one name and the next — so split the lines into blocks and pair blocks with holdings
        // in order. Only if the counts disagree does it fall back to nearest-baseline.
        const sortedRows = [...rows].sort((a, b) => b.y - a.y);
        const lines = [...nameItems].sort((a, b) => b.y - a.y);
        const blocks = [];
        for (const n of lines) {
          const last = blocks[blocks.length - 1];
          if (last && last[last.length - 1].y - n.y < 11) last.push(n);
          else blocks.push([n]);
        }
        if (blocks.length === sortedRows.length) {
          blocks.forEach((b, i) => sortedRows[i].nameLines.push(...b));
        } else {
          for (const n of lines) {
            let best = null;
            for (const r of rows) if (!best || Math.abs(r.y - n.y) < Math.abs(best.y - n.y)) best = r;
            if (best) best.nameLines.push(n);
          }
        }
        for (const r of rows) {
          r.nameLines.sort((a, b) => b.y - a.y);
          r.name = r.nameLines.map(n => n.s).join(' ').replace(/\s+/g, ' ').trim();
          delete r.nameLines;
          cur.holdings.push(r);
        }
        rows = []; nameItems = [];
      };

      for (const line of groupLines(page.items)) {
        const text = line.items.map(i => i.s).join(' ');

        let m;
        if ((m = /DEMAT ACCOUNTS HELD WITH (CDSL|NSDL)/.exec(text))) { if (hold) flush(); market = m[1]; hold = false; continue; }
        if (/^DP Name\s*:/.test(text) || line.items[0].s.startsWith('DP Name')) {
          if (hold) flush();
          const nameItem = line.items.find(i => i.x >= 60 && i.x < 300);
          const idIdx = line.items.findIndex(i => /^(BO ID|DPID|DP ID)\b/.test(i.s));
          const idItem = idIdx >= 0 ? line.items.slice(idIdx + 1).find(i => /^[A-Z0-9]{8,}$/.test(i.s)) : null;
          pendingDp = nameItem ? { dp: nameItem.s, boId: idItem ? idItem.s : null, market } : null;
          hold = false;
          continue;
        }
        if (/STATEMENT OF TRANSACTIONS/.test(text)) { if (hold) flush(); hold = false; continue; }
        if ((m = /HOLDING STATEMENT AS ON\s+(\d{2}-\d{2}-\d{4})/.exec(text))) {
          if (hold) flush();
          if (/Other Details/i.test(text)) { hold = false; continue; }   // bonds etc. — different layout
          asOf = asOf || toIso(m[1]);
          if (!cur || cur._pending !== pendingDp) {
            cur = { dp: pendingDp ? pendingDp.dp : 'Unknown', boId: pendingDp ? pendingDp.boId : null,
                    market: pendingDp ? pendingDp.market : market, holdings: [], portfolioValue: null, _pending: pendingDp };
            accounts.push(cur);
          }
          hold = true;
          continue;
        }
        // This line closes an account's holdings — sometimes after an "Other Details" block that
        // is not parsed, so it is matched whether or not a table is currently open.
        if (cur && (m = /Portfolio Value\s*[`₹]?\s*([\d,]+\.\d+)\s+as on/i.exec(text))) {
          if (hold) flush();
          if (cur.portfolioValue == null) cur.portfolioValue = num(m[1]);
          hold = false;
          continue;
        }
        if (!hold) continue;

        // a holdings-table line: either a holding baseline (has an ISIN) or a fragment of a name
        const isinItem = line.items.find(i => i.x < ISIN_COL_MAX && ISIN_TOKEN.test(i.s));
        if (isinItem) {
          const [, isin, marker] = ISIN_TOKEN.exec(isinItem.s);
          const nums = line.items.filter(i => i.x >= 200 && (i.s === '--' || NUM_TOKEN.test(i.s)));
          if (nums.length >= 3) {
            const qty = num(nums[0].s);
            const price = num(nums[nums.length - 2].s);
            const value = num(nums[nums.length - 1].s);
            rows.push({ isin, marker, qty, price, value, y: line.y, page: page.number, nameLines: [],
                        consistent: Math.abs(qty * price - value) <= Math.max(1, value * 0.005) });
          }
        }
        // (page furniture above y=660 and the footer below y=40 is never part of a name)
        if (line.y < 660 && line.y > 40) {
          for (const it of line.items) {
            if (it.x >= NAME_COL[0] && it.x < NAME_COL[1] && !NUM_TOKEN.test(it.s) && it.s !== '--' && !HEADER_WORDS.test(it.s) && !ISIN_TOKEN.test(it.s)) {
              nameItems.push(it);
            }
          }
        }
      }
      if (hold) flush();   // table continues on the next page; names never straddle a page break
    }

    accounts.forEach(a => {
      delete a._pending;
      a.holdings.forEach(h => { h.cleanName = cleanSecurityName(h.name); h.kind = classifyIsin(h.isin, h.name); });
      a.parsedValue = a.holdings.reduce((s, h) => s + h.value, 0);
    });
    return { asOfDate: asOf, accounts };
  }

  async function parseCdsl(arrayBuffer, password) {
    const pages = await loadPages(arrayBuffer, password);
    const out = parseHoldingsFromPages(pages);
    if (!out.accounts.length) throw new Error('No demat holdings tables were found in this file. Is it a CDSL Consolidated Account Statement?');
    return out;
  }

  /* ---------- 1b. CDSL transaction tables -> dated events ---------- */
  // In pdf.js coordinates a transaction table is regular even though its text dump is not:
  //   - a security's ISIN sits on the baseline of its *first* dated line and applies to every
  //     dated line below it until the next ISIN;
  //   - each transaction is one baseline carrying the date (x≈316) and up to five figures
  //     (opening balance, credit, debit, closing balance, stamp duty) in right-aligned columns;
  //   - the transaction code ("PAYOUT-CR", "EP-DR", …) is in a small description block beside it.
  // What each code means was established by summing them per stock and comparing with the
  // owner's books (bought / sold quantities match exactly) — see the handoff, §6.8.
  const TXN_DATE = /^(\d{2})-(\d{2})-(\d{4})$/;
  const TXN_COLS = { op: 406, cr: 448, dr: 490, cl: 537, duty: 579 };   // right edge of each column

  function eventKind(head, desc) {
    const c = (head || '').split(/\s+/)[0];
    // A corporate action on pledged shares prints one line for the pledged sub-balance and one
    // for the current balance; only the "Current" line carries the true movement.
    if (/^CA-/.test(c) && /\b(Cr|Db) Pledge\b/.test(desc)) return 'PLEDGE';
    // Exchange-settled purchases arrive under three codes. INTDEP-CR also carries a counter-BO
    // id; with an exchange settlement reference (S/G + digits) it is still a purchase, without
    // one it is a plain transfer from another account.
    if (c === 'INTDEP-CR') return (/CTRBO/.test(desc) && !/\b[SG]\d{6,}\b/.test(desc)) ? 'TRANSFER_IN' : 'BUY';
    if (c === 'PAYOUT-CR' || c === 'ON-CR' || c === 'BSECH-CR') return 'BUY';
    if (c === 'OF-CR') return 'TRANSFER_IN';                  // off-market credit — no purchase date
    if (c === 'EP-DR') return 'SELL';                          // early pay-in = delivery against a sale
    if (c === 'Pledge' || c === 'Unpledge' || c === 'MP') return 'PLEDGE';   // no change of ownership
    // Dividend reinvested into more units (an ETF or fund held in demat): new units on that date.
    // Only used where that ISIN is actually an imported holding, so fund noise is harmless.
    if (c === 'CA-Reinvestment') return 'CA_NEW';
    if (c === 'CA-Split' || c === 'CA-Listed') return 'CA_MOVE';   // old ISIN debited, new credited
    if (c === 'CA-Bonus') return 'CA_NEW';
    if (c === 'CA-Rights') return /^CA-Rights Entitlement/.test(desc) ? 'RIGHTS_ENT' : 'CA_NEW';
    if (c === 'CA-Extinguishment') return 'RIGHTS_ENT';
    return 'OTHER';
  }
  const KEPT_KINDS = new Set(['BUY', 'TRANSFER_IN', 'SELL', 'CA_MOVE', 'CA_NEW']);
  const isEquityIsin = (isin) => !['debt', 'rights', 'govt'].includes(classifyIsin(isin, ''));

  function extractEvents(pages) {
    const events = [], periods = [];
    const openSeen = new Set();
    let dp = null, acct = null, mode = null, isin = null, ord = 0;

    for (const page of pages) {
      const lines = groupLines(page.items.filter(i => i.y < 660 && i.y > 40), 0.6);
      const descLines = [], dataLines = [];
      for (const l of lines) {
        const text = l.items.map(i => i.s).join(' ');
        if (/^DP Name\s*:/.test(text) || l.items[0].s.startsWith('DP Name')) {
          const nameItem = l.items.find(i => i.x >= 60 && i.x < 300);
          const idIdx = l.items.findIndex(i => /^(BO ID|DPID|DP ID)\b/.test(i.s));
          const idItem = idIdx >= 0 ? l.items.slice(idIdx + 1).find(i => /^[A-Z0-9]{8,}$/.test(i.s)) : null;
          dp = nameItem ? nameItem.s : dp; acct = idItem ? idItem.s : dp; mode = null; isin = null;
          continue;
        }
        let m;
        if ((m = /STATEMENT OF TRANSACTIONS FOR THE PERIOD FROM\s+(\d{2}-\d{2}-\d{4})\s+TO\s+(\d{2}-\d{2}-\d{4})/.exec(text))) {
          mode = 'tx'; isin = null;
          periods.push({ acct, dp, from: toIso(m[1]), to: toIso(m[2]) });
          continue;
        }
        if (/HOLDING STATEMENT AS ON/.test(text)) { mode = null; continue; }
        if (mode !== 'tx') continue;

        const isinItem = l.items.find(i => i.x < ISIN_COL_MAX && ISIN_TOKEN.test(i.s));
        if (isinItem) isin = ISIN_TOKEN.exec(isinItem.s)[1];
        // description column (transaction code and references)
        const d = l.items.filter(i => i.x >= 215 && i.x < 312).map(i => i.s).join(' ');
        if (d) descLines.push({ y: l.y, text: d });
        const dateItem = l.items.find(i => i.x >= 305 && i.x < 335 && TXN_DATE.test(i.s));
        if (dateItem) {
          const cells = {};
          l.items.filter(i => i.x >= 340 && (i.s === '--' || NUM_TOKEN.test(i.s))).forEach(i => {
            const right = i.x + (i.w || 0);
            let best = null, bd = 1e9;
            for (const [k, c] of Object.entries(TXN_COLS)) { const dd = Math.abs(right - c); if (dd < bd) { bd = dd; best = k; } }
            if (bd <= 14) cells[best] = i.s;
          });
          dataLines.push({ y: l.y, date: toIso(dateItem.s), cells, isin, acct, dp, page: page.number });
        }
      }
      // A transaction's description is a block of lines ~9pt apart; blocks are ≥11pt apart.
      const blocks = [];
      for (const dl of descLines) {
        const b = blocks[blocks.length - 1];
        if (b && b.lines[b.lines.length - 1].y - dl.y < 11) b.lines.push(dl); else blocks.push({ lines: [dl] });
      }
      for (const dt of dataLines) {
        if (!dt.isin) continue;
        const blk = blocks.find(b => dt.y <= b.lines[0].y + 0.5 && dt.y >= b.lines[b.lines.length - 1].y - 0.5);
        const desc = blk ? blk.lines.map(l => l.text).join(' | ') : '';
        const head = blk ? blk.lines[0].text : '';
        const okey = dt.acct + '|' + dt.isin + '|' + periods.length;
        if (!openSeen.has(okey) && isEquityIsin(dt.isin)) {     // opening balance printed on the first line of each security
          openSeen.add(okey);
          const per = periods[periods.length - 1];
          events.push({ kind: 'OPEN', acct: dt.acct, dp: dt.dp, isin: dt.isin, qty: num(dt.cells.op), periodStart: per ? per.from : null, date: per ? per.from : null, ord: ord++ });
        }
        const kind = eventKind(head, desc);
        if (!KEPT_KINDS.has(kind) || !isEquityIsin(dt.isin)) continue;
        const cr = num(dt.cells.cr), dr = num(dt.cells.dr);
        const caM = /(\d{8})\s+(Cr|Db)\b/.exec(desc) || /(\d{8})/.exec(desc);
        const refs = (desc.match(/\d{7,}/g) || []).join('/');
        events.push({ kind, acct: dt.acct, dp: dt.dp, isin: dt.isin, date: dt.date, qty: cr > 0 ? cr : dr, side: cr > 0 ? 'Cr' : 'Db',
                      caRef: /^CA_/.test(kind) && caM ? caM[1] : null, code: head.split(/\s+/)[0], ref: refs, ord: ord++ });
      }
    }
    return { events, periods };
  }

  /* ---------- 1c. the statement's own portfolio-value history ---------- */
  // Page 2/3 of every CAS prints "Consolidated Portfolio Valuation for Year": the total value of
  // the whole CDSL portfolio at each of 12 month-ends, and below it the split by asset class at the
  // statement date. This is the only source of month-by-month values, and it is what lets the
  // Overview draw a real equity line (total − mutual funds − bonds/gold, see App).
  const MONTH_IDX = { Jan: 0, Feb: 1, Mar: 2, Apr: 3, May: 4, Jun: 5, Jul: 6, Aug: 7, Sep: 8, Oct: 9, Nov: 10, Dec: 11 };
  function extractPortfolioTable(pages) {
    const page = pages.find(p => p.items.some(i => /Month-Year/.test(i.s)) && p.items.some(i => /Portfolio Valuation/.test(i.s)));
    if (!page) return { monthly: [], classes: null };
    const items = page.items.filter(i => i.y > 40 && i.y < 700);
    const amount = /^[\d,]+\.\d{2}$/;
    const monthly = [];
    for (const it of items) {
      const m = /^(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+(\d{4})$/.exec(it.s);
      if (!m || it.x > 120) continue;
      const amt = items.find(o => Math.abs(o.y - it.y) < 1.5 && o.x > 200 && o.x < 300 && amount.test(o.s));
      if (!amt) continue;
      monthly.push({ date: new Date(Date.UTC(+m[2], MONTH_IDX[m[1]] + 1, 0)).toISOString().slice(0, 10), total: num(amt.s) });
    }
    const labels = { debt: /^Debts$/, equity: /^Equity$/, mf: /^Mutual Fund Folios$/, mfDemat: /^Mutual Funds Held in Demat Form$/, others: /^Others$/ };
    const classes = {};
    for (const [k, re] of Object.entries(labels)) {
      const lab = items.find(i => re.test(i.s) && i.y < 300);
      const val = lab && items.find(o => Math.abs(o.y - lab.y) < 3 && o.x > 400 && o.x < 450 && amount.test(o.s));
      if (val) classes[k] = num(val.s);
    }
    return { monthly, classes: Object.keys(classes).length ? classes : null };
  }

  // Everything one CDSL statement contributes: holdings on its date, the dated events, and the
  // month-end portfolio values.
  async function parseCdslFull(arrayBuffer, password) {
    const pages = await loadPages(arrayBuffer, password);
    const holdings = parseHoldingsFromPages(pages);
    if (!holdings.accounts.length) throw new Error('No demat holdings tables were found in this file. Is it a CDSL Consolidated Account Statement?');
    const tx = extractEvents(pages);
    const table = extractPortfolioTable(pages);
    return { ...holdings, events: tx.events, periods: tx.periods, monthly: table.monthly, classes: table.classes };
  }

  /* ---------- 2. Stock Summary spreadsheet ---------- */
  // Column layout (0-based): A name | B..D opening qty/rate/value | E..G inwards | H..J outwards | K..M closing
  function parseStockSummaryRows(rows) {
    const cellNum = (v) => {
      if (v == null || v === '') return 0;
      if (typeof v === 'number') return v;
      const m = /^-?[\d,]*\.?\d+/.exec(String(v).trim());
      return m ? parseFloat(m[0].replace(/,/g, '')) : 0;
    };
    let period = null;
    for (const r of rows.slice(0, 20)) {
      const t = (r || []).map(c => c == null ? '' : String(c)).join(' ');
      const m = /(\d{1,2}-[A-Za-z]{3}-\d{2,4})\s+to\s+(\d{1,2}-[A-Za-z]{3}-\d{2,4})/.exec(t);
      if (m) { period = { from: m[1], to: m[2] }; break; }
    }
    const hdr = rows.findIndex(r => r && String(r[1] || '').trim() === 'Quantity');
    if (hdr < 0) throw new Error('This does not look like a Stock Summary export (no Quantity/Rate/Value header found).');

    const list = [];
    for (let i = hdr + 1; i < rows.length; i++) {
      const r = rows[i] || [];
      const name = String(r[0] == null ? '' : r[0]).trim();
      if (!name) continue;
      if (/^grand total$/i.test(name)) break;
      const grp = (o) => ({ qty: cellNum(r[o]), rate: cellNum(r[o + 1]), value: cellNum(r[o + 2]) });
      list.push({ rowNo: i + 1, name, opening: grp(1), inwards: grp(4), outwards: grp(7), closing: grp(10), group: null, isGroup: false });
    }

    // Broker/group heading rows (e.g. "Prabhudas Liladhar Pvt. Ltd.") carry the *sum* of the
    // rows under them, so they are recognised by that sum rather than by their name.
    for (let i = 0; i < list.length; i++) {
      const target = list[i].closing.value;
      if (!target) continue;
      let acc = 0, kids = 0;
      for (let j = i + 1; j < list.length && j < i + 400; j++) {
        if (list[j].closing.value) { acc += list[j].closing.value; kids++; }
        if (kids >= 2 && Math.abs(acc - target) < 1.5) {
          list[i].isGroup = true;
          for (let k = i + 1; k <= j; k++) list[k].group = list[i].name;
          break;
        }
      }
    }
    return { period, rows: list.filter(r => !r.isGroup), groups: list.filter(r => r.isGroup) };
  }

  async function loadXlsx() {
    if (typeof XLSX !== 'undefined') return;
    await new Promise((resolve, reject) => {
      const s = document.createElement('script');
      s.src = 'https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js';
      s.onload = resolve;
      s.onerror = () => reject(new Error('Could not load the spreadsheet reader — check your internet connection.'));
      document.head.appendChild(s);
    });
  }

  async function parseStockSummary(arrayBuffer) {
    await loadXlsx();
    const wb = XLSX.read(arrayBuffer, { type: 'array' });
    const ws = wb.Sheets[wb.SheetNames[0]];
    const rows = XLSX.utils.sheet_to_json(ws, { header: 1, raw: true, defval: null });
    return parseStockSummaryRows(rows);
  }

  /* ---------- 3. Join: which books row is which CDSL holding ---------- */
  const STOP = new Set(['limited', 'ltd', 'pvt', 'private', 'india', 'indian', 'of', 'and', 'the', 'equity', 'eq', 'eqty', 'share', 'shares', 'sh',
    'new', 'with', 'face', 'value', 'rs', 're', 'fv', 'after', 'split', 'sub', 'subdivision', 'division', 'consolidation', 'capital', 'reduction',
    'company', 'co', 'corporation', 'corpn', 'corp', 'inc', 'prabhudas', 'prabudas', 'smc', 'global', 'liladhar', 'lilladher', 'a', 'old', 'name', 'bonus']);

  function nameTokens(name) {
    return cleanSecurityName(name).toLowerCase().replace(/&/g, ' and ').replace(/[^a-z0-9 ]+/g, ' ')
      .split(/\s+/).filter(t => t && !STOP.has(t));
  }

  // How well a (usually truncated) books name fits a CDSL name: the share of the books-name's
  // words that begin some word of the CDSL name.
  function nameScore(booksName, cdslName) {
    const xt = nameTokens(booksName), ct = nameTokens(cdslName);
    if (!xt.length || !ct.length) return 0;
    const hit = (t) => ct.some(c => c.startsWith(t) || (c.length >= 4 && t.startsWith(c)));
    return xt.filter(hit).length / xt.length;
  }

  // holdings: [{qty, cleanName, ...}]  rows: parseStockSummary().rows
  // Returns Map(holding -> { row, confidence, reason }) — each books row used at most once.
  function matchCosts(holdings, rows) {
    const cands = rows.filter(r => r.closing.qty > 0);
    const scored = [];
    holdings.forEach(h => {
      cands.forEach(r => {
        const ns = nameScore(r.name, h.cleanName || h.name);
        const qtyEq = Math.abs(h.qty - r.closing.qty) < 0.5;
        const total = ns + (qtyEq ? 1 : 0);
        if (total >= 1.0 || ns >= 0.99) scored.push({ h, r, ns, qtyEq, total });
      });
    });
    scored.sort((a, b) => b.total - a.total || b.ns - a.ns);
    const usedH = new Set(), usedR = new Set(), result = new Map();
    for (const s of scored) {
      if (usedH.has(s.h) || usedR.has(s.r)) continue;
      let confidence = null, reason = '';
      if (s.qtyEq && s.ns >= 0.5) { confidence = 'high'; reason = 'name and quantity match'; }
      else if (s.qtyEq && s.ns > 0) { confidence = 'medium'; reason = 'quantity matches, name partly'; }
      else if (s.ns >= 0.99 && !s.qtyEq) { confidence = 'medium'; reason = `name matches, quantity differs (books ${s.r.closing.qty})`; }
      else if (s.qtyEq) { confidence = 'low'; reason = 'only the quantity matches'; }
      if (!confidence) continue;
      usedH.add(s.h); usedR.add(s.r);
      result.set(s.h, { row: s.r, confidence, reason });
    }

    // Second pass, for what is still unmatched: a books row whose *closing* is nil but whose
    // opening (or purchased) quantity equals the demat quantity and whose name fits. That is
    // what a books mistake looks like — e.g. shares booked out at a token price though still held.
    for (const h of holdings) {
      if (result.has(h)) continue;
      let best = null;
      for (const r of rows) {
        if (usedR.has(r) || r.closing.qty > 0) continue;
        const ns = nameScore(r.name, h.cleanName || h.name);
        const qtyHit = [r.opening.qty, r.inwards.qty].some(q => Math.abs(q - h.qty) < 0.5);
        if (ns >= 0.99 && qtyHit && (!best || ns > best.ns)) best = { r, ns };
      }
      if (best) {
        usedR.add(best.r);
        result.set(h, { row: best.r, confidence: 'low', reason: 'the books show this as sold, but the demat account still holds it — cost taken from the books\' opening/purchase rate' });
      }
    }
    return result;
  }

  // The per-share cost a books row implies for a position still held.
  function costRate(row) {
    if (!row) return null;
    // value / quantity rather than the printed rate, which the books round to 2 decimals —
    // this makes total cost equal the books' closing value exactly.
    if (row.closing.qty > 0) return Math.round((row.closing.value / row.closing.qty) * 10000) / 10000;
    if (row.opening.qty > 0) return row.opening.rate;
    if (row.inwards.qty > 0) return row.inwards.rate;
    return null;
  }

  // Split a position into the lots it must have been built from. The books give opening
  // quantity, quantity bought and sold in the year, and closing quantity; FIFO means sales
  // consume the oldest units first, so whatever remains of the opening stock is the oldest lot
  // and the rest was bought during the year. Every lot carries the books' closing average cost,
  // so the total equals the closing value in the books.
  function splitLots(row, closingQty) {
    if (!row) return [{ kind: 'single', qty: closingQty }];
    // The books show nothing left, yet the demat account still holds the shares (a books
    // entry that doesn't reflect reality). Whatever the books did hold at the start of the
    // year is the best evidence of how old the shares are.
    if (row.closing.qty <= 0) return [{ kind: row.opening.qty >= closingQty - 0.5 ? 'opening' : 'year', qty: closingQty }];
    const remOpening = Math.max(0, Math.min(closingQty, row.opening.qty - row.outwards.qty));
    const bought = closingQty - remOpening;
    const lots = [];
    if (remOpening > 1e-9) lots.push({ kind: 'opening', qty: remOpening });
    if (bought > 1e-9) lots.push({ kind: 'year', qty: bought });
    return lots.length ? lots : [{ kind: 'single', qty: closingQty }];
  }

  return { parseCdsl, parseCdslFull, extractEvents, eventKind, parseHoldingsFromPages, loadPages, parseStockSummary, parseStockSummaryRows, matchCosts, splitLots, costRate,
           classifyIsin, cleanSecurityName, nameScore };
})();
