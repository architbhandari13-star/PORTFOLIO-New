/* calc.js — pure calculation helpers: XIRR, FIFO lot matching, P&L, STCG/LTCG classification.
   No DOM/Firebase dependencies — safe to unit-test in isolation. */

const Calc = (() => {

  /* ---------- XIRR (Newton-Raphson with bisection fallback) ---------- */
  // cashflows: [{ date: Date, amount: number }]  (outflows negative, inflows/valuation positive)
  function xirr(cashflows, guess = 0.15) {
    if (!cashflows || cashflows.length < 2) return null;
    const flows = cashflows
      .filter(cf => cf.amount !== 0)
      .map(cf => ({ t: (cf.date - cashflows[0].date) / (1000 * 60 * 60 * 24 * 365), amount: cf.amount }));
    if (flows.length < 2) return null;

    const npv = (rate) => flows.reduce((s, cf) => s + cf.amount / Math.pow(1 + rate, cf.t), 0);
    const dnpv = (rate) => flows.reduce((s, cf) => s - cf.t * cf.amount / Math.pow(1 + rate, cf.t + 1), 0);

    let rate = guess;
    for (let i = 0; i < 100; i++) {
      const f = npv(rate);
      const df = dnpv(rate);
      if (Math.abs(df) < 1e-10) break;
      const next = rate - f / df;
      if (!isFinite(next)) break;
      if (Math.abs(next - rate) < 1e-7) { rate = next; break; }
      rate = next;
      if (rate <= -0.999) rate = -0.999 + 1e-6; // keep in domain
    }
    if (isFinite(rate) && Math.abs(npv(rate)) < 1) return rate;

    // Bisection fallback for stubborn cases
    let lo = -0.9999, hi = 10;
    let flo = npv(lo), fhi = npv(hi);
    if (isNaN(flo) || isNaN(fhi) || flo * fhi > 0) return isFinite(rate) ? rate : null;
    for (let i = 0; i < 200; i++) {
      const mid = (lo + hi) / 2;
      const fmid = npv(mid);
      if (Math.abs(fmid) < 1e-3) return mid;
      if (flo * fmid < 0) { hi = mid; fhi = fmid; } else { lo = mid; flo = fmid; }
    }
    return (lo + hi) / 2;
  }

  /* ---------- FIFO lot tracking ---------- */
  // txns: [{ date, type: 'buy'|'sell', qty, price, charges }] sorted by date ascending
  // Returns { lots: [remaining open lots], realized: [{ sellDate, buyDate, qty, buyPrice, sellPrice, gain, term }] }
  function fifoMatch(txns, ltcgDays = 365) {
    const sorted = [...txns].sort((a, b) => new Date(a.date) - new Date(b.date));
    const lots = []; // { date, qty, price }
    const realized = [];

    for (const t of sorted) {
      const qty = Number(t.qty);
      const price = Number(t.price);
      if (t.type === 'buy') {
        // id / source / dateEstimated let the UI show and edit each remaining lot individually
        lots.push({ date: new Date(t.date), qty, price, id: t.id, source: t.source, dateEstimated: t.dateEstimated, dateNote: t.dateNote, priceEdited: t.priceEdited });
      } else if (t.type === 'sell') {
        let remaining = qty;
        while (remaining > 1e-9 && lots.length) {
          const lot = lots[0];
          const matched = Math.min(lot.qty, remaining);
          const holdingDays = (new Date(t.date) - lot.date) / (1000 * 60 * 60 * 24);
          realized.push({
            sellDate: t.date,
            buyDate: lot.date,
            qty: matched,
            buyPrice: lot.price,
            sellPrice: price,
            gain: matched * (price - lot.price),
            term: holdingDays >= ltcgDays ? 'LTCG' : 'STCG',
            holdingDays: Math.round(holdingDays)
          });
          lot.qty -= matched;
          remaining -= matched;
          if (lot.qty <= 1e-9) lots.shift();
        }
        // remaining > 0 here means a sell exceeds recorded buys (data entry gap) — ignored, surfaced by caller if needed.
      } else if (t.type === 'split' || t.type === 'bonus') {
        // adjustment: ratio applied to all open lots' qty, price divided inversely to preserve cost value
        const ratio = Number(t.ratio || 1); // e.g. 2 for a 1:1 bonus (qty doubles), or split ratio
        for (const lot of lots) {
          lot.qty *= ratio;
          lot.price /= ratio;
        }
      }
    }
    return { lots, realized };
  }

  function avgCost(lots) {
    const totalQty = lots.reduce((s, l) => s + l.qty, 0);
    const totalCost = lots.reduce((s, l) => s + l.qty * l.price, 0);
    return totalQty > 0 ? totalCost / totalQty : 0;
  }

  /* ---------- P&L helpers ---------- */
  function unrealizedPnl(qty, avgCostVal, ltp) {
    const invested = qty * avgCostVal;
    const value = qty * ltp;
    return { invested, value, gain: value - invested, gainPct: invested > 0 ? ((value - invested) / invested) * 100 : 0 };
  }

  function sumRealized(realizedList) {
    const total = realizedList.reduce((s, r) => s + r.gain, 0);
    const stcg = realizedList.filter(r => r.term === 'STCG').reduce((s, r) => s + r.gain, 0);
    const ltcg = realizedList.filter(r => r.term === 'LTCG').reduce((s, r) => s + r.gain, 0);
    return { total, stcg, ltcg };
  }

  return { xirr, fifoMatch, avgCost, unrealizedPnl, sumRealized };
})();
